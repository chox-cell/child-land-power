import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FaCompass, FaInfoCircle, FaArrowLeft, FaArrowRight } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

function VirtualTour() {
  const [currentScene, setCurrentScene] = useState(0);
  const [showInfo, setShowInfo] = useState(false);
  const navigate = useNavigate();

  const scenes = [
    {
      id: 'outdoor-playground',
      title: 'Eco-Friendly Playground',
      description: 'Our outdoor playground features sustainable materials and natural play elements.',
      image: 'https://images.unsplash.com/photo-1597430203889-c93a0cd4e27f?w=1200&auto=format&q=80',
      hotspots: [
        { x: 50, y: 30, label: 'Organic Garden' },
        { x: 70, y: 60, label: 'Natural Climbing Area' }
      ]
    },
    {
      id: 'language-center',
      title: 'Bilingual Learning Space',
      description: 'A dedicated space for immersive language learning through play and interaction.',
      image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1200&auto=format&q=80',
      hotspots: [
        { x: 40, y: 40, label: 'Reading Nook' },
        { x: 60, y: 50, label: 'Activity Area' }
      ]
    },
    {
      id: 'eco-classroom',
      title: 'Sustainable Classroom',
      description: 'Classrooms built with eco-friendly materials and natural lighting.',
      image: 'https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?w=1200&auto=format&q=80',
      hotspots: [
        { x: 30, y: 45, label: 'Recycling Station' },
        { x: 65, y: 35, label: 'Natural Light Windows' }
      ]
    }
  ];

  const handleNextScene = () => {
    setCurrentScene((prev) => (prev + 1) % scenes.length);
  };

  const handlePrevScene = () => {
    setCurrentScene((prev) => (prev - 1 + scenes.length) % scenes.length);
  };

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Tour Navigation */}
      <nav className="bg-white shadow-soft sticky top-16 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={handleBack}
                className="text-primary hover:text-accent transition-colors flex items-center gap-2"
                aria-label="Go back"
              >
                <FaArrowLeft />
                <span>Back</span>
              </button>
              <h1 className="text-2xl font-bold text-primary flex items-center gap-2">
                <FaCompass />
                Virtual Tour
              </h1>
            </div>
            <button
              onClick={() => setShowInfo(!showInfo)}
              className="text-primary hover:text-accent transition-colors"
              aria-label="Toggle information"
            >
              <FaInfoCircle size={24} />
            </button>
          </div>
        </div>
      </nav>

      {/* Main Tour View */}
      <div className="relative h-[calc(100vh-8rem)]">
        <motion.div
          key={currentScene}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          <img
            src={scenes[currentScene].image}
            alt={scenes[currentScene].title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>

          {/* Hotspots */}
          {scenes[currentScene].hotspots.map((hotspot, index) => (
            <motion.button
              key={index}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 bg-accent text-white px-3 py-1 rounded-full text-sm hover:bg-accent-light transition-colors"
              style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
            >
              {hotspot.label}
            </motion.button>
          ))}
        </motion.div>

        {/* Navigation Controls */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4">
          <button
            onClick={handlePrevScene}
            className="btn-primary p-4 rounded-full"
            aria-label="Previous scene"
          >
            <FaArrowLeft />
          </button>
          <div className="bg-white/10 backdrop-blur-lg px-6 py-3 rounded-full">
            {scenes.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentScene(index)}
                className={`w-3 h-3 rounded-full mx-1 transition-colors ${
                  currentScene === index ? 'bg-accent' : 'bg-gray-400'
                }`}
                aria-label={`Go to scene ${index + 1}`}
              />
            ))}
          </div>
          <button
            onClick={handleNextScene}
            className="btn-primary p-4 rounded-full"
            aria-label="Next scene"
          >
            <FaArrowRight />
          </button>
        </div>

        {/* Information Panel */}
        {showInfo && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 20 }}
            className="absolute top-0 right-0 w-96 h-full bg-white shadow-lg p-8 overflow-y-auto"
          >
            <h2 className="text-2xl font-bold text-primary mb-4">
              {scenes[currentScene].title}
            </h2>
            <p className="text-text-secondary mb-6">
              {scenes[currentScene].description}
            </p>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-primary">Key Features:</h3>
              <ul className="list-disc list-inside text-text-secondary space-y-2">
                {scenes[currentScene].hotspots.map((hotspot, index) => (
                  <li key={index}>{hotspot.label}</li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default VirtualTour;