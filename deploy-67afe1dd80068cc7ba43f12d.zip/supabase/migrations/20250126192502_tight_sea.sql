-- Check if policy exists first
DO $$ 
BEGIN
    -- Drop the policy if it exists
    DROP POLICY IF EXISTS "Users can create their own profile" ON profiles;
    
    -- Create the policy
    CREATE POLICY "Users can create their own profile"
      ON profiles
      FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = id);
END $$;

-- Add helpful comment
COMMENT ON POLICY "Users can create their own profile" ON profiles IS 'Allow users to create their own profile only';