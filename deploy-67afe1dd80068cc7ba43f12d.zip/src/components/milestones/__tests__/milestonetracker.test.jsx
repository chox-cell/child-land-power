import { describe, it, expect, beforeEach, vi } from 'vitest';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithProviders } from '../../../test/utils';
import MilestoneTracker from '../MilestoneTracker';
import { supabase } from '../../../lib/supabaseClient';

describe('MilestoneTracker Component', () => {
  const mockMilestones = [
    {
      id: '1',
      title: 'First Words',
      description: 'Uses single words meaningfully',
      category: 'language',
      importance: 'essential',
      age_range_start: 9,
      age_range_end: 14,
    },
  ];

  beforeEach(() => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: mockMilestones, error: null }),
      eq: vi.fn().mockResolvedValue({ data: [], error: null }),
    }));
  });

  it('renders milestone tracker', async () => {
    renderWithProviders(<MilestoneTracker childId="123" />);
    
    await waitFor(() => {
      expect(screen.getByText('First Words')).toBeInTheDocument();
      expect(screen.getByText('Uses single words meaningfully')).toBeInTheDocument();
    });
  });

  it('filters milestones by category', async () => {
    const user = userEvent.setup();
    renderWithProviders(<MilestoneTracker childId="123" />);

    await waitFor(() => {
      expect(screen.getByText('First Words')).toBeInTheDocument();
    });

    await user.click(screen.getByRole('button', { name: /language/i }));
    
    expect(screen.getByText('First Words')).toBeInTheDocument();
  });

  it('marks milestone as achieved', async () => {
    const user = userEvent.setup();
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      insert: vi.fn().mockResolvedValue({ data: [{ id: '1' }], error: null }),
      select: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: mockMilestones, error: null }),
      eq: vi.fn().mockResolvedValue({ data: [], error: null }),
    }));

    renderWithProviders(<MilestoneTracker childId="123" />);

    await waitFor(() => {
      expect(screen.getByText('First Words')).toBeInTheDocument();
    });

    const achieveButton = screen.getByRole('button', { name: /mark as achieved/i });
    await user.click(achieveButton);

    await waitFor(() => {
      expect(supabase.from).toHaveBeenCalledWith('child_milestones');
    });
  });
});