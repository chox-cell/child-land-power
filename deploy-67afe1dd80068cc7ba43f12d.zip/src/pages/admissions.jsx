import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaClipboard, FaCalendarCheck, FaFileSignature, FaQuestionCircle } from 'react-icons/fa';

function Admissions() {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState('full-time');

  const handleEnroll = () => {
    navigate('/register-child');
  };

  const handleScheduleTour = () => {
    navigate('/schedule-visit');
  };

  const handleContact = () => {
    navigate('/contact');
  };

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Join Childland
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Begin your child's journey in our bilingual, eco-conscious education program
          </p>
        </section>

        {/* Enrollment Steps */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-purple-600 text-center mb-8">Enrollment Process</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 hover:border-blue-100 transition-all">
              <FaClipboard className="text-4xl text-blue-600 mb-4" />
              <h3 className="text-2xl font-bold text-purple-600 mb-2">1. Choose Plan</h3>
              <p className="text-gray-600 mb-4">
                Select the care plan that best fits your family's needs.
              </p>
              <select
                value={selectedPlan}
                onChange={(e) => setSelectedPlan(e.target.value)}
                className="w-full mb-4 rounded-lg border-gray-200 focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="full-time">Full-Time Care (€800/month)</option>
                <option value="part-time">Part-Time Care (€400/month)</option>
                <option value="drop-in">Drop-In Care (€10/hour)</option>
              </select>
              <button 
                onClick={handleEnroll}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Continue to Registration
              </button>
            </div>

            {/* Step 2 */}
            <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 hover:border-blue-100 transition-all">
              <FaCalendarCheck className="text-4xl text-blue-600 mb-4" />
              <h3 className="text-2xl font-bold text-purple-600 mb-2">2. Schedule Tour</h3>
              <p className="text-gray-600 mb-4">
                Visit our facility, meet our team, and see our eco-friendly learning environment.
              </p>
              <button 
                onClick={handleScheduleTour}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Book Tour
              </button>
            </div>

            {/* Step 3 */}
            <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 hover:border-blue-100 transition-all">
              <FaFileSignature className="text-4xl text-blue-600 mb-4" />
              <h3 className="text-2xl font-bold text-purple-600 mb-2">3. Complete Forms</h3>
              <p className="text-gray-600 mb-4">
                Fill out necessary documentation and health information.
              </p>
              <button 
                onClick={handleEnroll}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Access Forms
              </button>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <FaQuestionCircle className="text-5xl text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-purple-600">Frequently Asked Questions</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:border-blue-100 transition-all">
              <h3 className="text-xl font-bold text-purple-600 mb-2">What are your fees?</h3>
              <p className="text-gray-600">
                We offer flexible plans starting from €400/month for part-time care, €800/month for full-time care, and €10/hour for drop-in care. All plans include meals and educational activities.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:border-blue-100 transition-all">
              <h3 className="text-xl font-bold text-purple-600 mb-2">What languages do you teach?</h3>
              <p className="text-gray-600">
                We provide a bilingual environment with both French and English. Children naturally acquire both languages through daily activities, songs, and play.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:border-blue-100 transition-all">
              <h3 className="text-xl font-bold text-purple-600 mb-2">What is your teacher-to-child ratio?</h3>
              <p className="text-gray-600">
                We maintain a 1:8 ratio for children aged 3-5 years, ensuring each child receives proper attention and care.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:border-blue-100 transition-all">
              <h3 className="text-xl font-bold text-purple-600 mb-2">What ages do you accept?</h3>
              <p className="text-gray-600">
                Our program is specifically designed for children aged 3-5 years old, with activities tailored to their developmental stage.
              </p>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center">
          <h2 className="text-3xl font-bold text-purple-600 mb-6">Ready to Begin?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Start your child's journey with Childland today. We're here to answer any questions you may have.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <button 
              onClick={handleEnroll}
              className="bg-blue-600 text-white font-semibold py-4 px-8 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Apply Now
            </button>
            <button 
              onClick={handleContact}
              className="border-2 border-blue-600 text-blue-600 font-semibold py-4 px-8 rounded-lg hover:bg-blue-600 hover:text-white transition-colors"
            >
              Contact Us
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}

export default Admissions;