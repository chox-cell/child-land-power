export const translations = {
  en: {
    navigation: {
      home: 'Home',
      about: 'About',
      programs: 'Programs',
      sustainability: 'Sustainability',
      languageResources: 'Language Resources',
      blog: 'Blog',
      admissions: 'Admissions',
      testimonials: 'Testimonials',
      contact: 'Contact',
      portal: 'Parent Portal'
    },
    home: {
      hero: {
        title: 'Welcome to Childland',
        subtitle: "Nurturing Tomorrow's Eco-Conscious Leaders!",
        location: 'Orléans, France'
      },
      features: {
        ecoLearning: {
          title: 'Eco-Conscious Learning',
          description: 'Through hands-on gardening, recycling projects, and nature exploration, we nurture a deep connection with our environment.'
        },
        bilingual: {
          title: 'Bilingual Environment',
          description: 'Immersive French and English learning through play, stories, and daily activities, preparing children for a global future.'
        }
      },
      cta: {
        title: 'Join Our Community',
        learnMore: 'Learn More',
        enroll: 'Enroll Now',
        contact: 'Contact Us'
      },
      values: {
        title: 'Our Core Values',
        sustainability: 'Sustainability',
        bilingual: 'Bilingual',
        flexibility: 'Flexibility',
        community: 'Community'
      }
    },
    common: {
      learnMore: 'Learn More',
      contactUs: 'Contact Us',
      enroll: 'Enroll Now',
      readMore: 'Read More',
      loading: 'Loading...',
      error: 'An error occurred',
      success: 'Success!',
      submit: 'Submit',
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      view: 'View',
      close: 'Close'
    }
  },
  fr: {
    navigation: {
      home: 'Accueil',
      about: 'À Propos',
      programs: 'Programmes',
      sustainability: 'Durabilité',
      languageResources: 'Ressources Linguistiques',
      blog: 'Blog',
      admissions: 'Admissions',
      testimonials: 'Témoignages',
      contact: 'Contact',
      portal: 'Espace Parents'
    },
    home: {
      hero: {
        title: 'Bienvenue à Childland',
        subtitle: 'Former les Leaders Éco-Responsables de Demain !',
        location: 'Orléans, France'
      },
      features: {
        ecoLearning: {
          title: 'Apprentissage Éco-Responsable',
          description: 'À travers le jardinage, le recyclage et l\'exploration de la nature, nous cultivons un lien profond avec notre environnement.'
        },
        bilingual: {
          title: 'Environnement Bilingue',
          description: 'Apprentissage immersif du français et de l\'anglais par le jeu, les histoires et les activités quotidiennes.'
        }
      },
      cta: {
        title: 'Rejoignez Notre Communauté',
        learnMore: 'En Savoir Plus',
        enroll: 'Inscrivez-vous',
        contact: 'Contactez-nous'
      },
      values: {
        title: 'Nos Valeurs',
        sustainability: 'Durabilité',
        bilingual: 'Bilinguisme',
        flexibility: 'Flexibilité',
        community: 'Communauté'
      }
    },
    common: {
      learnMore: 'En Savoir Plus',
      contactUs: 'Contactez-nous',
      enroll: 'Inscrivez-vous',
      readMore: 'Lire la Suite',
      loading: 'Chargement...',
      error: 'Une erreur est survenue',
      success: 'Succès !',
      submit: 'Envoyer',
      cancel: 'Annuler',
      save: 'Enregistrer',
      delete: 'Supprimer',
      edit: 'Modifier',
      view: 'Voir',
      close: 'Fermer'
    }
  }
};

export const useTranslation = (language) => {
  return {
    t: (key) => {
      const keys = key.split('.');
      let value = translations[language];
      
      for (const k of keys) {
        if (value && value[k]) {
          value = value[k];
        } else {
          console.warn(`Translation missing for key: ${key} in language: ${language}`);
          return key;
        }
      }
      
      return value;
    }
  };
};