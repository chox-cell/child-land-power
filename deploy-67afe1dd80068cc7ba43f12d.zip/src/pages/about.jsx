import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaLeaf, FaGlobe, FaHeart, FaUsers } from 'react-icons/fa';

function About() {
  const navigate = useNavigate();

  const handleScheduleVisit = () => {
    navigate('/schedule-visit');
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-primary">
            About Childland
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Where sustainability meets education in a nurturing bilingual environment
          </p>
        </section>

        {/* Founder Section */}
        <section className="card mb-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold text-primary mb-4">Meet Our Founder</h2>
              <h3 className="text-xl font-bold text-accent mb-4">Mirlinda Veseli</h3>
              <div className="text-text-secondary space-y-4">
                <p>
                  With nearly a decade of experience in early childhood education, I am a Level 3 qualified practitioner who is deeply passionate about nurturing and supporting young children as they grow and develop. I began my journey as an apprentice and have since advanced through various roles, from Room Leader to Senior Practitioner.
                </p>
                <p>
                  Having worked in nurseries across both London and Scotland, I've been fortunate to work in diverse environments that have helped me refine my skills. My expertise lies in fostering creativity, enhancing communication, and solving challenges with a child-centred approach.
                </p>
                <p>
                  I believe that every child is unique, and I strive to create a nurturing and stimulating environment where each one feels safe, supported, and encouraged to explore their potential. The early years are such a crucial time for learning, and it's a privilege to be part of that journey.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?w=800&auto=format" 
                alt="Founder with children" 
                className="rounded-2xl w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </section>

        {/* Daily Schedule */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">Daily Schedule</h2>
          <div className="card">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">8:00 - 9:00</span>
                <span className="text-text-secondary">Welcoming children and Breakfast</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">9:00 - 9:30</span>
                <span className="text-text-secondary">Circle time - singing songs and reading</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">9:30 - 10:30</span>
                <span className="text-text-secondary">Garden and Planned activity</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">10:30 - 11:00</span>
                <span className="text-text-secondary">Snack</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">11:00 - 13:00</span>
                <span className="text-text-secondary">Local Walk, Quiet time and Free play</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">13:00 - 14:00</span>
                <span className="text-text-secondary">Lunch</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">14:00 - 15:30</span>
                <span className="text-text-secondary">Garden and Planned activity</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">15:30 - 16:00</span>
                <span className="text-text-secondary">Snack</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-primary font-bold">16:00 - 18:00</span>
                <span className="text-text-secondary">Free Play and pick up</span>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center">
          <h2 className="text-3xl font-bold text-primary mb-6">Join Our Community</h2>
          <p className="text-text-secondary mb-8 max-w-2xl mx-auto">
            Be part of our mission to raise eco-conscious, bilingual children who will shape 
            a better tomorrow.
          </p>
          <button 
            onClick={handleScheduleVisit}
            className="btn-primary"
          >
            Schedule a Visit
          </button>
        </section>
      </main>
    </div>
  );
}

export default About;