/*
  # Create Test Table with RLS
  
  1. Changes
    - Create test table with user_id reference
    - Enable RLS
    - Add policy for row-level access
  
  2. Security
    - Enable row level security
    - Add policy for authenticated users
*/

-- Create test table first
CREATE TABLE IF NOT EXISTS rls_test (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE rls_test ENABLE ROW LEVEL SECURITY;

-- Create policy for viewing records
CREATE POLICY "rls_test_select"
  ON rls_test
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);