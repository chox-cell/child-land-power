/*
  # Fix update_updated_at_column function
  
  1. Changes
    - Create a proper trigger function for updating updated_at column
    - Add security definer and search path settings
    - Add proper return type and parameters
  
  2. Notes
    - Function is SECURITY DEFINER to ensure it runs with proper permissions
    - Explicitly sets search_path for security
    - Returns TRIGGER type as required for trigger functions
*/

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- Add helpful comment
COMMENT ON FUNCTION public.update_updated_at_column() IS 'Trigger function to automatically update updated_at timestamp';