import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import { FaPaperPlane } from 'react-icons/fa';

function Messages({ session }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    let mounted = true;
    
    async function fetchMessages() {
      try {
        const { data, error } = await supabase
          .from('messages')
          .select('*')
          .or(`sender_id.eq.${session.user.id},receiver_id.eq.${session.user.id}`)
          .order('created_at', { ascending: true });

        if (error) throw error;
        if (mounted) {
          setMessages(data);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error:', error);
        if (mounted) {
          toast.error('Failed to load messages');
          setLoading(false);
        }
      }
    }

    fetchMessages();

    const subscription = supabase
      .channel('messages')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, payload => {
        if (payload.new.sender_id === session.user.id || payload.new.receiver_id === session.user.id) {
          setMessages(current => [...current, payload.new]);
        }
      })
      .subscribe();

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [session]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const { error } = await supabase
        .from('messages')
        .insert([
          {
            content: newMessage.trim(),
            sender_id: session.user.id,
            receiver_id: 'staff_id', // Replace with actual staff ID
          },
        ]);

      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to send message');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="card h-[600px] flex flex-col">
      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-8 text-text-light">
            No messages yet. Start a conversation!
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender_id === session.user.id ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[70%] p-3 rounded-xl ${
                  message.sender_id === session.user.id
                    ? 'bg-accent text-white'
                    : 'bg-gray-100 text-text'
                }`}
              >
                <p className="mb-1">{message.content}</p>
                <p className="text-xs opacity-70">
                  {format(new Date(message.created_at), 'p')}
                </p>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="input flex-1"
          />
          <button
            type="submit"
            className="btn-primary px-4"
          >
            <FaPaperPlane />
          </button>
        </div>
      </form>
    </div>
  );
}

export default Messages;