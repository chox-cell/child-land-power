/*
  # Update triggers and functions
  
  1. Functions
    - Recreate update_updated_at_column with proper search_path
  
  2. Triggers
    - Recreate triggers for eco_metrics and chats
*/

-- Drop existing triggers first
DROP TRIGGER IF EXISTS update_eco_metrics_updated_at ON eco_metrics;
DROP TRIGGER IF EXISTS update_chats_updated_at ON chats;

-- Drop existing functions
DROP FUNCTION IF EXISTS update_updated_at_column();
DROP FUNCTION IF EXISTS update_chat_updated_at();
DROP FUNCTION IF EXISTS update_eco_metrics_updated_at();

-- Recreate function with search_path
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate triggers
CREATE TRIGGER update_eco_metrics_updated_at
  BEFORE UPDATE ON eco_metrics
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chats_updated_at
  BEFORE UPDATE ON chats
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();