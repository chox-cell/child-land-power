-- Create profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  phone text,
  address text,
  role text CHECK (role IN ('parent', 'staff', 'admin')) DEFAULT 'parent',
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create restrictive policy for profile updates requiring AAL2
CREATE POLICY "Restrict updates to AAL2"
  ON profiles
  AS RESTRICTIVE
  FOR UPDATE
  TO authenticated
  USING ((auth.jwt()->>'aal')::text = 'aal2');

-- Add comment explaining the policy
COMMENT ON POLICY "Restrict updates to AAL2" ON profiles IS 
  'Requires AAL2 (higher authentication assurance level) for profile updates';

-- Add helpful comment
COMMENT ON TABLE profiles IS 'User profile information with row-level security and AAL2 requirement for updates';