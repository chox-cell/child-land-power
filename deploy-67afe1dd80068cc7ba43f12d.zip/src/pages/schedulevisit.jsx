import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaCalendarAlt, FaClock, FaUser, FaEnvelope, FaPhone, FaChild, FaComments } from 'react-icons/fa';
import { supabase } from '../lib/supabaseClient';
import toast from 'react-hot-toast';

function ScheduleVisit() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    numberOfChildren: '1',
    childrenAges: '',
    message: ''
  });

  const availableTimes = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('visit_requests')
        .insert([
          {
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            preferred_date: formData.preferredDate,
            preferred_time: formData.preferredTime,
            number_of_children: parseInt(formData.numberOfChildren),
            children_ages: formData.childrenAges,
            message: formData.message,
            status: 'pending'
          }
        ]);

      if (error) throw error;

      toast.success('Visit scheduled successfully! We will contact you to confirm.');
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to schedule visit. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Get tomorrow's date as minimum date for scheduling
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  // Get date 3 months from now as maximum date
  const maxDate = new Date();
  maxDate.setMonth(maxDate.getMonth() + 3);
  const maxDateStr = maxDate.toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Schedule a Visit
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Come see our eco-conscious childcare center and meet our dedicated team
          </p>
        </section>

        {/* Form Section */}
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20 space-y-6">
            {/* Contact Information */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-accent-light flex items-center gap-2">
                <FaUser />
                Contact Information
              </h2>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-accent-light mb-2">Full Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-accent-light mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-accent-light mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Visit Details */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-accent-light flex items-center gap-2">
                <FaCalendarAlt />
                Visit Details
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-accent-light mb-2">Preferred Date</label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({...formData, preferredDate: e.target.value})}
                    min={minDate}
                    max={maxDateStr}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none [color-scheme:dark]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-accent-light mb-2">Preferred Time</label>
                  <select
                    value={formData.preferredTime}
                    onChange={(e) => setFormData({...formData, preferredTime: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  >
                    <option value="">Select a time</option>
                    {availableTimes.map(time => (
                      <option key={time} value={time}>{time}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Children Information */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-accent-light flex items-center gap-2">
                <FaChild />
                Children Information
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-accent-light mb-2">Number of Children</label>
                  <select
                    value={formData.numberOfChildren}
                    onChange={(e) => setFormData({...formData, numberOfChildren: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  >
                    {[1, 2, 3, 4, 5].map(num => (
                      <option key={num} value={num}>{num}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-accent-light mb-2">Children's Ages</label>
                  <input
                    type="text"
                    value={formData.childrenAges}
                    onChange={(e) => setFormData({...formData, childrenAges: e.target.value})}
                    placeholder="e.g., 3, 4 years old"
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Additional Message */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-accent-light flex items-center gap-2">
                <FaComments />
                Additional Message
              </h2>

              <textarea
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                placeholder="Any specific questions or requirements?"
                className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                rows="4"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-accent to-accent-light text-primary-dark font-semibold py-4 px-8 rounded-xl text-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-primary-dark border-t-transparent"></div>
              ) : (
                <>
                  <FaCalendarAlt />
                  Schedule Visit
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ScheduleVisit;