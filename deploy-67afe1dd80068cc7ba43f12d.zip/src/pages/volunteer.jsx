import React, { useState } from 'react';
import { FaUser, FaEnvelope, FaPhone, FaClock, FaClipboard, FaHeart } from 'react-icons/fa';

function Volunteer() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    availability: [],
    interests: [],
    experience: '',
    message: ''
  });

  const availabilityOptions = [
    'Weekday Mornings',
    'Weekday Afternoons',
    'Weekday Evenings',
    'Weekends'
  ];

  const interestOptions = [
    'Teaching Assistant',
    'Garden Maintenance',
    'Event Planning',
    'Administrative Support',
    'Eco Projects'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-4 py-24">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-accent mb-8 text-center">Volunteer With Us</h1>
          
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-accent-light mb-2">
                    <FaUser className="inline-block mr-2" />
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-accent-light mb-2">
                    <FaEnvelope className="inline-block mr-2" />
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-accent-light mb-2">
                    <FaPhone className="inline-block mr-2" />
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-accent-light mb-2">
                    <FaClock className="inline-block mr-2" />
                    Availability
                  </label>
                  <div className="space-y-2">
                    {availabilityOptions.map(option => (
                      <label key={option} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={formData.availability.includes(option)}
                          onChange={(e) => {
                            const newAvailability = e.target.checked
                              ? [...formData.availability, option]
                              : formData.availability.filter(item => item !== option);
                            setFormData({...formData, availability: newAvailability});
                          }}
                          className="text-accent focus:ring-accent"
                        />
                        <span className="text-gray-300">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-accent-light mb-2">
                    <FaHeart className="inline-block mr-2" />
                    Areas of Interest
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {interestOptions.map(option => (
                      <label key={option} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={formData.interests.includes(option)}
                          onChange={(e) => {
                            const newInterests = e.target.checked
                              ? [...formData.interests, option]
                              : formData.interests.filter(item => item !== option);
                            setFormData({...formData, interests: newInterests});
                          }}
                          className="text-accent focus:ring-accent"
                        />
                        <span className="text-gray-300">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-accent-light mb-2">
                    <FaClipboard className="inline-block mr-2" />
                    Relevant Experience
                  </label>
                  <textarea
                    value={formData.experience}
                    onChange={(e) => setFormData({...formData, experience: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    rows="4"
                  ></textarea>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-accent-light mb-2">
                    Why do you want to volunteer with us?
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                    rows="4"
                    required
                  ></textarea>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-accent to-accent-light text-primary-dark font-semibold py-4 px-8 rounded-xl text-lg hover:opacity-90 transition-opacity"
              >
                Submit Application
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Volunteer;