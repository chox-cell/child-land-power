import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Elements } from '@stripe/react-stripe-js';
import { FaLock, FaShieldAlt } from 'react-icons/fa';
import toast from 'react-hot-toast';
import PaymentForm from '../components/PaymentForm';
import { stripePromise } from '../lib/stripe';

function Payment() {
  const navigate = useNavigate();
  const location = useLocation();
  const [clientSecret, setClientSecret] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Validate payment details
    if (!location.state?.type && !location.state?.plan) {
      toast.error('Invalid payment request');
      navigate('/');
      return;
    }

    // Create payment intent
    const createPaymentIntent = async () => {
      try {
        const response = await fetch('/api/create-payment-intent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amount: getAmount(),
            type: location.state?.type || 'subscription',
            plan: location.state?.plan
          }),
        });

        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (error) {
        console.error('Error:', error);
        toast.error('Failed to initialize payment');
      } finally {
        setLoading(false);
      }
    };

    createPaymentIntent();
  }, [location.state, navigate]);

  const getAmount = () => {
    if (location.state?.type === 'donation') {
      return location.state.amount || '0';
    }
    
    // Default plan amounts
    switch (location.state?.plan) {
      case 'full-time': return '800';
      case 'part-time': return '400';
      case 'drop-in': return '10';
      default: return '0';
    }
  };

  const getDescription = () => {
    if (location.state?.type === 'donation') {
      return 'Donation';
    }
    return `${location.state?.plan || 'Full-time'} Plan`;
  };

  if (loading || !clientSecret) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto">
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-3xl font-bold text-accent flex items-center gap-2">
                <FaLock className="text-accent" />
                Secure Payment
              </h1>
              <FaShieldAlt className="text-2xl text-accent" />
            </div>

            {/* Payment Summary */}
            <div className="bg-primary-dark/50 p-6 rounded-xl mb-8">
              <h2 className="text-xl font-bold text-accent-light mb-4">Payment Summary</h2>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-gray-300 capitalize">{getDescription()}</p>
                  <p className="text-sm text-gray-400 mt-1">One-time payment</p>
                </div>
                <span className="text-2xl font-bold text-accent">€{getAmount()}</span>
              </div>
            </div>

            {/* Stripe Elements */}
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <PaymentForm clientSecret={clientSecret} />
            </Elements>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-400">
                Your payment is secured with 256-bit encryption
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Payment;