/*
  # Update Profiles Schema and Policies

  1. Changes
    - Make phone and address fields nullable
    - Drop existing policies to avoid conflicts
    - Recreate policies with proper permissions
  
  2. Security
    - Maintain RLS
    - Keep authentication requirements
*/

-- Drop existing policies first to avoid conflicts
DROP POLICY IF EXISTS "Allow profile creation during registration" ON profiles;
DROP POLICY IF EXISTS "Allow users to view own profile" ON profiles;
DROP POLICY IF EXISTS "Allow users to update own profile" ON profiles;

-- Recreate profiles table with correct constraints
DROP TABLE IF EXISTS profiles;
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  phone text NULL, -- Make phone optional
  address text NULL, -- Make address optional for consistency
  role text CHECK (role IN ('parent', 'staff', 'admin')) DEFAULT 'parent',
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Enable profile creation"
  ON profiles
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Enable profile viewing"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Enable profile updates"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Add helpful comment
COMMENT ON TABLE profiles IS 'User profile information with row-level security';