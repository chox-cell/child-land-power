-- Create bucket metadata table
CREATE TABLE IF NOT EXISTS bucket_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bucket_id text NOT NULL REFERENCES storage.buckets(id) ON DELETE CASCADE,
  description text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE bucket_metadata ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_bucket_metadata_bucket_id ON bucket_metadata(bucket_id);

-- Create trigger for updated_at
CREATE TRIGGER update_bucket_metadata_updated_at
  BEFORE UPDATE ON bucket_metadata
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create policies
CREATE POLICY "Anyone can view bucket metadata"
  ON bucket_metadata
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can manage bucket metadata"
  ON bucket_metadata
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Insert initial metadata for existing buckets
INSERT INTO bucket_metadata (bucket_id, description, metadata)
VALUES
  ('avatars', 'User profile photos and avatars', jsonb_build_object(
    'purpose', 'profile_images',
    'max_file_size', 5242880,
    'allowed_types', ARRAY['image/jpeg', 'image/png', 'image/gif']
  )),
  ('activities', 'Activity photos and documents', jsonb_build_object(
    'purpose', 'activity_content',
    'max_file_size', 10485760,
    'allowed_types', ARRAY['image/jpeg', 'image/png', 'image/gif', 'application/pdf']
  )),
  ('resources', 'Educational resources and materials', jsonb_build_object(
    'purpose', 'educational_content',
    'max_file_size', 20971520,
    'allowed_types', ARRAY['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'video/mp4', 'audio/mpeg']
  )),
  ('public', 'Publicly accessible assets', jsonb_build_object(
    'purpose', 'public_assets',
    'max_file_size', 5242880,
    'allowed_types', ARRAY['image/jpeg', 'image/png', 'image/gif']
  ))
ON CONFLICT (bucket_id) DO UPDATE
SET 
  description = EXCLUDED.description,
  metadata = bucket_metadata.metadata || EXCLUDED.metadata;

-- Add helpful comments
COMMENT ON TABLE bucket_metadata IS 'Metadata and configuration for storage buckets';
COMMENT ON COLUMN bucket_metadata.bucket_id IS 'Reference to storage bucket';
COMMENT ON COLUMN bucket_metadata.description IS 'Human-readable description of bucket purpose';
COMMENT ON COLUMN bucket_metadata.metadata IS 'Additional bucket configuration and metadata';