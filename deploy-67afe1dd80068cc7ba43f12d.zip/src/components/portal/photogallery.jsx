import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

function PhotoGallery({ session }) {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState(null);

  useEffect(() => {
    fetchPhotos();
  }, [session]);

  async function fetchPhotos() {
    try {
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('parent_id', session.user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPhotos(data);
    } catch (error) {
      toast.error('Error loading photos');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {photos.length === 0 ? (
          <div className="col-span-full text-center py-8 text-gray-400">
            No photos uploaded yet
          </div>
        ) : (
          photos.map((photo) => (
            <div
              key={photo.id}
              className="relative group cursor-pointer"
              onClick={() => setSelectedPhoto(photo)}
            >
              <div className="aspect-square overflow-hidden rounded-xl">
                <img
                  src={photo.url}
                  alt={photo.description}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-end">
                <div className="p-4 w-full">
                  <p className="text-white text-sm truncate">
                    {photo.description}
                  </p>
                  <p className="text-gray-300 text-xs">
                    {format(new Date(photo.created_at), 'PP')}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Photo Modal */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedPhoto(null)}
        >
          <div
            className="max-w-4xl w-full bg-primary-dark rounded-xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.description}
              className="w-full h-auto"
            />
            <div className="p-4">
              <p className="text-white mb-2">{selectedPhoto.description}</p>
              <p className="text-gray-400 text-sm">
                {format(new Date(selectedPhoto.created_at), 'PPp')}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default PhotoGallery;