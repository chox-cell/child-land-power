/*
  # Update timestamp function improvements
  
  1. Changes
    - Add SECURITY DEFINER to run with owner privileges
    - Set explicit search_path for security
    - Add VOLATILE marker since function modifies database
    - Add parameter name for clarity
    - Add STRICT marker to handle NULL values
    - Add proper error handling
  
  2. Security
    - Restricted search_path prevents search_path attacks
    - SECURITY DEFINER ensures consistent permissions
    - Explicit schema qualification improves security
*/

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
VOLATILE
STRICT
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW IS NULL THEN
    RAISE EXCEPTION 'Cannot update with null NEW row';
  END IF;
  
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- Add helpful comment
COMMENT ON FUNCTION public.update_updated_at_column() IS 'Trigger function to automatically update updated_at timestamp';