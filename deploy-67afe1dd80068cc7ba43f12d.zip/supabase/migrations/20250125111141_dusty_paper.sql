/*
  # Configure Authentication Settings
  
  1. Changes
    - Create function to manage auth settings
    - Set OTP expiry to 1 hour (3600 seconds)
    - Enable secure email change
  
  2. Notes
    - Uses custom functions since direct auth schema access is restricted
    - Settings will be applied through Supabase's auth API
*/

-- Create a function to track auth configuration version
CREATE TABLE IF NOT EXISTS public.auth_configuration (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    version integer NOT NULL DEFAULT 1,
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.auth_configuration ENABLE ROW LEVEL SECURITY;

-- Create policy for admins
CREATE POLICY "Only admins can manage auth configuration"
    ON public.auth_configuration
    FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE auth.uid() = id
            AND raw_user_meta_data->>'is_admin' = 'true'
        )
    );

-- Insert initial configuration
INSERT INTO public.auth_configuration (settings)
VALUES (
    jsonb_build_object(
        'otp_expiry_seconds', 3600,
        'secure_email_change_enabled', true
    )
)
ON CONFLICT DO NOTHING;

-- Add updated_at trigger
CREATE TRIGGER update_auth_configuration_updated_at
    BEFORE UPDATE ON public.auth_configuration
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Add helpful comment
COMMENT ON TABLE public.auth_configuration IS 'Tracks authentication configuration settings';