import React, { useState } from 'react';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaPaperPlane, FaClock, FaGlobe } from 'react-icons/fa';
import { motion } from 'framer-motion';
import { emailConfig } from '../config/email';

function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-primary">
            Contact Us
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            We'd love to hear from you! Get in touch with any questions about our programs.
          </p>
        </section>

        {/* Map Section */}
        <section className="mb-16">
          <div className="card">
            <div className="aspect-[16/9] w-full mb-6 rounded-xl overflow-hidden">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d42386.79255087553!2d1.8853921771484375!3d47.902488799999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e4e4d77fb7f0bd%3A0xe2088691e5f5b90b!2sOrl%C3%A9ans%2C%20France!5e0!3m2!1sen!2sus!4v1709669047974!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Childland Location"
              ></iframe>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <FaMapMarkerAlt className="text-4xl text-accent mb-4 mx-auto" />
                <h3 className="text-xl font-bold text-primary mb-2">Address</h3>
                <p className="text-text-secondary">123 Rue de la République</p>
                <p className="text-text-secondary">45000 Orléans, France</p>
                <a
                  href="https://maps.google.com/?q=Orleans,France"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:text-accent-light mt-2 inline-block"
                >
                  Get Directions →
                </a>
              </div>

              <div className="text-center">
                <FaClock className="text-4xl text-accent mb-4 mx-auto" />
                <h3 className="text-xl font-bold text-primary mb-2">Hours</h3>
                <div className="space-y-1">
                  <p className="text-text-secondary">
                    <span className="font-semibold">Monday - Friday:</span>
                    <br />8:00 AM - 6:00 PM
                  </p>
                  <p className="text-text-secondary">
                    <span className="font-semibold">Saturday - Sunday:</span>
                    <br />Closed
                  </p>
                </div>
              </div>

              <div className="text-center">
                <FaGlobe className="text-4xl text-accent mb-4 mx-auto" />
                <h3 className="text-xl font-bold text-primary mb-2">Contact</h3>
                <p className="text-text-secondary mb-2">
                  <FaPhone className="inline-block mr-2" />
                  +33 2 38 XX XX XX
                </p>
                <p className="text-text-secondary">
                  <FaEnvelope className="inline-block mr-2" />
                  <a
                    href={`mailto:${emailConfig.adminEmail}`}
                    className="text-accent hover:text-accent-light"
                  >
                    {emailConfig.adminEmail}
                  </a>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <section className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card"
          >
            <h2 className="text-2xl font-bold text-primary mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-text-secondary mb-2">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="input w-full"
                  required
                />
              </div>
              
              <div>
                <label className="block text-text-secondary mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="input w-full"
                  required
                />
              </div>

              <div>
                <label className="block text-text-secondary mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="input w-full"
                  rows="4"
                  required
                ></textarea>
              </div>

              <button
                type="submit"
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                <FaPaperPlane />
                Send Message
              </button>
            </form>
          </motion.div>
        </section>

        {/* Additional Information */}
        <section className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-primary mb-8">Visit Our Center</h2>
          <p className="text-text-secondary max-w-2xl mx-auto mb-6">
            We welcome you to visit our eco-conscious bilingual childcare center. 
            Schedule a tour to see our facilities and meet our dedicated team.
          </p>
          <button
            onClick={() => window.location.href = '/schedule-visit'}
            className="btn-primary"
          >
            Schedule a Visit
          </button>
        </section>
      </main>
    </div>
  );
}

export default Contact;