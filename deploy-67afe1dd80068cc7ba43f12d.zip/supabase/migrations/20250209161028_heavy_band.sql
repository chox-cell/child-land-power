/*
  # Fix Authentication System

  1. Changes
    - Drop existing profiles table and policies
    - Recreate profiles table with correct constraints
    - Set up proper RLS policies
    - Make phone and address optional
  
  2. Security
    - Enable RLS
    - Allow profile creation during registration
    - Restrict profile access to authenticated users
*/

-- Drop existing table and policies
DROP TABLE IF EXISTS profiles CASCADE;

-- Create profiles table with correct constraints
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  address text,
  role text NOT NULL CHECK (role IN ('parent', 'staff', 'admin')) DEFAULT 'parent',
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable public profile creation"
  ON profiles
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Enable own profile viewing"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Enable own profile updates"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Add helpful comment
COMMENT ON TABLE profiles IS 'User profile information with row-level security';