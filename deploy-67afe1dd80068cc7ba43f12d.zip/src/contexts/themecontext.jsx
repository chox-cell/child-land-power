import React from 'react';

export function ThemeProvider({ children }) {
  return children;
}

export const useTheme = () => {
  return { isDark: false };
};