/*
  # Parent Portal Schema

  1. New Tables
    - `activities`
      - `id` (uuid, primary key)
      - `parent_id` (uuid, references auth.users)
      - `child_id` (uuid, references children)
      - `title` (text)
      - `description` (text)
      - `metrics` (jsonb)
      - `created_at` (timestamptz)
    
    - `photos`
      - `id` (uuid, primary key)
      - `parent_id` (uuid, references auth.users)
      - `child_id` (uuid, references children)
      - `url` (text)
      - `description` (text)
      - `created_at` (timestamptz)
    
    - `messages`
      - `id` (uuid, primary key)
      - `sender_id` (uuid, references auth.users)
      - `receiver_id` (uuid, references auth.users)
      - `content` (text)
      - `created_at` (timestamptz)
    
    - `children`
      - `id` (uuid, primary key)
      - `parent_id` (uuid, references auth.users)
      - `name` (text)
      - `date_of_birth` (date)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Create children table
CREATE TABLE IF NOT EXISTS children (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  date_of_birth date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create activities table
CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  child_id uuid REFERENCES children NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  metrics jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create photos table
CREATE TABLE IF NOT EXISTS photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  child_id uuid REFERENCES children NOT NULL,
  url text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users NOT NULL,
  receiver_id uuid REFERENCES auth.users NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE children ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create policies for children table
CREATE POLICY "Parents can view their own children"
  ON children
  FOR SELECT
  TO authenticated
  USING (auth.uid() = parent_id);

-- Create policies for activities table
CREATE POLICY "Parents can view their children's activities"
  ON activities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = parent_id);

-- Create policies for photos table
CREATE POLICY "Parents can view their children's photos"
  ON photos
  FOR SELECT
  TO authenticated
  USING (auth.uid() = parent_id);

-- Create policies for messages table
CREATE POLICY "Users can view their own messages"
  ON messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);