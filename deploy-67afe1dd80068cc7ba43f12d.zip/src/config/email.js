export const emailConfig = {
  adminEmail: 'care@childland.fr',
  supportEmail: 'care@childland.fr',
  noReplyEmail: 'no-reply@childland.fr',
  emailTemplates: {
    welcome: {
      subject: 'Welcome to Childland!',
      from: 'care@childland.fr'
    },
    visitRequest: {
      subject: 'New Visit Request - Childland',
      from: 'care@childland.fr'
    },
    registration: {
      subject: 'Registration Confirmation - Childland',
      from: 'care@childland.fr'
    },
    payment: {
      subject: 'Payment Confirmation - Childland',
      from: 'care@childland.fr'
    }
  }
};