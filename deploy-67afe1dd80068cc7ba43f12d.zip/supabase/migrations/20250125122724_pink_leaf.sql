-- Create a new role for system operations
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_catalog.pg_roles WHERE rolname = 'custom_service_role'
  ) THEN
    CREATE ROLE custom_service_role WITH NOLOGIN BYPASSRLS;
  END IF;
END $$;

-- Add comment explaining the role
COMMENT ON ROLE custom_service_role IS 'Custom role with bypassrls privilege for system operations';