import React, { useState } from 'react';
import { FaQuoteLeft, FaStar, FaPaperPlane, FaChild, FaHeart } from 'react-icons/fa';

function Testimonials() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    relationship: 'parent',
    rating: 5,
    testimonial: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Form submission logic would go here
    console.log('Testimonial submitted:', formData);
  };

  const testimonials = [
    {
      id: 1,
      name: "Emma L.",
      relationship: "Parent",
      text: "Childland has transformed my daughter's understanding of environmental responsibility. She now teaches us about recycling at home!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1543342384-1f1350e27861?w=400&auto=format"
    },
    {
      id: 2,
      name: "Thomas M.",
      relationship: "Parent",
      text: "The bilingual environment is incredible. My son switches effortlessly between French and English, and his love for nature has blossomed.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1543341777-25a1fb3f0589?w=400&auto=format"
    },
    {
      id: 3,
      name: "Sophie R.",
      relationship: "Parent",
      text: "The dedication to sustainability while maintaining excellent education standards is remarkable. My children love the garden activities!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=400&auto=format"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white relative overflow-hidden">
      {/* Floating Spheres */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-sphere rounded-full blur-xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-sphere rounded-full blur-xl animate-pulse delay-1000"></div>
      
      <main className="relative z-10 container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Parent Testimonials
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Hear from our wonderful community of parents and children
          </p>
        </section>

        {/* Featured Testimonials */}
        <section className="mb-20">
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20 hover:border-accent/40 transition-all">
                <div className="relative w-24 h-24 mx-auto mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-full h-full object-cover rounded-full border-2 border-accent"
                  />
                  <FaQuoteLeft className="absolute -bottom-2 -right-2 text-3xl text-accent" />
                </div>
                <div className="flex justify-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <FaStar key={i} className="text-accent mx-0.5" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4 italic">"{testimonial.text}"</p>
                <div className="text-center">
                  <p className="font-semibold text-accent-light">{testimonial.name}</p>
                  <p className="text-sm text-gray-400">{testimonial.relationship}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Child Testimonials */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-accent text-center mb-8">From Our Little Ones</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-2xl border border-accent/20">
              <FaChild className="text-4xl text-accent mb-4 mx-auto" />
              <p className="text-gray-300 text-center italic mb-2">
                "I love planting seeds in our garden and watching them grow!"
              </p>
              <p className="text-center text-accent-light">- Lucas, Age 5</p>
            </div>
            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-2xl border border-accent/20">
              <FaHeart className="text-4xl text-accent mb-4 mx-auto" />
              <p className="text-gray-300 text-center italic mb-2">
                "Making art with recycled things is my favorite!"
              </p>
              <p className="text-center text-accent-light">- Marie, Age 4</p>
            </div>
          </div>
        </section>

        {/* Submit Testimonial Form */}
        <section className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold text-accent text-center mb-8">Share Your Experience</h2>
          <form onSubmit={handleSubmit} className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <div className="mb-6">
              <label htmlFor="name" className="block text-accent-light mb-2">Name</label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                required
              />
            </div>
            
            <div className="mb-6">
              <label htmlFor="email" className="block text-accent-light mb-2">Email</label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                required
              />
            </div>

            <div className="mb-6">
              <label htmlFor="relationship" className="block text-accent-light mb-2">I am a...</label>
              <select
                id="relationship"
                value={formData.relationship}
                onChange={(e) => setFormData({...formData, relationship: e.target.value})}
                className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
              >
                <option value="parent">Parent</option>
                <option value="guardian">Guardian</option>
                <option value="family">Family Member</option>
              </select>
            </div>

            <div className="mb-6">
              <label htmlFor="rating" className="block text-accent-light mb-2">Rating</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setFormData({...formData, rating})}
                    className={`p-2 rounded-full transition-colors ${
                      formData.rating >= rating ? 'text-accent' : 'text-gray-500'
                    }`}
                  >
                    <FaStar />
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <label htmlFor="testimonial" className="block text-accent-light mb-2">Your Testimonial</label>
              <textarea
                id="testimonial"
                value={formData.testimonial}
                onChange={(e) => setFormData({...formData, testimonial: e.target.value})}
                className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                rows="4"
                required
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-accent to-accent-light text-primary-dark font-semibold py-4 px-8 rounded-xl text-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              <FaPaperPlane />
              Submit Testimonial
            </button>
          </form>
        </section>
      </main>
    </div>
  );
}

export default Testimonials;