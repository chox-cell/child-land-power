import React, { useState } from 'react';
import { FaRecycle, FaSeedling, FaWater, FaSun } from 'react-icons/fa';

function EcoTracker() {
  const [timeframe, setTimeframe] = useState('month');

  const metrics = {
    waste_reduced: { value: 0, unit: 'kg', description: 'Total waste diverted from landfills' },
    trees_planted: { value: 0, unit: 'trees', description: 'New trees planted in our garden' },
    water_saved: { value: 0, unit: 'L', description: 'Water conserved through efficient practices' },
    energy_saved: { value: 0, unit: 'kWh', description: 'Energy saved through conservation' }
  };

  const goals = [
    { name: 'Waste Reduction Goal', progress: 75 },
    { name: 'Energy Conservation Goal', progress: 60 }
  ];

  return (
    <div className="bg-background p-8 rounded-2xl">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-accent flex items-center gap-2">
          <FaSeedling className="text-2xl" />
          Eco Impact Tracker
        </h2>
        
        <div className="flex gap-2">
          {['week', 'month', 'year'].map((period) => (
            <button
              key={period}
              onClick={() => setTimeframe(period)}
              className={`px-4 py-2 rounded-lg transition-colors ${
                timeframe === period
                  ? 'bg-accent text-background'
                  : 'bg-background-dark text-white hover:bg-background-darker'
              }`}
            >
              {period.charAt(0).toUpperCase() + period.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {Object.entries(metrics).map(([key, data], index) => {
          const Icon = [FaRecycle, FaSeedling, FaWater, FaSun][index];
          return (
            <div key={key} className="bg-background-dark p-6 rounded-xl">
              <Icon className="text-3xl text-accent mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                {key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
              </h3>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-4xl font-bold text-accent">{data.value}</span>
                <span className="text-gray-400">{data.unit}</span>
              </div>
              <p className="text-sm text-gray-400">{data.description}</p>
            </div>
          );
        })}
      </div>

      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Monthly Goals</h3>
        <div className="space-y-4">
          {goals.map((goal) => (
            <div key={goal.name} className="bg-background-dark p-4 rounded-xl">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300">{goal.name}</span>
                <span className="text-accent">{goal.progress}%</span>
              </div>
              <div className="h-2 bg-background-darker rounded-full overflow-hidden">
                <div 
                  className="h-full bg-accent transition-all duration-500" 
                  style={{ width: `${goal.progress}%` }} 
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default EcoTracker;