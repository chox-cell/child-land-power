import React, { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { FaSave, FaTimes } from 'react-icons/fa';
import toast from 'react-hot-toast';

function MetricsUpdateForm({ currentMetrics, onClose, onUpdate }) {
  const [formData, setFormData] = useState({
    waste_reduced: currentMetrics?.waste_reduced || 0,
    trees_planted: currentMetrics?.trees_planted || 0,
    water_saved: currentMetrics?.water_saved || 0,
    energy_saved: currentMetrics?.energy_saved || 0,
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const { data, error } = await supabase
        .from('eco_metrics')
        .insert([
          {
            ...formData,
            date: new Date().toISOString(),
          }
        ]);

      if (error) throw error;

      toast.success('Metrics updated successfully');
      onUpdate(data[0]);
      onClose();
    } catch (error) {
      toast.error('Error updating metrics');
      console.error('Error:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <div className="bg-primary-dark rounded-2xl p-8 max-w-md w-full">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-accent">Update Eco Metrics</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <FaTimes />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-accent-light mb-2">
              Waste Reduced (kg)
            </label>
            <input
              type="number"
              value={formData.waste_reduced}
              onChange={(e) => setFormData({
                ...formData,
                waste_reduced: parseFloat(e.target.value)
              })}
              className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
              min="0"
              step="0.1"
            />
          </div>

          <div>
            <label className="block text-accent-light mb-2">
              Trees Planted
            </label>
            <input
              type="number"
              value={formData.trees_planted}
              onChange={(e) => setFormData({
                ...formData,
                trees_planted: parseInt(e.target.value)
              })}
              className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
              min="0"
            />
          </div>

          <div>
            <label className="block text-accent-light mb-2">
              Water Saved (L)
            </label>
            <input
              type="number"
              value={formData.water_saved}
              onChange={(e) => setFormData({
                ...formData,
                water_saved: parseFloat(e.target.value)
              })}
              className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
              min="0"
              step="0.1"
            />
          </div>

          <div>
            <label className="block text-accent-light mb-2">
              Energy Saved (kWh)
            </label>
            <input
              type="number"
              value={formData.energy_saved}
              onChange={(e) => setFormData({
                ...formData,
                energy_saved: parseFloat(e.target.value)
              })}
              className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
              min="0"
              step="0.1"
            />
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="flex-1 bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
            >
              <FaSave />
              Save Changes
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 border border-accent text-accent px-6 py-3 rounded-xl hover:bg-accent hover:text-primary-dark transition-colors flex items-center justify-center gap-2"
            >
              <FaTimes />
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default MetricsUpdateForm;