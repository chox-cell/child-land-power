import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaStar, FaCheck, FaDownload, FaPlus } from 'react-icons/fa';
import { supabase } from '../../lib/supabaseClient';
import toast from 'react-hot-toast';

function MilestoneTracker({ childId }) {
  const [milestones, setMilestones] = useState([]);
  const [achievedMilestones, setAchievedMilestones] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMilestones();
    fetchAchievedMilestones();
  }, [childId]);

  const fetchMilestones = async () => {
    try {
      const { data, error } = await supabase
        .from('milestones')
        .select('*')
        .order('age_range_start');

      if (error) throw error;
      setMilestones(data);
    } catch (error) {
      console.error('Error fetching milestones:', error);
      toast.error('Failed to load milestones');
    }
  };

  const fetchAchievedMilestones = async () => {
    try {
      const { data, error } = await supabase
        .from('child_milestones')
        .select('*')
        .eq('child_id', childId);

      if (error) throw error;
      setAchievedMilestones(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching achieved milestones:', error);
      toast.error('Failed to load progress');
      setLoading(false);
    }
  };

  const markMilestoneAchieved = async (milestoneId) => {
    try {
      const { error } = await supabase
        .from('child_milestones')
        .insert([
          {
            child_id: childId,
            milestone_id: milestoneId,
            achieved_at: new Date().toISOString()
          }
        ]);

      if (error) throw error;
      
      toast.success('Milestone recorded!');
      fetchAchievedMilestones();
    } catch (error) {
      console.error('Error recording milestone:', error);
      toast.error('Failed to record milestone');
    }
  };

  const downloadGuide = async (category) => {
    try {
      const { data, error } = await supabase
        .from('milestone_resources')
        .select('*')
        .eq('resource_type', 'guide')
        .eq('category', category)
        .single();

      if (error) throw error;

      // In a real app, this would download a PDF
      toast.success('Guide downloaded successfully');
    } catch (error) {
      console.error('Error downloading guide:', error);
      toast.error('Failed to download guide');
    }
  };

  const categories = [
    { id: 'all', label: 'All Milestones' },
    { id: 'language', label: 'Language' },
    { id: 'cognitive', label: 'Cognitive' },
    { id: 'physical', label: 'Physical' },
    { id: 'social', label: 'Social' }
  ];

  const filteredMilestones = milestones.filter(milestone => 
    selectedCategory === 'all' || milestone.category === selectedCategory
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Category Filter */}
      <div className="flex flex-wrap gap-4">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-4 py-2 rounded-xl transition-colors ${
              selectedCategory === category.id
                ? 'bg-accent text-primary-dark'
                : 'bg-primary-dark/50 text-accent hover:bg-primary-dark/70'
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>

      {/* Milestone Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        {filteredMilestones.map(milestone => {
          const isAchieved = achievedMilestones.some(
            am => am.milestone_id === milestone.id
          );

          return (
            <motion.div
              key={milestone.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-primary/30 backdrop-blur-lg p-6 rounded-xl border ${
                isAchieved ? 'border-accent' : 'border-accent/20'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-accent-light">
                    {milestone.title}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {milestone.age_range_start}-{milestone.age_range_end} months
                  </p>
                </div>
                {milestone.importance === 'essential' && (
                  <FaStar className="text-accent" />
                )}
              </div>

              <p className="text-gray-300 mb-4">{milestone.description}</p>

              <div className="flex justify-between items-center">
                {isAchieved ? (
                  <span className="flex items-center gap-2 text-accent">
                    <FaCheck />
                    Achieved
                  </span>
                ) : (
                  <button
                    onClick={() => markMilestoneAchieved(milestone.id)}
                    className="flex items-center gap-2 text-accent hover:text-accent-light transition-colors"
                  >
                    <FaPlus />
                    Mark as Achieved
                  </button>
                )}

                <button
                  onClick={() => downloadGuide(milestone.category)}
                  className="flex items-center gap-2 text-gray-400 hover:text-accent transition-colors"
                >
                  <FaDownload />
                  Resources
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Progress Summary */}
      <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
        <h3 className="text-xl font-bold text-accent-light mb-4">
          Development Progress
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.slice(1).map(category => {
            const categoryMilestones = milestones.filter(
              m => m.category === category.id
            );
            const achievedCount = achievedMilestones.filter(am =>
              categoryMilestones.some(m => m.id === am.milestone_id)
            ).length;
            const percentage = categoryMilestones.length
              ? Math.round((achievedCount / categoryMilestones.length) * 100)
              : 0;

            return (
              <div key={category.id} className="text-center">
                <p className="text-accent-light font-semibold mb-2">
                  {category.label}
                </p>
                <div className="relative pt-1">
                  <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-primary-dark">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${percentage}%` }}
                      transition={{ duration: 1 }}
                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-accent"
                    />
                  </div>
                </div>
                <p className="text-gray-300">
                  {achievedCount} / {categoryMilestones.length}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default MilestoneTracker;