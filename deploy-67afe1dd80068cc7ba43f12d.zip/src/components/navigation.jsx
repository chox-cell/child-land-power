import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaLeaf, FaBars, FaTimes, FaChild, FaChevronDown, FaPhone } from 'react-icons/fa';

function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const menuItems = [
    { path: '/about', label: 'About Us' },
    { path: '/programs', label: 'Our Programs' },
    { path: '/sustainability', label: 'Eco Initiative' },
    { path: '/admissions', label: 'Admissions' },
    { path: '/blog', label: 'Blog' },
    { path: '/virtual-tour', label: 'Virtual Tour' },
    { 
      path: '/contact', 
      label: 'Contact Us',
      icon: <FaPhone className="inline-block mr-2" />
    }
  ];

  const handlePortalClick = () => {
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-soft sticky top-0 z-50">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <FaLeaf className="text-2xl text-accent" />
            <span className="text-xl font-bold text-primary">Childland</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            {/* Menu Dropdown */}
            <div className="relative group">
              <button className="btn-secondary flex items-center gap-2">
                <FaBars />
                Menu
                <FaChevronDown className="group-hover:rotate-180 transition-transform" />
              </button>

              {/* Dropdown Menu */}
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-border opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                {menuItems.map(item => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="block px-4 py-2 text-text-secondary hover:text-primary hover:bg-gray-50 transition-colors"
                  >
                    {item.icon}{item.label}
                  </Link>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <Link 
              to="/register-child" 
              className="btn-primary flex items-center gap-2"
            >
              <FaChild />
              Register Child
            </Link>
            <button 
              onClick={handlePortalClick}
              className="btn-secondary"
            >
              Parent Portal
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-primary hover:text-accent transition-colors"
          >
            {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden py-4 space-y-2">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className="block text-text-secondary hover:text-primary py-2 transition-colors"
              >
                {item.icon}{item.label}
              </Link>
            ))}

            {/* Mobile Action Buttons */}
            <Link
              to="/register-child"
              onClick={() => setIsOpen(false)}
              className="block btn-primary text-center flex items-center gap-2 justify-center mt-4"
            >
              <FaChild />
              Register Child
            </Link>
            <button
              onClick={() => {
                setIsOpen(false);
                handlePortalClick();
              }}
              className="block btn-secondary text-center mt-2 w-full"
            >
              Parent Portal
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navigation;