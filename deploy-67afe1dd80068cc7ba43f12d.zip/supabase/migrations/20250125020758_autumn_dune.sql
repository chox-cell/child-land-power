/*
  # Create chat functionality tables
  
  1. New Tables
    - chats table for managing chat sessions
    - chat_messages table for storing messages
  2. Security
    - Enable RLS
    - Add policies for chat access
  3. Automation
    - Add trigger for updating timestamps
*/

-- Create chats table if not exists
CREATE TABLE IF NOT EXISTS chats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create chat_messages table if not exists
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id uuid REFERENCES chats NOT NULL,
  sender_type text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_chat_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_chats_updated_at
  BEFORE UPDATE ON chats
  FOR EACH ROW
  EXECUTE FUNCTION update_chat_updated_at();

-- Create policies for chats
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chats' 
    AND policyname = 'Public chat access'
  ) THEN
    CREATE POLICY "Public chat access"
      ON chats
      FOR ALL
      TO public
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for chat_messages
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_messages' 
    AND policyname = 'Public chat messages access'
  ) THEN
    CREATE POLICY "Public chat messages access"
      ON chat_messages
      FOR ALL
      TO public
      USING (
        EXISTS (
          SELECT 1 FROM chats
          WHERE id = chat_id
          AND status = 'active'
        )
      )
      WITH CHECK (
        EXISTS (
          SELECT 1 FROM chats
          WHERE id = chat_id
          AND status = 'active'
        )
      );
  END IF;
END $$;