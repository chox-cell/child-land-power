-- Create auth_configuration table if it doesn't exist
CREATE TABLE IF NOT EXISTS auth_configuration (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    version integer NOT NULL DEFAULT 1,
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE auth_configuration ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Only admins can manage auth configuration" ON auth_configuration;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create policy for admins
CREATE POLICY "Only admins can manage auth configuration"
    ON auth_configuration
    FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE auth.uid() = id
            AND raw_user_meta_data->>'is_admin' = 'true'
        )
    );

-- Insert initial configuration if not exists
INSERT INTO auth_configuration (settings)
SELECT jsonb_build_object(
    'otp_expiry_seconds', 1800,
    'secure_email_change_enabled', true,
    'email_confirmations_enabled', false
)
WHERE NOT EXISTS (SELECT 1 FROM auth_configuration);

-- Add updated_at trigger if it doesn't exist
DO $$ 
BEGIN
    CREATE TRIGGER update_auth_configuration_updated_at
        BEFORE UPDATE ON auth_configuration
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Add helpful comment
COMMENT ON TABLE auth_configuration IS 'Tracks authentication configuration settings';