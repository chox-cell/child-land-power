/*
  # Complete Database Schema Setup

  1. Tables
    - auth.users (enable RLS and add policies)
    - children (for storing child information)
    - activities (for tracking daily activities)
    - photos (for storing photo gallery)
    - messages (for parent-staff communication)

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for data access
    - Set up user profile management

  3. Changes
    - Consolidate all migrations into a single file
    - Add proper error handling with IF EXISTS/IF NOT EXISTS
    - Ensure clean installation
*/

-- Enable RLS on auth.users
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create children table
CREATE TABLE IF NOT EXISTS children (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  date_of_birth date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create activities table
CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  child_id uuid REFERENCES children NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  metrics jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create photos table
CREATE TABLE IF NOT EXISTS photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  child_id uuid REFERENCES children NOT NULL,
  url text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users NOT NULL,
  receiver_id uuid REFERENCES auth.users NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE children ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create policies for children table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'children' 
    AND policyname = 'Parents can view their own children'
  ) THEN
    CREATE POLICY "Parents can view their own children"
      ON children
      FOR SELECT
      TO authenticated
      USING (auth.uid() = parent_id);
  END IF;
END $$;

-- Create policies for activities table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'activities' 
    AND policyname = 'Parents can view their children''s activities'
  ) THEN
    CREATE POLICY "Parents can view their children's activities"
      ON activities
      FOR SELECT
      TO authenticated
      USING (auth.uid() = parent_id);
  END IF;
END $$;

-- Create policies for photos table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'photos' 
    AND policyname = 'Parents can view their children''s photos'
  ) THEN
    CREATE POLICY "Parents can view their children's photos"
      ON photos
      FOR SELECT
      TO authenticated
      USING (auth.uid() = parent_id);
  END IF;
END $$;

-- Create policies for messages table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'messages' 
    AND policyname = 'Users can view their own messages'
  ) THEN
    CREATE POLICY "Users can view their own messages"
      ON messages
      FOR SELECT
      TO authenticated
      USING (auth.uid() = sender_id OR auth.uid() = receiver_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'messages' 
    AND policyname = 'Users can send messages'
  ) THEN
    CREATE POLICY "Users can send messages"
      ON messages
      FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = sender_id);
  END IF;
END $$;

-- Create policies for auth.users
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND schemaname = 'auth' 
    AND policyname = 'Users can view own profile'
  ) THEN
    CREATE POLICY "Users can view own profile"
      ON auth.users
      FOR SELECT
      TO authenticated
      USING (auth.uid() = id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND schemaname = 'auth' 
    AND policyname = 'Users can update own profile'
  ) THEN
    CREATE POLICY "Users can update own profile"
      ON auth.users
      FOR UPDATE
      TO authenticated
      USING (auth.uid() = id);
  END IF;
END $$;