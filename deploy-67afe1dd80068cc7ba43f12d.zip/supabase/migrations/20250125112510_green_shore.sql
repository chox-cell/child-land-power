/*
  # Child Development Milestone Schema

  1. New Tables
    - `milestones`
      - Standard developmental milestones by age
      - Categories: language, cognitive, physical, social
    - `child_milestones`
      - Track individual child's milestone achievements
    - `milestone_resources`
      - Educational resources and activities for each milestone

  2. Security
    - Enable RLS
    - Add policies for parent access
*/

-- Create milestones table
CREATE TABLE IF NOT EXISTS milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL CHECK (category IN ('language', 'cognitive', 'physical', 'social')),
  age_range_start integer NOT NULL CHECK (age_range_start >= 0),
  age_range_end integer NOT NULL CHECK (age_range_end >= age_range_start),
  importance text NOT NULL CHECK (importance IN ('essential', 'significant', 'supportive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create child_milestones table
CREATE TABLE IF NOT EXISTS child_milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid REFERENCES children NOT NULL,
  milestone_id uuid REFERENCES milestones NOT NULL,
  achieved_at timestamptz NOT NULL,
  notes text,
  media_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(child_id, milestone_id)
);

-- Create milestone_resources table
CREATE TABLE IF NOT EXISTS milestone_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  milestone_id uuid REFERENCES milestones NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  resource_type text NOT NULL CHECK (resource_type IN ('activity', 'guide', 'video', 'article')),
  content text NOT NULL,
  age_appropriate boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE child_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE milestone_resources ENABLE ROW LEVEL SECURITY;

-- Create policies for milestones
CREATE POLICY "Anyone can view milestones"
  ON milestones
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for child_milestones
CREATE POLICY "Parents can view their children's milestones"
  ON child_milestones
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM children
      WHERE id = child_id
      AND parent_id = auth.uid()
    )
  );

CREATE POLICY "Parents can manage their children's milestones"
  ON child_milestones
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM children
      WHERE id = child_id
      AND parent_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM children
      WHERE id = child_id
      AND parent_id = auth.uid()
    )
  );

-- Create policies for milestone_resources
CREATE POLICY "Anyone can view milestone resources"
  ON milestone_resources
  FOR SELECT
  TO authenticated
  USING (true);

-- Create triggers for updated_at
CREATE TRIGGER update_milestones_updated_at
  BEFORE UPDATE ON milestones
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_child_milestones_updated_at
  BEFORE UPDATE ON child_milestones
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_milestone_resources_updated_at
  BEFORE UPDATE ON milestone_resources
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX idx_milestones_category ON milestones(category);
CREATE INDEX idx_milestones_age_range ON milestones(age_range_start, age_range_end);
CREATE INDEX idx_child_milestones_child ON child_milestones(child_id);
CREATE INDEX idx_child_milestones_milestone ON child_milestones(milestone_id);
CREATE INDEX idx_milestone_resources_milestone ON milestone_resources(milestone_id);
CREATE INDEX idx_milestone_resources_type ON milestone_resources(resource_type);

-- Insert sample milestones
INSERT INTO milestones (title, description, category, age_range_start, age_range_end, importance) VALUES
-- Language Milestones
('First Words', 'Uses single words meaningfully', 'language', 9, 14, 'essential'),
('Two-Word Phrases', 'Combines two words to express ideas', 'language', 18, 24, 'essential'),
('Complex Sentences', 'Uses sentences with multiple clauses', 'language', 36, 48, 'significant'),

-- Cognitive Milestones
('Object Permanence', 'Understands objects exist even when hidden', 'cognitive', 4, 8, 'essential'),
('Symbolic Play', 'Uses objects to represent other things in play', 'cognitive', 18, 24, 'significant'),
('Problem Solving', 'Solves simple puzzles and mechanical problems', 'cognitive', 24, 36, 'significant'),

-- Physical Milestones
('Rolling Over', 'Rolls from back to tummy and reverse', 'physical', 4, 6, 'essential'),
('First Steps', 'Takes first independent steps', 'physical', 9, 15, 'essential'),
('Climbing Stairs', 'Climbs stairs with alternating feet', 'physical', 24, 36, 'significant'),

-- Social Milestones
('Social Smile', 'Smiles in response to others', 'social', 1, 3, 'essential'),
('Parallel Play', 'Plays alongside other children', 'social', 24, 30, 'significant'),
('Cooperative Play', 'Plays cooperatively with other children', 'social', 36, 48, 'significant');

-- Insert sample resources
INSERT INTO milestone_resources (milestone_id, title, description, resource_type, content) 
SELECT 
  id,
  'Supporting ' || title,
  'Activities and tips to support ' || description,
  'activity',
  'Detailed guide for parents to support this milestone through daily activities and play.'
FROM milestones;