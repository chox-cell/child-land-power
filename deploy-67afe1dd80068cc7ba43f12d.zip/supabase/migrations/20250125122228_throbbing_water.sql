-- Create custom admin role
CREATE ROLE custom_admin;

-- Grant necessary privileges
GRANT USAGE ON SCHEMA public TO custom_admin;
GRANT ALL ON ALL TABLES IN SCHEMA public TO custom_admin;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO custom_admin;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO custom_admin;

-- Enable row level security bypass for custom_admin
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO custom_admin;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO custom_admin;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO custom_admin;

-- Add comment explaining the role
COMMENT ON ROLE custom_admin IS 'Custom administrative role with elevated privileges for system operations';