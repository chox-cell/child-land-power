import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaLeaf, FaStar, FaExternalLinkAlt, FaFilter } from 'react-icons/fa';
import { supabase } from '../lib/supabaseClient';
import toast from 'react-hot-toast';

function EcoProducts() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [ageFilter, setAgeFilter] = useState('all');

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Failed to load categories');
    }
  };

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('eco_products')
        .select(`
          *,
          category:product_categories(name),
          reviews:product_reviews(rating)
        `)
        .order('is_featured', { ascending: false });

      if (error) throw error;
      setProducts(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
      setLoading(false);
    }
  };

  const getAverageRating = (reviews) => {
    if (!reviews || reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return Math.round((sum / reviews.length) * 10) / 10;
  };

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'all' || 
      product.category.name.toLowerCase() === selectedCategory;
    
    const matchesAge = ageFilter === 'all' || 
      (ageFilter === '0-2' && product.age_range.includes('2')) ||
      (ageFilter === '3-5' && product.age_range.includes('3-5')) ||
      (ageFilter === '6+' && parseInt(product.age_range) >= 6);

    return matchesCategory && matchesAge;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Eco-Friendly Products
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Curated sustainable toys, books, and learning materials for conscious families
          </p>
        </section>

        {/* Filters */}
        <section className="mb-12">
          <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-2xl border border-accent/20">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Categories */}
              <div className="flex-1">
                <h3 className="text-accent-light mb-3 flex items-center gap-2">
                  <FaFilter />
                  Categories
                </h3>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`px-4 py-2 rounded-xl transition-colors ${
                      selectedCategory === 'all'
                        ? 'bg-accent text-primary-dark'
                        : 'bg-primary-dark/50 text-gray-300 hover:text-accent'
                    }`}
                  >
                    All
                  </button>
                  {categories.map(category => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.name.toLowerCase())}
                      className={`px-4 py-2 rounded-xl transition-colors ${
                        selectedCategory === category.name.toLowerCase()
                          ? 'bg-accent text-primary-dark'
                          : 'bg-primary-dark/50 text-gray-300 hover:text-accent'
                      }`}
                    >
                      {category.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Age Range */}
              <div className="flex-1">
                <h3 className="text-accent-light mb-3">Age Range</h3>
                <div className="flex flex-wrap gap-3">
                  {['all', '0-2', '3-5', '6+'].map(age => (
                    <button
                      key={age}
                      onClick={() => setAgeFilter(age)}
                      className={`px-4 py-2 rounded-xl transition-colors ${
                        ageFilter === age
                          ? 'bg-accent text-primary-dark'
                          : 'bg-primary-dark/50 text-gray-300 hover:text-accent'
                      }`}
                    >
                      {age === 'all' ? 'All Ages' : `${age} years`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map(product => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-primary/30 backdrop-blur-lg rounded-2xl border border-accent/20 overflow-hidden hover:border-accent/40 transition-all"
            >
              {/* Product Image */}
              <div className="relative h-48">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {product.is_featured && (
                  <div className="absolute top-4 right-4 bg-accent text-primary-dark px-3 py-1 rounded-full text-sm font-semibold">
                    Featured
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-accent-light">
                    {product.name}
                  </h3>
                  <span className="text-sm text-gray-400">
                    {product.age_range}
                  </span>
                </div>

                <p className="text-gray-300 mb-4">{product.description}</p>

                {/* Sustainability Features */}
                <div className="mb-4">
                  <h4 className="text-accent-light text-sm mb-2">Sustainability Features:</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.sustainability_features.map((feature, index) => (
                      <span
                        key={index}
                        className="bg-primary-dark/50 text-accent px-2 py-1 rounded-lg text-sm"
                      >
                        <FaLeaf className="inline-block mr-1" />
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-1 text-accent mb-1">
                      <FaStar />
                      <span>{getAverageRating(product.reviews)}</span>
                    </div>
                    <p className="text-gray-400 text-sm">{product.price_range}</p>
                  </div>
                  <a
                    href={product.purchase_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-accent text-primary-dark px-4 py-2 rounded-xl hover:bg-accent-light transition-colors flex items-center gap-2"
                  >
                    Learn More
                    <FaExternalLinkAlt />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </section>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No products found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default EcoProducts;