-- Create test table if it doesn't exist
CREATE TABLE IF NOT EXISTS test_table (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index on user_id column
CREATE INDEX IF NOT EXISTS idx_test_table_user_id
  ON test_table
  USING btree (user_id);