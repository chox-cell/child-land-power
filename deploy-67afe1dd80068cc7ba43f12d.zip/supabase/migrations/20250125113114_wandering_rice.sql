/*
  # Create Eco-Friendly Products Tables

  1. New Tables
    - eco_products: For storing sustainable product recommendations
    - product_categories: For organizing products by category
    - product_reviews: For storing staff reviews and recommendations

  2. Security
    - Enable RLS on all tables
    - Add policies for viewing products
    - Add policies for managing products (admin only)

  3. Changes
    - Add indexes for performance
    - Add foreign key constraints
*/

-- Create product_categories table
CREATE TABLE IF NOT EXISTS product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create eco_products table
CREATE TABLE IF NOT EXISTS eco_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES product_categories NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  price_range text NOT NULL,
  image_url text,
  purchase_url text,
  is_featured boolean DEFAULT false,
  age_range text NOT NULL,
  sustainability_features text[] NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create product_reviews table
CREATE TABLE IF NOT EXISTS product_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES eco_products ON DELETE CASCADE NOT NULL,
  staff_id uuid REFERENCES auth.users NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE eco_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_reviews ENABLE ROW LEVEL SECURITY;

-- Create policies for product_categories
CREATE POLICY "Anyone can view product categories"
  ON product_categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can manage product categories"
  ON product_categories
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for eco_products
CREATE POLICY "Anyone can view eco products"
  ON eco_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can manage eco products"
  ON eco_products
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for product_reviews
CREATE POLICY "Anyone can view product reviews"
  ON product_reviews
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only staff can create reviews"
  ON product_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND (
        raw_user_meta_data->>'is_admin' = 'true'
        OR raw_user_meta_data->>'is_staff' = 'true'
      )
    )
  );

CREATE POLICY "Staff can only update their own reviews"
  ON product_reviews
  FOR UPDATE
  TO authenticated
  USING (staff_id = auth.uid())
  WITH CHECK (staff_id = auth.uid());

-- Create triggers
CREATE TRIGGER update_product_categories_updated_at
  BEFORE UPDATE ON product_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_eco_products_updated_at
  BEFORE UPDATE ON eco_products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_product_reviews_updated_at
  BEFORE UPDATE ON product_reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX idx_eco_products_category ON eco_products(category_id);
CREATE INDEX idx_eco_products_featured ON eco_products(is_featured);
CREATE INDEX idx_product_reviews_product ON product_reviews(product_id);
CREATE INDEX idx_product_reviews_staff ON product_reviews(staff_id);

-- Insert initial categories
INSERT INTO product_categories (name, description) VALUES
('Toys', 'Eco-friendly and sustainable toys for all ages'),
('Books', 'Environmental education and nature-themed books'),
('Art Supplies', 'Non-toxic and sustainable art materials'),
('Learning Tools', 'Educational materials promoting environmental awareness');

-- Insert sample products
INSERT INTO eco_products (
  category_id,
  name,
  description,
  price_range,
  image_url,
  purchase_url,
  is_featured,
  age_range,
  sustainability_features
) 
SELECT
  c.id,
  CASE c.name
    WHEN 'Toys' THEN 'Wooden Building Blocks'
    WHEN 'Books' THEN 'The Little Gardener'
    WHEN 'Art Supplies' THEN 'Natural Paint Set'
    WHEN 'Learning Tools' THEN 'Recycling Sorting Game'
  END,
  CASE c.name
    WHEN 'Toys' THEN 'Handcrafted wooden blocks made from sustainable forests'
    WHEN 'Books' THEN 'A beautifully illustrated story about growing your own garden'
    WHEN 'Art Supplies' THEN 'Plant-based paints in recyclable containers'
    WHEN 'Learning Tools' THEN 'Educational game teaching proper recycling habits'
  END,
  CASE c.name
    WHEN 'Toys' THEN '€30-€50'
    WHEN 'Books' THEN '€15-€20'
    WHEN 'Art Supplies' THEN '€25-€35'
    WHEN 'Learning Tools' THEN '€20-€30'
  END,
  'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=800&auto=format',
  'https://example.com/product',
  true,
  CASE c.name
    WHEN 'Toys' THEN '2-6 years'
    WHEN 'Books' THEN '3-8 years'
    WHEN 'Art Supplies' THEN '4+ years'
    WHEN 'Learning Tools' THEN '5+ years'
  END,
  CASE c.name
    WHEN 'Toys' THEN ARRAY['FSC-certified wood', 'Non-toxic finishes', 'Plastic-free packaging']
    WHEN 'Books' THEN ARRAY['Recycled paper', 'Soy-based inks', 'Carbon-neutral printing']
    WHEN 'Art Supplies' THEN ARRAY['Natural ingredients', 'Recyclable packaging', 'Zero waste']
    WHEN 'Learning Tools' THEN ARRAY['Recycled materials', 'Educational value', 'Durable design']
  END
FROM product_categories c;