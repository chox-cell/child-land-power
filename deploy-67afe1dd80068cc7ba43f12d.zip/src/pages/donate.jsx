import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaHeart, FaLeaf, FaUsers, FaGraduationCap } from 'react-icons/fa';

function Donate() {
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [customAmount, setCustomAmount] = useState('');

  const predefinedAmounts = ['20', '50', '100', '200'];

  const handleDonate = (selectedAmount) => {
    const donationAmount = selectedAmount === 'custom' ? customAmount : selectedAmount;
    navigate('/payment', { 
      state: { 
        type: 'donation',
        amount: donationAmount 
      }
    });
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-24">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-primary mb-8 text-center">Support Our Mission</h1>
          
          {/* Impact Section */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="card">
              <FaLeaf className="text-3xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Environmental Impact</h3>
              <p className="text-text-secondary">Support our eco-friendly initiatives and sustainable practices.</p>
            </div>
            
            <div className="card">
              <FaGraduationCap className="text-3xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Education Support</h3>
              <p className="text-text-secondary">Help provide quality bilingual education to more children.</p>
            </div>
            
            <div className="card">
              <FaUsers className="text-3xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Community Building</h3>
              <p className="text-text-secondary">Strengthen our community through inclusive programs.</p>
            </div>
          </div>

          {/* Donation Form */}
          <div className="card">
            <form className="space-y-8">
              {/* Amount Selection */}
              <div>
                <label className="block text-primary font-bold mb-4 text-xl">
                  Select Amount (€)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  {predefinedAmounts.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => handleDonate(preset)}
                      className="btn-secondary hover:bg-accent hover:text-white hover:border-accent p-4"
                    >
                      €{preset}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder="Enter custom amount"
                    className="input flex-1"
                    min="1"
                  />
                  <button
                    type="button"
                    onClick={() => handleDonate('custom')}
                    className="btn-primary"
                    disabled={!customAmount}
                  >
                    Donate Custom Amount
                  </button>
                </div>
              </div>
            </form>

            <div className="mt-8 text-center text-text-secondary">
              <p>Your donation may be tax-deductible. A receipt will be provided for your records.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Donate;