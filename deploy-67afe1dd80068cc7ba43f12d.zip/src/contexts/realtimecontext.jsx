import React, { createContext, useContext, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const RealtimeContext = createContext({});

export function RealtimeProvider({ children }) {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Subscribe to activities
    const activitySubscription = supabase
      .channel('activities')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'activities',
        filter: `parent_id=eq.${user.id}`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          toast.success('New activity recorded!');
        }
      })
      .subscribe();

    // Subscribe to photos
    const photoSubscription = supabase
      .channel('photos')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'photos',
        filter: `parent_id=eq.${user.id}`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          toast.success('New photo added!');
        }
      })
      .subscribe();

    // Subscribe to milestone achievements
    const milestoneSubscription = supabase
      .channel('child_milestones')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'child_milestones',
        filter: `child_id=in.(select id from children where parent_id=eq.${user.id})`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          toast.success('New milestone achieved!');
        }
      })
      .subscribe();

    // Subscribe to eco metrics (for staff/admin)
    const ecoMetricsSubscription = supabase
      .channel('eco_metrics')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'eco_metrics'
      }, (payload) => {
        if (payload.eventType === 'UPDATE' || payload.eventType === 'INSERT') {
          toast.success('Eco metrics updated!');
        }
      })
      .subscribe();

    // Cleanup subscriptions
    return () => {
      activitySubscription.unsubscribe();
      photoSubscription.unsubscribe();
      milestoneSubscription.unsubscribe();
      ecoMetricsSubscription.unsubscribe();
    };
  }, [user]);

  return (
    <RealtimeContext.Provider value={{}}>
      {children}
    </RealtimeContext.Provider>
  );
}

export function useRealtime() {
  return useContext(RealtimeContext);
}