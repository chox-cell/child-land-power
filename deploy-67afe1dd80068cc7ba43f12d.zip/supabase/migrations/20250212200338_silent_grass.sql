/*
  # Fix Enum Type Conversions
  
  1. Create enum types
  2. Add temporary columns
  3. Convert data safely
  4. Replace old columns with new ones
*/

-- First, create all enum types
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('parent', 'staff', 'admin');
    CREATE TYPE activity_type AS ENUM ('learning', 'play', 'meal', 'nap', 'outdoor', 'art', 'music', 'milestone', 'other');
    CREATE TYPE milestone_category AS ENUM ('language', 'cognitive', 'physical', 'social');
    CREATE TYPE milestone_importance AS ENUM ('essential', 'significant', 'supportive');
    CREATE TYPE notification_type AS ENUM ('activity', 'photo', 'milestone', 'message', 'system');
    CREATE TYPE visit_request_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
    CREATE TYPE resource_type AS ENUM ('activity', 'guide', 'video', 'article');
    CREATE TYPE message_status AS ENUM ('sent', 'delivered', 'read');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Safely convert profiles table
DO $$ BEGIN
    -- Add temporary column
    ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role_enum user_role;
    
    -- Convert existing data
    UPDATE profiles SET role_enum = role::user_role;
    
    -- Drop old column and rename new one
    ALTER TABLE profiles 
        DROP COLUMN role,
        ALTER COLUMN role_enum SET DEFAULT 'parent',
        ALTER COLUMN role_enum SET NOT NULL,
        ALTER COLUMN role_enum TYPE user_role;
    
    ALTER TABLE profiles RENAME COLUMN role_enum TO role;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Safely convert activities table
DO $$ BEGIN
    -- Add temporary column
    ALTER TABLE activities ADD COLUMN IF NOT EXISTS activity_type_enum activity_type;
    
    -- Convert existing data with default
    UPDATE activities SET activity_type_enum = COALESCE(activity_type::activity_type, 'other');
    
    -- Drop old column and rename new one
    ALTER TABLE activities 
        DROP COLUMN IF EXISTS activity_type,
        ALTER COLUMN activity_type_enum SET DEFAULT 'other',
        ALTER COLUMN activity_type_enum SET NOT NULL,
        ALTER COLUMN activity_type_enum TYPE activity_type;
    
    ALTER TABLE activities RENAME COLUMN activity_type_enum TO activity_type;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Safely convert milestones table
DO $$ BEGIN
    -- Add temporary columns
    ALTER TABLE milestones ADD COLUMN IF NOT EXISTS category_enum milestone_category;
    ALTER TABLE milestones ADD COLUMN IF NOT EXISTS importance_enum milestone_importance;
    
    -- Convert existing data
    UPDATE milestones SET 
        category_enum = category::milestone_category,
        importance_enum = importance::milestone_importance;
    
    -- Drop old columns and rename new ones
    ALTER TABLE milestones 
        DROP COLUMN IF EXISTS category,
        DROP COLUMN IF EXISTS importance,
        ALTER COLUMN category_enum SET NOT NULL,
        ALTER COLUMN importance_enum SET NOT NULL,
        ALTER COLUMN category_enum TYPE milestone_category,
        ALTER COLUMN importance_enum TYPE milestone_importance;
    
    ALTER TABLE milestones RENAME COLUMN category_enum TO category;
    ALTER TABLE milestones RENAME COLUMN importance_enum TO importance;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Safely convert visit_requests table
DO $$ BEGIN
    -- Add temporary column
    ALTER TABLE visit_requests ADD COLUMN IF NOT EXISTS status_enum visit_request_status;
    
    -- Convert existing data with default
    UPDATE visit_requests SET status_enum = COALESCE(status::visit_request_status, 'pending');
    
    -- Drop old column and rename new one
    ALTER TABLE visit_requests 
        DROP COLUMN IF EXISTS status,
        ALTER COLUMN status_enum SET DEFAULT 'pending',
        ALTER COLUMN status_enum SET NOT NULL,
        ALTER COLUMN status_enum TYPE visit_request_status;
    
    ALTER TABLE visit_requests RENAME COLUMN status_enum TO status;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Safely convert milestone_resources table
DO $$ BEGIN
    -- Add temporary column
    ALTER TABLE milestone_resources ADD COLUMN IF NOT EXISTS resource_type_enum resource_type;
    
    -- Convert existing data
    UPDATE milestone_resources SET resource_type_enum = resource_type::resource_type;
    
    -- Drop old column and rename new one
    ALTER TABLE milestone_resources 
        DROP COLUMN IF EXISTS resource_type,
        ALTER COLUMN resource_type_enum SET NOT NULL,
        ALTER COLUMN resource_type_enum TYPE resource_type;
    
    ALTER TABLE milestone_resources RENAME COLUMN resource_type_enum TO resource_type;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Safely convert messages table
DO $$ BEGIN
    -- Add temporary column
    ALTER TABLE messages ADD COLUMN IF NOT EXISTS status_enum message_status;
    
    -- Convert existing data with default
    UPDATE messages SET status_enum = COALESCE(status::message_status, 'sent');
    
    -- Drop old column and rename new one
    ALTER TABLE messages 
        DROP COLUMN IF EXISTS status,
        ALTER COLUMN status_enum SET DEFAULT 'sent',
        ALTER COLUMN status_enum SET NOT NULL,
        ALTER COLUMN status_enum TYPE message_status;
    
    ALTER TABLE messages RENAME COLUMN status_enum TO status;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Add helpful comments
COMMENT ON TYPE user_role IS 'Enumerated type for user roles in the system';
COMMENT ON TYPE activity_type IS 'Types of activities that can be recorded';
COMMENT ON TYPE milestone_category IS 'Categories of developmental milestones';
COMMENT ON TYPE milestone_importance IS 'Importance levels for milestones';
COMMENT ON TYPE notification_type IS 'Types of system notifications';
COMMENT ON TYPE visit_request_status IS 'Status options for visit requests';
COMMENT ON TYPE resource_type IS 'Types of educational resources';
COMMENT ON TYPE message_status IS 'Status of messages in the system';