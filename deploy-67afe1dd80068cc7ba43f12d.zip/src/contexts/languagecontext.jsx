import React, { createContext, useContext, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const LanguageContext = createContext();

export function LanguageProvider({ children }) {
  // Get initial language from browser or localStorage
  const getBrowserLanguage = () => {
    const savedLang = localStorage.getItem('preferredLanguage');
    if (savedLang) return savedLang;
    
    const browserLang = navigator.language.split('-')[0];
    return browserLang === 'fr' ? 'fr' : 'en';
  };

  const [language, setLanguage] = useState(getBrowserLanguage());
  const [isChanging, setIsChanging] = useState(false);

  const changeLanguage = (newLang) => {
    setIsChanging(true);
    setLanguage(newLang);
    localStorage.setItem('preferredLanguage', newLang);
    
    // Simulate content transition
    setTimeout(() => {
      setIsChanging(false);
    }, 300);
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, isChanging }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={language}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};