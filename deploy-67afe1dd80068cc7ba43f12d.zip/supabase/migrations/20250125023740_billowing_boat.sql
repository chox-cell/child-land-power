/*
  # Database Schema Consolidation
  
  1. Tables
    - eco_metrics: Environmental impact tracking
    - charts: Chart configurations
    - chart_data: Data points for charts
  
  2. Security
    - Enable RLS on all tables
    - Add policies for viewing and managing data
    - Secure function execution
  
  3. Features
    - Automatic timestamp management
    - Data validation constraints
    - Performance indexes
*/

-- Drop existing objects safely
DROP TRIGGER IF EXISTS update_eco_metrics_updated_at ON eco_metrics;
DROP TRIGGER IF EXISTS update_charts_updated_at ON charts;
DROP TRIGGER IF EXISTS update_chart_data_updated_at ON chart_data;
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;
DROP TABLE IF EXISTS chart_data CASCADE;
DROP TABLE IF EXISTS charts CASCADE;
DROP TABLE IF EXISTS eco_metrics CASCADE;

-- Create updated_at function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create eco_metrics table
CREATE TABLE eco_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date timestamptz NOT NULL DEFAULT now(),
  waste_reduced numeric NOT NULL DEFAULT 0 CHECK (waste_reduced >= 0),
  trees_planted integer NOT NULL DEFAULT 0 CHECK (trees_planted >= 0),
  water_saved numeric NOT NULL DEFAULT 0 CHECK (water_saved >= 0),
  energy_saved numeric NOT NULL DEFAULT 0 CHECK (energy_saved >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create charts table
CREATE TABLE charts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  type text NOT NULL,
  description text,
  config jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create chart_data table
CREATE TABLE chart_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chart_id uuid REFERENCES charts ON DELETE CASCADE,
  label text NOT NULL,
  value numeric NOT NULL CHECK (value >= 0),
  category text,
  date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE eco_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE charts ENABLE ROW LEVEL SECURITY;
ALTER TABLE chart_data ENABLE ROW LEVEL SECURITY;

-- Create triggers
CREATE TRIGGER update_eco_metrics_updated_at
  BEFORE UPDATE ON eco_metrics
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_charts_updated_at
  BEFORE UPDATE ON charts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chart_data_updated_at
  BEFORE UPDATE ON chart_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create policies
CREATE POLICY "Anyone can view eco metrics"
  ON eco_metrics
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can insert eco metrics"
  ON eco_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

CREATE POLICY "Only admins can update eco metrics"
  ON eco_metrics
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for charts
CREATE POLICY "Anyone can view active charts"
  ON charts
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only admins can manage charts"
  ON charts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for chart_data
CREATE POLICY "Anyone can view chart data"
  ON chart_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM charts
      WHERE id = chart_id
      AND is_active = true
    )
  );

CREATE POLICY "Only admins can manage chart data"
  ON chart_data
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create indexes
CREATE INDEX idx_eco_metrics_date ON eco_metrics(date);
CREATE INDEX idx_charts_type ON charts(type);
CREATE INDEX idx_charts_is_active ON charts(is_active);
CREATE INDEX idx_chart_data_date ON chart_data(date);
CREATE INDEX idx_chart_data_category ON chart_data(category);
CREATE INDEX idx_chart_data_chart_id ON chart_data(chart_id);

-- Insert initial data
INSERT INTO eco_metrics (
  waste_reduced,
  trees_planted,
  water_saved,
  energy_saved
)
SELECT 
  100.5,  -- Initial waste reduced in kg
  5,      -- Initial trees planted
  1000.0, -- Initial water saved in L
  500.0   -- Initial energy saved in kWh
WHERE NOT EXISTS (SELECT 1 FROM eco_metrics);

-- Insert sample charts
INSERT INTO charts (title, type, description, config)
VALUES 
  (
    'Eco Impact Overview',
    'line',
    'Monthly tracking of our environmental impact metrics',
    '{
      "xAxis": "date",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  ),
  (
    'Resource Conservation',
    'bar',
    'Comparison of resource conservation metrics',
    '{
      "xAxis": "category",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  );