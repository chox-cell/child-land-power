/*
  # Add indexes and foreign key constraints

  1. Changes
    - Add indexes for eco_metrics table
    - Add indexes for children table
    - Add indexes for activities table
    - Add indexes for photos table
    - Add indexes for messages table
    - Add foreign key constraints with cascade delete
    - Add check constraints for data validation
    - Add composite indexes for common query patterns

  2. Notes
    - All indexes use IF NOT EXISTS to avoid errors
    - Foreign keys use cascade delete where appropriate
    - Added check constraints for data validation
*/

-- Add indexes for eco_metrics
CREATE INDEX IF NOT EXISTS idx_eco_metrics_date ON eco_metrics(date);

-- Add indexes for children table
CREATE INDEX IF NOT EXISTS idx_children_parent_id ON children(parent_id);
CREATE INDEX IF NOT EXISTS idx_children_date_of_birth ON children(date_of_birth);

-- Add indexes for activities
CREATE INDEX IF NOT EXISTS idx_activities_parent_id ON activities(parent_id);
CREATE INDEX IF NOT EXISTS idx_activities_child_id ON activities(child_id);
CREATE INDEX IF NOT EXISTS idx_activities_created_at ON activities(created_at);

-- Add indexes for photos
CREATE INDEX IF NOT EXISTS idx_photos_parent_id ON photos(parent_id);
CREATE INDEX IF NOT EXISTS idx_photos_child_id ON photos(child_id);
CREATE INDEX IF NOT EXISTS idx_photos_created_at ON photos(created_at);

-- Add indexes for messages
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver_id ON messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- Add foreign key constraints with cascade delete where appropriate
ALTER TABLE activities
ADD CONSTRAINT fk_activities_child
FOREIGN KEY (child_id) REFERENCES children(id)
ON DELETE CASCADE;

ALTER TABLE photos
ADD CONSTRAINT fk_photos_child
FOREIGN KEY (child_id) REFERENCES children(id)
ON DELETE CASCADE;

-- Add check constraints for data validation
ALTER TABLE eco_metrics
ADD CONSTRAINT chk_eco_metrics_positive
CHECK (
  waste_reduced >= 0 AND
  trees_planted >= 0 AND
  water_saved >= 0 AND
  energy_saved >= 0
);

-- Add composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_activities_parent_child 
ON activities(parent_id, child_id);

CREATE INDEX IF NOT EXISTS idx_photos_parent_child
ON photos(parent_id, child_id);

CREATE INDEX IF NOT EXISTS idx_messages_sender_receiver
ON messages(sender_id, receiver_id);