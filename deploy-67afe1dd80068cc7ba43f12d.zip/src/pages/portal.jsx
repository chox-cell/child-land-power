import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import { FaChild, FaCamera, FaComments, FaSignOutAlt } from 'react-icons/fa';
import { Tab } from '@headlessui/react';
import toast from 'react-hot-toast';
import ActivityFeed from '../components/portal/ActivityFeed';
import PhotoGallery from '../components/portal/PhotoGallery';
import Messages from '../components/portal/Messages';

function Portal() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedChild, setSelectedChild] = useState(null);
  const [children, setChildren] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    async function initializeAuth() {
      try {
        // Get current session
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) throw sessionError;
        
        if (!session) {
          navigate('/login');
          return;
        }

        if (mounted) {
          setSession(session);
          await fetchChildren(session.user.id);
          setLoading(false);
        }
      } catch (error) {
        console.error('Auth error:', error);
        if (mounted) {
          toast.error('Authentication error');
          navigate('/login');
        }
      }
    }

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted) {
        if (!session) {
          navigate('/login');
          return;
        }
        setSession(session);
      }
    });

    initializeAuth();

    return () => {
      mounted = false;
      subscription?.unsubscribe();
    };
  }, [navigate]);

  const fetchChildren = async (userId) => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select('*')
        .eq('parent_id', userId)
        .order('name');

      if (error) throw error;
      
      if (data) {
        setChildren(data);
        if (data.length > 0) {
          setSelectedChild(data[0]);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to load children data');
    }
  };

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      toast.success('Signed out successfully');
      navigate('/login');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error signing out');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-primary">Parent Portal</h1>
            {children.length > 0 && (
              <div className="mt-2">
                <select
                  value={selectedChild?.id}
                  onChange={(e) => setSelectedChild(children.find(c => c.id === e.target.value))}
                  className="input"
                >
                  {children.map(child => (
                    <option key={child.id} value={child.id}>
                      {child.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
          <button
            onClick={handleSignOut}
            className="btn-secondary flex items-center gap-2 text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
          >
            <FaSignOutAlt />
            Sign Out
          </button>
        </div>

        {/* Main Content */}
        {children.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-xl text-text-secondary mb-4">No children registered yet.</p>
            <button
              onClick={() => navigate('/register-child')}
              className="btn-primary inline-flex items-center gap-2"
            >
              <FaChild />
              Register a Child
            </button>
          </div>
        ) : (
          <Tab.Group>
            <Tab.List className="flex space-x-4 mb-8">
              <Tab className={({ selected }) =>
                `flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors
                 ${selected 
                   ? 'bg-accent text-white' 
                   : 'text-text-secondary hover:text-primary bg-gray-50'}`
              }>
                <FaChild />
                Activities
              </Tab>
              <Tab className={({ selected }) =>
                `flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors
                 ${selected 
                   ? 'bg-accent text-white' 
                   : 'text-text-secondary hover:text-primary bg-gray-50'}`
              }>
                <FaCamera />
                Photos
              </Tab>
              <Tab className={({ selected }) =>
                `flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors
                 ${selected 
                   ? 'bg-accent text-white' 
                   : 'text-text-secondary hover:text-primary bg-gray-50'}`
              }>
                <FaComments />
                Messages
              </Tab>
            </Tab.List>

            <Tab.Panels>
              <Tab.Panel>
                <ActivityFeed session={session} childId={selectedChild?.id} />
              </Tab.Panel>
              <Tab.Panel>
                <PhotoGallery session={session} childId={selectedChild?.id} />
              </Tab.Panel>
              <Tab.Panel>
                <Messages session={session} />
              </Tab.Panel>
            </Tab.Panels>
          </Tab.Group>
        )}
      </div>
    </div>
  );
}

export default Portal;