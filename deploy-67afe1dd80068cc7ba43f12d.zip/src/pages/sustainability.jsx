import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaLeaf, FaRecycle, FaSeedling, FaHandsHelping, FaSun, FaWater } from 'react-icons/fa';
import EcoTracker from '../components/EcoTracker';

function Sustainability() {
  const navigate = useNavigate();

  const handleVolunteer = () => {
    navigate('/contact', { state: { type: 'volunteer' } });
  };

  const handleDonate = () => {
    navigate('/contact', { state: { type: 'donate' } });
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-primary">
            Our Green Initiative
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Building a sustainable future through eco-conscious education and practices
          </p>
        </section>

        {/* Eco-Friendly Practices */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">Sustainable Practices</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card">
              <FaSeedling className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Organic Garden</h3>
              <p className="text-text-secondary">
                Our children learn about food sustainability through hands-on experience in our organic garden, growing vegetables and herbs used in our kitchen.
              </p>
            </div>

            <div className="card">
              <FaRecycle className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Recycling Program</h3>
              <p className="text-text-secondary">
                We implement comprehensive recycling practices and teach children about waste reduction through creative reuse projects.
              </p>
            </div>

            <div className="card">
              <FaSun className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Energy Efficiency</h3>
              <p className="text-text-secondary">
                Our facility uses energy-efficient lighting and natural ventilation to reduce our carbon footprint.
              </p>
            </div>
          </div>
        </section>

        {/* Environmental Impact */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">Our Impact</h2>
          <div className="card">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="text-center">
                <FaLeaf className="text-5xl text-accent mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-primary mb-2">Waste Reduction</h3>
                <p className="text-4xl font-bold text-accent mb-2">80%</p>
                <p className="text-text-secondary">Reduction in single-use plastics</p>
              </div>

              <div className="text-center">
                <FaWater className="text-5xl text-accent mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-primary mb-2">Water Conservation</h3>
                <p className="text-4xl font-bold text-accent mb-2">40%</p>
                <p className="text-text-secondary">Reduction in water usage</p>
              </div>
            </div>
          </div>
        </section>

        {/* How You Can Help */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">How You Can Help</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="card">
              <FaHandsHelping className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-4">Volunteer Opportunities</h3>
              <ul className="text-text-secondary space-y-2 mb-6">
                <li>• Garden maintenance</li>
                <li>• Recycling program support</li>
                <li>• Environmental education</li>
                <li>• Special eco-events</li>
              </ul>
              <button 
                onClick={handleVolunteer}
                className="btn-primary w-full"
              >
                Volunteer With Us
              </button>
            </div>

            <div className="card">
              <FaLeaf className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-4">Support Our Mission</h3>
              <ul className="text-text-secondary space-y-2 mb-6">
                <li>• Garden supplies</li>
                <li>• Eco-friendly toys</li>
                <li>• Art materials</li>
                <li>• Educational resources</li>
              </ul>
              <button 
                onClick={handleDonate}
                className="btn-primary w-full"
              >
                Make a Donation
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default Sustainability;