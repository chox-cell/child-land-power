import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaCalendar, FaClock, FaHourglass, FaSeedling, FaLanguage, FaRecycle } from 'react-icons/fa';

function Programs() {
  const navigate = useNavigate();

  const handleEnroll = () => {
    navigate('/register-child');
  };

  const handleContact = () => {
    navigate('/contact');
  };

  const handleLearnMore = () => {
    navigate('/admissions');
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-primary">
            Our Programs
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Discover our flexible childcare options designed for children aged 3-5 years
          </p>
        </section>

        {/* Pricing Plans */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">Childcare Plans</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Full-time Plan */}
            <div className="card">
              <FaCalendar className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Full-Time Care</h3>
              <p className="text-3xl font-bold text-accent mb-4">€800<span className="text-text-secondary text-lg">/month</span></p>
              <ul className="text-text-secondary space-y-2 mb-6">
                <li>• Monday to Friday</li>
                <li>• 8:00 AM - 6:00 PM</li>
                <li>• All meals included</li>
                <li>• Full curriculum access</li>
                <li>• Regular progress reports</li>
              </ul>
              <div className="space-y-3">
                <button 
                  onClick={handleEnroll}
                  className="btn-primary w-full"
                >
                  Enroll Now
                </button>
                <button 
                  onClick={handleLearnMore}
                  className="btn-secondary w-full"
                >
                  Learn More
                </button>
              </div>
            </div>

            {/* Part-time Plan */}
            <div className="card">
              <FaClock className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Part-Time Care</h3>
              <p className="text-3xl font-bold text-accent mb-4">€400<span className="text-text-secondary text-lg">/month</span></p>
              <ul className="text-text-secondary space-y-2 mb-6">
                <li>• 2-3 days per week</li>
                <li>• Flexible scheduling</li>
                <li>• Meals included</li>
                <li>• Curriculum access</li>
                <li>• Monthly progress updates</li>
              </ul>
              <div className="space-y-3">
                <button 
                  onClick={handleEnroll}
                  className="btn-primary w-full"
                >
                  Enroll Now
                </button>
                <button 
                  onClick={handleLearnMore}
                  className="btn-secondary w-full"
                >
                  Learn More
                </button>
              </div>
            </div>

            {/* Drop-in Plan */}
            <div className="card">
              <FaHourglass className="text-4xl text-accent mb-4" />
              <h3 className="text-2xl font-bold text-primary mb-2">Drop-In Care</h3>
              <p className="text-3xl font-bold text-accent mb-4">€10<span className="text-text-secondary text-lg">/hour</span></p>
              <ul className="text-text-secondary space-y-2 mb-6">
                <li>• Flexible hours</li>
                <li>• Subject to availability</li>
                <li>• Meal option available</li>
                <li>• Activity participation</li>
                <li>• Daily report provided</li>
              </ul>
              <div className="space-y-3">
                <button 
                  onClick={handleContact}
                  className="btn-primary w-full"
                >
                  Contact Us
                </button>
                <button 
                  onClick={handleLearnMore}
                  className="btn-secondary w-full"
                >
                  Learn More
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Features */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-primary text-center mb-8">Program Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card">
              <FaSeedling className="text-4xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Eco-Activities</h3>
              <p className="text-text-secondary">
                Daily gardening, nature exploration, and recycling projects to foster environmental awareness
              </p>
            </div>

            <div className="card">
              <FaLanguage className="text-4xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Bilingual Learning</h3>
              <p className="text-text-secondary">
                Immersive French-English environment with dedicated language activities throughout the day
              </p>
            </div>

            <div className="card">
              <FaRecycle className="text-4xl text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Sustainable Crafts</h3>
              <p className="text-text-secondary">
                Creative projects using recycled materials to teach sustainability through art
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default Programs;