-- Enable storage extension
CREATE EXTENSION IF NOT EXISTS "storage" SCHEMA "extensions";

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('avatars', 'avatars', false, 5242880, ARRAY['image/jpeg', 'image/png', 'image/gif']), -- 5MB limit for profile photos
  ('activities', 'activities', false, 10485760, ARRAY['image/jpeg', 'image/png', 'image/gif', 'application/pdf']), -- 10MB limit
  ('resources', 'resources', false, 20971520, ARRAY['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'video/mp4', 'audio/mpeg']), -- 20MB limit
  ('public', 'public', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/gif']) -- 5MB limit for public assets
ON CONFLICT (id) DO NOTHING;

-- Set up RLS policies for avatars bucket
CREATE POLICY "Users can view own avatar"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload own avatar"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars' 
    AND auth.uid()::text = (storage.foldername(name))[1]
    AND (storage.foldername(name))[2] IS NULL
  );

-- Set up RLS policies for activities bucket
CREATE POLICY "Parents can view their children's activities"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'activities'
    AND EXISTS (
      SELECT 1 FROM activities a
      WHERE a.parent_id = auth.uid()
      AND a.id::text = (storage.foldername(name))[1]
    )
  );

CREATE POLICY "Parents can upload activities"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'activities'
    AND EXISTS (
      SELECT 1 FROM activities a
      WHERE a.parent_id = auth.uid()
      AND a.id::text = (storage.foldername(name))[1]
    )
  );

-- Set up RLS policies for resources bucket
CREATE POLICY "Anyone can view resources"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'resources');

CREATE POLICY "Only staff can upload resources"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'resources'
    AND EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('staff', 'admin')
    )
  );

-- Set up RLS policies for public bucket
CREATE POLICY "Anyone can view public files"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'public');

CREATE POLICY "Only admins can upload public files"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'public'
    AND EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
  );

-- Add helpful comments
COMMENT ON POLICY "Users can view own avatar" ON storage.objects IS 'Allow users to view their own avatar';
COMMENT ON POLICY "Users can upload own avatar" ON storage.objects IS 'Allow users to upload their own avatar';
COMMENT ON POLICY "Parents can view their children's activities" ON storage.objects IS 'Allow parents to view their children''s activity photos';
COMMENT ON POLICY "Parents can upload activities" ON storage.objects IS 'Allow parents to upload activity photos';
COMMENT ON POLICY "Anyone can view resources" ON storage.objects IS 'Allow authenticated users to view educational resources';
COMMENT ON POLICY "Only staff can upload resources" ON storage.objects IS 'Allow only staff to upload educational resources';
COMMENT ON POLICY "Anyone can view public files" ON storage.objects IS 'Allow anyone to view public files';
COMMENT ON POLICY "Only admins can upload public files" ON storage.objects IS 'Allow only admins to upload public files';