-- Drop existing tables if they exist
DROP TABLE IF EXISTS profiles CASCADE;
DROP TABLE IF EXISTS activities CASCADE;
DROP TABLE IF EXISTS milestones CASCADE;
DROP TABLE IF EXISTS visit_requests CASCADE;
DROP TABLE IF EXISTS milestone_resources CASCADE;
DROP TABLE IF EXISTS messages CASCADE;

-- Create new tables with text columns and check constraints
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  address text,
  role text NOT NULL DEFAULT 'parent' CHECK (role IN ('parent', 'staff', 'admin')),
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES auth.users NOT NULL,
  child_id uuid REFERENCES children NOT NULL,
  activity_type text NOT NULL DEFAULT 'other' CHECK (activity_type IN ('learning', 'play', 'meal', 'nap', 'outdoor', 'art', 'music', 'milestone', 'other')),
  title text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL DEFAULT 'language' CHECK (category IN ('language', 'cognitive', 'physical', 'social')),
  importance text NOT NULL DEFAULT 'essential' CHECK (importance IN ('essential', 'significant', 'supportive')),
  age_range_start integer NOT NULL CHECK (age_range_start >= 0),
  age_range_end integer NOT NULL CHECK (age_range_end >= age_range_start),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE visit_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  preferred_date date NOT NULL,
  preferred_time time NOT NULL,
  number_of_children integer NOT NULL CHECK (number_of_children > 0),
  children_ages text NOT NULL,
  message text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE milestone_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  milestone_id uuid REFERENCES milestones NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  resource_type text NOT NULL DEFAULT 'guide' CHECK (resource_type IN ('activity', 'guide', 'video', 'article')),
  content text NOT NULL,
  age_appropriate boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users NOT NULL,
  receiver_id uuid REFERENCES auth.users NOT NULL,
  content text NOT NULL,
  status text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add helpful comments
COMMENT ON TABLE profiles IS 'User profile information with role-based access';
COMMENT ON TABLE activities IS 'Child activities and events';
COMMENT ON TABLE milestones IS 'Child development milestones';
COMMENT ON TABLE visit_requests IS 'Facility visit scheduling requests';
COMMENT ON TABLE milestone_resources IS 'Educational resources for milestones';
COMMENT ON TABLE messages IS 'Internal messaging system';