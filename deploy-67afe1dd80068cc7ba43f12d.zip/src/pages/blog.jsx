import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FaCalendar, FaTags, FaUser, FaComments, FaSearch } from 'react-icons/fa';

function Blog() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const blogPosts = [
    {
      id: 1,
      title: "How to Raise a Bilingual Child: Tips and Benefits",
      category: "Language Learning",
      date: "March 15, 2024",
      author: "Dr. Emma Wilson",
      excerpt: "Explore the advantages of bilingualism and practical methods for teaching two languages at home.",
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&auto=format",
      tags: ["bilingual", "education", "parenting"]
    },
    {
      id: 2,
      title: "Eco-Friendly Parenting: Reducing Waste at Home",
      category: "Eco-Friendly Systems",
      date: "March 14, 2024",
      author: "Sarah Green",
      excerpt: "Tips on using sustainable products and creating fun recycling habits with kids.",
      image: "https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=800&auto=format",
      tags: ["eco-friendly", "sustainability", "home"]
    },
    {
      id: 3,
      title: "The Power of Connection: Helping Kids Develop Social Skills",
      category: "Community Building",
      date: "March 13, 2024",
      author: "Michael Chen",
      excerpt: "Learn how parents can help kids build strong, meaningful friendships.",
      image: "https://images.unsplash.com/photo-1602030638412-bb8dcc0bc8b0?w=800&auto=format",
      tags: ["social skills", "development", "friendship"]
    },
    {
      id: 4,
      title: "Understanding Your Child's Emotional Needs",
      category: "Psychology",
      date: "March 12, 2024",
      author: "Dr. Lisa Thompson",
      excerpt: "A guide to recognizing emotions and fostering open communication with your child.",
      image: "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=800&auto=format",
      tags: ["psychology", "emotions", "parenting"]
    },
    {
      id: 5,
      title: "Kid-Friendly Healthy Recipes for Picky Eaters",
      category: "Food & Nutrition",
      date: "March 11, 2024",
      author: "Chef Maria Rodriguez",
      excerpt: "Easy and nutritious recipes kids will love, from smoothies to eco-snacks.",
      image: "https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=800&auto=format",
      tags: ["nutrition", "recipes", "health"]
    },
    {
      id: 6,
      title: "Teaching Children Hygiene Habits Through Fun Routines",
      category: "Health & Hygiene",
      date: "March 10, 2024",
      author: "Nurse Jenny Kim",
      excerpt: "Creative ways to make handwashing, dental care, and cleanliness exciting for kids.",
      image: "https://images.unsplash.com/photo-1613843433065-819a04a47a09?w=800&auto=format",
      tags: ["hygiene", "health", "routines"]
    },
    {
      id: 7,
      title: "The Science of Language Learning in Early Childhood",
      category: "Language Learning",
      date: "March 9, 2024",
      author: "Prof. James Miller",
      excerpt: "Discover how children naturally acquire language skills and how to support their learning journey.",
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&auto=format",
      tags: ["language", "science", "development"]
    },
    {
      id: 8,
      title: "Teaching Children to Care for the Planet",
      category: "Eco-Friendly Systems",
      date: "March 8, 2024",
      author: "Emily Nature",
      excerpt: "Engaging activities to help children understand and protect our environment.",
      image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&auto=format",
      tags: ["environment", "education", "activities"]
    },
    {
      id: 9,
      title: "Building a Supportive Parenting Community",
      category: "Community Building",
      date: "March 7, 2024",
      author: "Rachel Foster",
      excerpt: "How to create and nurture a network of supportive parents in your community.",
      image: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format",
      tags: ["community", "support", "networking"]
    },
    {
      id: 10,
      title: "Managing Parental Stress and Its Impact",
      category: "Psychology",
      date: "March 6, 2024",
      author: "Dr. Mark Stevens",
      excerpt: "Understanding and managing parental stress for a healthier family dynamic.",
      image: "https://images.unsplash.com/photo-1534644107580-3a4dbd494a95?w=800&auto=format",
      tags: ["stress", "mental health", "parenting"]
    },
    {
      id: 11,
      title: "The Role of Nutrition in Child Development",
      category: "Food & Nutrition",
      date: "March 5, 2024",
      author: "Dr. Sarah Lee",
      excerpt: "Understanding how proper nutrition supports your child's growth and development.",
      image: "https://images.unsplash.com/photo-1490818387583-1baba5e638af?w=800&auto=format",
      tags: ["nutrition", "development", "health"]
    },
    {
      id: 12,
      title: "Understanding Childhood Allergies",
      category: "Health & Hygiene",
      date: "March 4, 2024",
      author: "Dr. Robert Allen",
      excerpt: "Essential information about common childhood allergies and prevention strategies.",
      image: "https://images.unsplash.com/photo-1584362917165-526a968579e8?w=800&auto=format",
      tags: ["allergies", "health", "prevention"]
    }
  ];

  const categories = [
    { id: 'all', label: 'All Posts' },
    { id: 'Language Learning', label: 'Language Learning' },
    { id: 'Eco-Friendly Systems', label: 'Eco-Friendly' },
    { id: 'Community Building', label: 'Community' },
    { id: 'Psychology', label: 'Psychology' },
    { id: 'Food & Nutrition', label: 'Nutrition' },
    { id: 'Health & Hygiene', label: 'Health' }
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Childland Blog
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Insights and resources for eco-conscious, bilingual parenting
          </p>
        </section>

        {/* Search and Filter */}
        <section className="mb-12">
          <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-2xl border border-accent/20">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Search */}
              <div className="flex-1 relative">
                <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-accent" />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-primary-dark/50 border border-accent/20 rounded-xl py-3 pl-12 pr-4 text-white focus:border-accent outline-none"
                />
              </div>
              
              {/* Categories */}
              <div className="flex gap-3 flex-wrap">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-4 py-2 rounded-xl transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-accent text-primary-dark'
                        : 'bg-primary-dark/50 text-gray-300 hover:text-accent'
                    }`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Blog Posts Grid */}
        <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-primary/30 backdrop-blur-lg rounded-2xl border border-accent/20 overflow-hidden hover:border-accent/40 transition-all"
            >
              <div className="relative h-48">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-dark/80 to-transparent"></div>
                <div className="absolute bottom-4 left-4">
                  <div className="flex items-center gap-2 text-sm text-accent-light">
                    <FaCalendar className="text-accent" />
                    {post.date}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-2 mb-2 text-sm text-gray-400">
                  <FaUser className="text-accent" />
                  {post.author}
                </div>
                
                <h2 className="text-xl font-bold text-accent-light mb-3">
                  {post.title}
                </h2>
                
                <p className="text-gray-300 mb-4">
                  {post.excerpt}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {post.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="text-xs bg-primary-dark/50 text-accent px-2 py-1 rounded-lg"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex justify-between items-center">
                  <button className="text-accent hover:text-accent-light transition-colors">
                    Read More →
                  </button>
                  <div className="flex items-center gap-1 text-gray-400">
                    <FaComments className="text-accent" />
                    <span>12</span>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </section>

        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No articles found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Blog;