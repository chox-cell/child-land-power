-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_activities_parent_id ON activities(parent_id);
CREATE INDEX IF NOT EXISTS idx_activities_child_id ON activities(child_id);
CREATE INDEX IF NOT EXISTS idx_activities_activity_type ON activities(activity_type);
CREATE INDEX IF NOT EXISTS idx_milestones_category ON milestones(category);
CREATE INDEX IF NOT EXISTS idx_milestones_importance ON milestones(importance);
CREATE INDEX IF NOT EXISTS idx_visit_requests_status ON visit_requests(status);
CREATE INDEX IF NOT EXISTS idx_milestone_resources_milestone_id ON milestone_resources(milestone_id);
CREATE INDEX IF NOT EXISTS idx_milestone_resources_resource_type ON milestone_resources(resource_type);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver_id ON messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_messages_status ON messages(status);

-- Add composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_activities_parent_child ON activities(parent_id, child_id);
CREATE INDEX IF NOT EXISTS idx_messages_participants ON messages(sender_id, receiver_id);

-- Add helpful comments
COMMENT ON INDEX idx_profiles_role IS 'Index for filtering users by role';
COMMENT ON INDEX idx_activities_parent_id IS 'Index for filtering activities by parent';
COMMENT ON INDEX idx_activities_child_id IS 'Index for filtering activities by child';
COMMENT ON INDEX idx_activities_activity_type IS 'Index for filtering activities by type';
COMMENT ON INDEX idx_milestones_category IS 'Index for filtering milestones by category';
COMMENT ON INDEX idx_milestones_importance IS 'Index for filtering milestones by importance';
COMMENT ON INDEX idx_visit_requests_status IS 'Index for filtering visit requests by status';
COMMENT ON INDEX idx_milestone_resources_milestone_id IS 'Index for filtering resources by milestone';
COMMENT ON INDEX idx_milestone_resources_resource_type IS 'Index for filtering resources by type';
COMMENT ON INDEX idx_messages_sender_id IS 'Index for filtering messages by sender';
COMMENT ON INDEX idx_messages_receiver_id IS 'Index for filtering messages by receiver';
COMMENT ON INDEX idx_messages_status IS 'Index for filtering messages by status';