/*
  # Add Charts and Chart Data Tables
  
  1. New Tables
    - charts: Stores chart configurations and metadata
    - chart_data: Stores the actual data points for each chart
  
  2. Security
    - Enable RLS on both tables
    - Add policies for viewing and managing charts
    - Add policies for viewing and managing chart data
  
  3. Features
    - Automatic updated_at timestamp management
    - Sample data for demonstration
*/

-- Create charts table
CREATE TABLE IF NOT EXISTS charts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  type text NOT NULL,
  description text,
  config jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create chart_data table
CREATE TABLE IF NOT EXISTS chart_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chart_id uuid REFERENCES charts NOT NULL,
  label text NOT NULL,
  value numeric NOT NULL,
  category text,
  date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE charts ENABLE ROW LEVEL SECURITY;
ALTER TABLE chart_data ENABLE ROW LEVEL SECURITY;

-- Create policies for charts
CREATE POLICY "Anyone can view active charts"
  ON charts
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only admins can manage charts"
  ON charts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for chart_data
CREATE POLICY "Anyone can view chart data"
  ON chart_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM charts
      WHERE id = chart_id
      AND is_active = true
    )
  );

CREATE POLICY "Only admins can manage chart data"
  ON chart_data
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create triggers
DROP TRIGGER IF EXISTS update_charts_updated_at ON charts;
CREATE TRIGGER update_charts_updated_at
  BEFORE UPDATE ON charts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_chart_data_updated_at ON chart_data;
CREATE TRIGGER update_chart_data_updated_at
  BEFORE UPDATE ON chart_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert sample chart data
INSERT INTO charts (title, type, description, config)
VALUES 
  (
    'Eco Impact Overview',
    'line',
    'Monthly tracking of our environmental impact metrics',
    '{
      "xAxis": "date",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  ),
  (
    'Resource Conservation',
    'bar',
    'Comparison of resource conservation metrics',
    '{
      "xAxis": "category",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  );

-- Insert sample chart data points
WITH chart_ids AS (
  SELECT id, type FROM charts
)
INSERT INTO chart_data (chart_id, label, value, category, date)
SELECT 
  c.id,
  CASE 
    WHEN c.type = 'line' THEN 'Waste Reduced'
    ELSE 'Water Saved'
  END,
  CASE 
    WHEN c.type = 'line' THEN random() * 100
    ELSE random() * 1000
  END,
  CASE 
    WHEN c.type = 'line' THEN NULL
    ELSE 'Conservation'
  END,
  now() - (i || ' days')::interval
FROM chart_ids c
CROSS JOIN generate_series(0, 30) i;