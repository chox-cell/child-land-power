import { emailConfig } from '../config/email';

export const sendEmail = async (type, to, data) => {
  try {
    const template = emailConfig.emailTemplates[type];
    if (!template) {
      throw new Error('Email template not found');
    }

    // For development, log the email instead of sending
    if (import.meta.env.DEV) {
      console.log('Email would be sent:', {
        to,
        from: template.from,
        subject: template.subject,
        text: generatePlainTextEmail(type, data),
        html: generateHtmlEmail(type, data),
      });
      return { success: true, response: 'Email logged in development' };
    }

    // In production, implement your email sending logic here
    // This is a placeholder for the actual email sending implementation
    return { success: true, response: 'Email sent successfully' };
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error: error.message };
  }
};

export const notifyAdmin = async (subject, content) => {
  try {
    // For development, log the notification instead of sending
    if (import.meta.env.DEV) {
      console.log('Admin notification would be sent:', {
        to: emailConfig.adminEmail,
        from: emailConfig.noReplyEmail,
        subject,
        content
      });
      return { success: true, response: 'Notification logged in development' };
    }

    // In production, implement your notification logic here
    return { success: true, response: 'Notification sent successfully' };
  } catch (error) {
    console.error('Error notifying admin:', error);
    return { success: false, error: error.message };
  }
};

function generatePlainTextEmail(type, data) {
  switch (type) {
    case 'welcome':
      return `Welcome to Childland!\n\nDear ${data.name},\n\nThank you for joining our eco-conscious bilingual childcare community. We're excited to have you with us!\n\nBest regards,\nThe Childland Team`;
    
    case 'visitRequest':
      return `New Visit Request\n\nName: ${data.name}\nEmail: ${data.email}\nPhone: ${data.phone}\nPreferred Date: ${data.date}\nPreferred Time: ${data.time}\nNumber of Children: ${data.numberOfChildren}\nChildren's Ages: ${data.childrenAges}\n\nMessage: ${data.message}`;
    
    case 'registration':
      return `Registration Confirmation\n\nDear ${data.name},\n\nYour registration at Childland has been confirmed. We look forward to welcoming you and your child!\n\nBest regards,\nThe Childland Team`;
    
    case 'payment':
      return `Payment Confirmation\n\nDear ${data.name},\n\nYour payment of €${data.amount} has been successfully processed.\n\nPayment Details:\nTransaction ID: ${data.transactionId}\nDate: ${data.date}\n\nThank you for your payment!\n\nBest regards,\nThe Childland Team`;
    
    default:
      return '';
  }
}

function generateHtmlEmail(type, data) {
  const baseStyle = 'font-family: Arial, sans-serif; color: #333;';
  const headerStyle = 'color: #4A3B8F; font-size: 24px; margin-bottom: 20px;';
  const paragraphStyle = 'margin-bottom: 15px; line-height: 1.5;';

  switch (type) {
    case 'welcome':
      return `
        <div style="${baseStyle}">
          <h1 style="${headerStyle}">Welcome to Childland!</h1>
          <p style="${paragraphStyle}">Dear ${data.name},</p>
          <p style="${paragraphStyle}">Thank you for joining our eco-conscious bilingual childcare community. We're excited to have you with us!</p>
          <p style="${paragraphStyle}">Best regards,<br>The Childland Team</p>
        </div>
      `;
    
    case 'visitRequest':
      return `
        <div style="${baseStyle}">
          <h1 style="${headerStyle}">New Visit Request</h1>
          <div style="${paragraphStyle}">
            <p><strong>Name:</strong> ${data.name}</p>
            <p><strong>Email:</strong> ${data.email}</p>
            <p><strong>Phone:</strong> ${data.phone}</p>
            <p><strong>Preferred Date:</strong> ${data.date}</p>
            <p><strong>Preferred Time:</strong> ${data.time}</p>
            <p><strong>Number of Children:</strong> ${data.numberOfChildren}</p>
            <p><strong>Children's Ages:</strong> ${data.childrenAges}</p>
            <p><strong>Message:</strong> ${data.message}</p>
          </div>
        </div>
      `;
    
    case 'registration':
      return `
        <div style="${baseStyle}">
          <h1 style="${headerStyle}">Registration Confirmation</h1>
          <p style="${paragraphStyle}">Dear ${data.name},</p>
          <p style="${paragraphStyle}">Your registration at Childland has been confirmed. We look forward to welcoming you and your child!</p>
          <p style="${paragraphStyle}">Best regards,<br>The Childland Team</p>
        </div>
      `;
    
    case 'payment':
      return `
        <div style="${baseStyle}">
          <h1 style="${headerStyle}">Payment Confirmation</h1>
          <p style="${paragraphStyle}">Dear ${data.name},</p>
          <p style="${paragraphStyle}">Your payment of €${data.amount} has been successfully processed.</p>
          <div style="${paragraphStyle}">
            <h2 style="color: #4A3B8F; font-size: 18px;">Payment Details:</h2>
            <p><strong>Transaction ID:</strong> ${data.transactionId}</p>
            <p><strong>Date:</strong> ${data.date}</p>
          </div>
          <p style="${paragraphStyle}">Thank you for your payment!</p>
          <p style="${paragraphStyle}">Best regards,<br>The Childland Team</p>
        </div>
      `;
    
    default:
      return '';
  }
}