-- Function to notify on new activities
CREATE OR REPLACE FUNCTION notify_new_activity()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  -- Insert notification for parent
  INSERT INTO notifications (
    user_id,
    type,
    title,
    content,
    metadata
  )
  SELECT
    NEW.parent_id,
    'activity',
    'New Activity Recorded',
    NEW.title,
    jsonb_build_object(
      'activity_id', NEW.id,
      'child_id', NEW.child_id,
      'description', NEW.description
    );
  RETURN NEW;
END;
$$;

-- Function to notify on new photos
CREATE OR REPLACE FUNCTION notify_new_photo()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  -- Insert notification for parent
  INSERT INTO notifications (
    user_id,
    type,
    title,
    content,
    metadata
  )
  SELECT
    NEW.parent_id,
    'photo',
    'New Photo Added',
    COALESCE(NEW.description, 'A new photo has been added'),
    jsonb_build_object(
      'photo_id', NEW.id,
      'child_id', NEW.child_id,
      'url', NEW.url
    );
  RETURN NEW;
END;
$$;

-- Function to notify on milestone achievements
CREATE OR REPLACE FUNCTION notify_milestone_achievement()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  -- Insert notification for parent
  INSERT INTO notifications (
    user_id,
    type,
    title,
    content,
    metadata
  )
  SELECT
    c.parent_id,
    'milestone',
    'Milestone Achieved',
    m.title,
    jsonb_build_object(
      'milestone_id', NEW.milestone_id,
      'child_id', NEW.child_id,
      'achieved_at', NEW.achieved_at
    )
  FROM children c
  JOIN milestones m ON m.id = NEW.milestone_id
  WHERE c.id = NEW.child_id;
  RETURN NEW;
END;
$$;

-- Function to notify on new messages
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  -- Insert notification for recipient
  INSERT INTO notifications (
    user_id,
    type,
    title,
    content,
    metadata
  )
  VALUES (
    NEW.receiver_id,
    'message',
    'New Message',
    substring(NEW.content from 1 for 100),
    jsonb_build_object(
      'message_id', NEW.id,
      'sender_id', NEW.sender_id
    )
  );
  RETURN NEW;
END;
$$;

-- Create notifications table if it doesn't exist
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  content text,
  metadata jsonb DEFAULT '{}',
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create policy for notifications
CREATE POLICY "Users can view their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policy for marking notifications as read
CREATE POLICY "Users can update their own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create triggers for notifications
CREATE TRIGGER notify_on_new_activity
  AFTER INSERT ON activities
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_activity();

CREATE TRIGGER notify_on_new_photo
  AFTER INSERT ON photos
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_photo();

CREATE TRIGGER notify_on_milestone_achievement
  AFTER INSERT ON child_milestones
  FOR EACH ROW
  EXECUTE FUNCTION notify_milestone_achievement();

CREATE TRIGGER notify_on_new_message
  AFTER INSERT ON messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_message();

-- Add updated_at trigger for notifications
CREATE TRIGGER update_notifications_updated_at
  BEFORE UPDATE ON notifications
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add indexes for notifications
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_read ON notifications(read);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);

COMMENT ON TABLE notifications IS 'System notifications for users';
COMMENT ON FUNCTION notify_new_activity() IS 'Trigger function to create notifications for new activities';
COMMENT ON FUNCTION notify_new_photo() IS 'Trigger function to create notifications for new photos';
COMMENT ON FUNCTION notify_milestone_achievement() IS 'Trigger function to create notifications for milestone achievements';
COMMENT ON FUNCTION notify_new_message() IS 'Trigger function to create notifications for new messages';