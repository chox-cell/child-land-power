-- Create test_table first if it doesn't exist
CREATE TABLE IF NOT EXISTS test_table (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
ALTER TABLE test_table ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "rls_test_select" ON test_table;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create new policy
CREATE POLICY "rls_test_select"
  ON test_table
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index on user_id if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_test_table_user_id ON test_table(user_id);

-- Add updated_at trigger if it doesn't exist
DO $$ 
BEGIN
    CREATE TRIGGER update_test_table_updated_at
        BEFORE UPDATE ON test_table
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;