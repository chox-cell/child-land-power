-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS update_eco_metrics_updated_at ON eco_metrics;
DROP TRIGGER IF EXISTS update_charts_updated_at ON charts;
DROP TRIGGER IF EXISTS update_chart_data_updated_at ON chart_data;

-- Drop existing function if exists
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- Create updated_at function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create tables and other objects...
-- Rest of the migration remains the same as before