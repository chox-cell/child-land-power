-- Create test_table first
CREATE TABLE IF NOT EXISTS test_table (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE test_table ENABLE ROW LEVEL SECURITY;

-- Create policy for viewing test_table records
CREATE POLICY "rls_test_select"
  ON test_table
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Add updated_at trigger
CREATE TRIGGER update_test_table_updated_at
  BEFORE UPDATE ON test_table
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();