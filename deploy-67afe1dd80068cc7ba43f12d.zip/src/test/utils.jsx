import React from 'react';
import { render } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '../contexts/AuthContext';
import { RealtimeProvider } from '../contexts/RealtimeContext';

export function renderWithProviders(ui, { route = '/' } = {}) {
  window.history.pushState({}, 'Test page', route);

  return {
    ...render(
      <BrowserRouter>
        <AuthProvider>
          <RealtimeProvider>
            {ui}
          </RealtimeProvider>
        </AuthProvider>
      </BrowserRouter>
    ),
  };
}

export * from '@testing-library/react';
export { default as userEvent } from '@testing-library/user-event';