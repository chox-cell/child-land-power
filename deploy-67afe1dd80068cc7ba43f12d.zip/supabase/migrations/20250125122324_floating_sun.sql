-- Create custom admin role with elevated privileges
CREATE ROLE app_admin;

-- Grant necessary privileges
GRANT USAGE ON SCHEMA public TO app_admin;
GRANT ALL ON ALL TABLES IN SCHEMA public TO app_admin;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO app_admin;

-- Set up default privileges
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
GRANT ALL ON TABLES TO app_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA public 
GRANT ALL ON SEQUENCES TO app_admin;

-- Add comment explaining the role
COMMENT ON ROLE app_admin IS 'Application admin role with elevated privileges for system operations';