import React from 'react';
import { trackError } from '../utils/monitoring';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Track error with our custom monitoring
    trackError(error, {
      componentStack: errorInfo.componentStack,
      boundary: 'ErrorBoundary'
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white flex items-center justify-center p-4">
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20 max-w-md w-full">
            <div className="text-center mb-6">
              <span role="img" aria-label="error" className="text-4xl">⚠️</span>
            </div>
            <h2 className="text-2xl font-bold text-accent mb-4 text-center">
              Something went wrong
            </h2>
            <p className="text-gray-300 mb-6 text-center">
              We're sorry, but something went wrong. Our team has been notified and we'll fix it as soon as possible.
            </p>
            <div className="flex flex-col gap-4">
              <button
                onClick={() => window.location.reload()}
                className="w-full bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors"
              >
                Reload Page
              </button>
              <button
                onClick={() => window.history.back()}
                className="w-full border border-accent text-accent px-6 py-3 rounded-xl hover:bg-accent hover:text-primary-dark transition-colors"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export { ErrorBoundary };