import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaChild, FaCalendarAlt, FaHeartbeat, FaPhoneAlt, FaUserFriends } from 'react-icons/fa';
import toast from 'react-hot-toast';

function RegisterChild() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    allergies: '',
    medicalConditions: '',
    medications: '',
    emergencyContact1: {
      name: '',
      relationship: '',
      phone: ''
    },
    emergencyContact2: {
      name: '',
      relationship: '',
      phone: ''
    },
    doctorName: '',
    doctorPhone: '',
    insuranceProvider: '',
    insuranceNumber: '',
    additionalNotes: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Here you would typically send the data to your backend
      toast.success('Child registered successfully!');
      navigate('/portal');
    } catch (error) {
      toast.error('Failed to register child. Please try again.');
      console.error('Error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-primary mb-8 text-center">Register a Child</h1>

          <form onSubmit={handleSubmit} className="card space-y-8">
            {/* Basic Information */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4 flex items-center gap-2">
                <FaChild />
                Basic Information
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-text-secondary mb-2">First Name</label>
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                    className="input w-full"
                    required
                  />
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Last Name</label>
                  <input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                    className="input w-full"
                    required
                  />
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Date of Birth</label>
                  <div className="relative">
                    <FaCalendarAlt className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary" />
                    <input
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
                      className="input w-full pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                    className="input w-full"
                    required
                  >
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
            </section>

            {/* Medical Information */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4 flex items-center gap-2">
                <FaHeartbeat />
                Medical Information
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-text-secondary mb-2">Allergies</label>
                  <textarea
                    value={formData.allergies}
                    onChange={(e) => setFormData({...formData, allergies: e.target.value})}
                    className="input w-full"
                    rows="2"
                    placeholder="List any allergies..."
                  ></textarea>
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Medical Conditions</label>
                  <textarea
                    value={formData.medicalConditions}
                    onChange={(e) => setFormData({...formData, medicalConditions: e.target.value})}
                    className="input w-full"
                    rows="2"
                    placeholder="List any medical conditions..."
                  ></textarea>
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Current Medications</label>
                  <textarea
                    value={formData.medications}
                    onChange={(e) => setFormData({...formData, medications: e.target.value})}
                    className="input w-full"
                    rows="2"
                    placeholder="List any medications..."
                  ></textarea>
                </div>
              </div>
            </section>

            {/* Emergency Contacts */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4 flex items-center gap-2">
                <FaUserFriends />
                Emergency Contacts
              </h2>
              <div className="space-y-6">
                {/* Emergency Contact 1 */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-text-secondary mb-2">Name</label>
                    <input
                      type="text"
                      value={formData.emergencyContact1.name}
                      onChange={(e) => setFormData({
                        ...formData,
                        emergencyContact1: {...formData.emergencyContact1, name: e.target.value}
                      })}
                      className="input w-full"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-text-secondary mb-2">Relationship</label>
                    <input
                      type="text"
                      value={formData.emergencyContact1.relationship}
                      onChange={(e) => setFormData({
                        ...formData,
                        emergencyContact1: {...formData.emergencyContact1, relationship: e.target.value}
                      })}
                      className="input w-full"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-text-secondary mb-2">Phone</label>
                    <div className="relative">
                      <FaPhoneAlt className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary" />
                      <input
                        type="tel"
                        value={formData.emergencyContact1.phone}
                        onChange={(e) => setFormData({
                          ...formData,
                          emergencyContact1: {...formData.emergencyContact1, phone: e.target.value}
                        })}
                        className="input w-full pl-10"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Emergency Contact 2 */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-text-secondary mb-2">Name</label>
                    <input
                      type="text"
                      value={formData.emergencyContact2.name}
                      onChange={(e) => setFormData({
                        ...formData,
                        emergencyContact2: {...formData.emergencyContact2, name: e.target.value}
                      })}
                      className="input w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-text-secondary mb-2">Relationship</label>
                    <input
                      type="text"
                      value={formData.emergencyContact2.relationship}
                      onChange={(e) => setFormData({
                        ...formData,
                        emergencyContact2: {...formData.emergencyContact2, relationship: e.target.value}
                      })}
                      className="input w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-text-secondary mb-2">Phone</label>
                    <div className="relative">
                      <FaPhoneAlt className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary" />
                      <input
                        type="tel"
                        value={formData.emergencyContact2.phone}
                        onChange={(e) => setFormData({
                          ...formData,
                          emergencyContact2: {...formData.emergencyContact2, phone: e.target.value}
                        })}
                        className="input w-full pl-10"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Medical Provider Information */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">Medical Provider Information</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-text-secondary mb-2">Doctor's Name</label>
                  <input
                    type="text"
                    value={formData.doctorName}
                    onChange={(e) => setFormData({...formData, doctorName: e.target.value})}
                    className="input w-full"
                    required
                  />
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Doctor's Phone</label>
                  <div className="relative">
                    <FaPhoneAlt className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary" />
                    <input
                      type="tel"
                      value={formData.doctorPhone}
                      onChange={(e) => setFormData({...formData, doctorPhone: e.target.value})}
                      className="input w-full pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Insurance Provider</label>
                  <input
                    type="text"
                    value={formData.insuranceProvider}
                    onChange={(e) => setFormData({...formData, insuranceProvider: e.target.value})}
                    className="input w-full"
                    required
                  />
                </div>
                <div>
                  <label className="block text-text-secondary mb-2">Insurance Number</label>
                  <input
                    type="text"
                    value={formData.insuranceNumber}
                    onChange={(e) => setFormData({...formData, insuranceNumber: e.target.value})}
                    className="input w-full"
                    required
                  />
                </div>
              </div>
            </section>

            {/* Additional Notes */}
            <section>
              <label className="block text-text-secondary mb-2">Additional Notes</label>
              <textarea
                value={formData.additionalNotes}
                onChange={(e) => setFormData({...formData, additionalNotes: e.target.value})}
                className="input w-full"
                rows="4"
                placeholder="Any additional information we should know..."
              ></textarea>
            </section>

            <button
              type="submit"
              className="btn-primary w-full"
            >
              Register Child
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default RegisterChild;