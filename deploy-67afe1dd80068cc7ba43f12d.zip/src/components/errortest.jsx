import React from 'react';
import * as Sentry from '@sentry/react';
import { trackError } from '../utils/monitoring';

function ErrorTest() {
  const throwError = () => {
    try {
      throw new Error("This is a test error!");
    } catch (error) {
      // Track error with both Sentry and our custom monitoring
      Sentry.captureException(error, {
        tags: {
          component: 'ErrorTest',
          type: 'test-error'
        },
        extra: {
          timestamp: new Date().toISOString(),
          location: 'ErrorTest component'
        }
      });
      trackError(error, {
        component: 'ErrorTest',
        type: 'test-error'
      });
      throw error; // Re-throw to trigger error boundary
    }
  };

  return (
    <button
      onClick={throwError}
      className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
      aria-label="Trigger test error"
    >
      <span role="img" aria-label="warning">⚠️</span>
      Trigger Test Error
    </button>
  );
}

export default ErrorTest;