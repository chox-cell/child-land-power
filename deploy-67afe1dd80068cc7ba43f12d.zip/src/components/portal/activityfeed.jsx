import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

function ActivityFeed({ session }) {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchActivities();

    // Subscribe to real-time updates
    const subscription = supabase
      .channel('activities')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'activities',
        filter: `parent_id=eq.${session.user.id}`
      }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setActivities(current => [payload.new, ...current]);
        } else if (payload.eventType === 'DELETE') {
          setActivities(current => current.filter(activity => activity.id !== payload.old.id));
        } else if (payload.eventType === 'UPDATE') {
          setActivities(current => current.map(activity => 
            activity.id === payload.new.id ? payload.new : activity
          ));
        }
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [session]);

  async function fetchActivities() {
    try {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .eq('parent_id', session.user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setActivities(data);
    } catch (error) {
      toast.error('Error loading activities');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {activities.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          No activities recorded yet
        </div>
      ) : (
        activities.map((activity) => (
          <div
            key={activity.id}
            className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20"
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-semibold text-accent-light">
                {activity.title}
              </h3>
              <span className="text-sm text-gray-400">
                {format(new Date(activity.created_at), 'PPp')}
              </span>
            </div>
            <p className="text-gray-300 mb-4">{activity.description}</p>
            {activity.metrics && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(activity.metrics).map(([key, value]) => (
                  <div
                    key={key}
                    className="bg-primary-dark/30 p-3 rounded-lg text-center"
                  >
                    <div className="text-sm text-gray-400">{key}</div>
                    <div className="text-accent font-semibold">{value}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}

export default ActivityFeed;