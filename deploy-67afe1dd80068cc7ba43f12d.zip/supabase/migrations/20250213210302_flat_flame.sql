-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";      -- For UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";       -- For cryptographic functions
CREATE EXTENSION IF NOT EXISTS "citext";         -- For case-insensitive text fields
CREATE EXTENSION IF NOT EXISTS "pg_trgm";        -- For text search and similarity
CREATE EXTENSION IF NOT EXISTS "unaccent";       -- For accent-insensitive search
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements"; -- For query performance monitoring

-- Add text search configuration for French and English
DO $$ 
BEGIN
  -- Create French configuration if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_ts_config WHERE cfgname = 'french_unaccent'
  ) THEN
    CREATE TEXT SEARCH CONFIGURATION french_unaccent ( COPY = french );
    ALTER TEXT SEARCH CONFIGURATION french_unaccent 
      ALTER MAPPING FOR hword, hword_part, word 
      WITH unaccent, french_stem;
  END IF;

  -- Create English configuration if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_ts_config WHERE cfgname = 'english_unaccent'
  ) THEN
    CREATE TEXT SEARCH CONFIGURATION english_unaccent ( COPY = english );
    ALTER TEXT SEARCH CONFIGURATION english_unaccent 
      ALTER MAPPING FOR hword, hword_part, word 
      WITH unaccent, english_stem;
  END IF;
END $$;

-- Add helpful comments
COMMENT ON EXTENSION "uuid-ossp" IS 'UUID generation functions';
COMMENT ON EXTENSION "pgcrypto" IS 'Cryptographic functions';
COMMENT ON EXTENSION "citext" IS 'Case-insensitive character string type';
COMMENT ON EXTENSION "pg_trgm" IS 'Text similarity measurement and index searching';
COMMENT ON EXTENSION "unaccent" IS 'Text search dictionary that removes accents';
COMMENT ON EXTENSION "pg_stat_statements" IS 'Track planning and execution statistics of all SQL statements executed';