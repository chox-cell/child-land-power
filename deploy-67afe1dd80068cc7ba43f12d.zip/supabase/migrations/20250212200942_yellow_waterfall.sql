/*
  # Fix Enum Type Migration
  
  1. Create enum types
  2. Add new columns
  3. Convert data safely
  4. Drop old columns
  5. Add constraints
*/

-- First, create all enum types
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('parent', 'staff', 'admin');
    CREATE TYPE activity_type AS ENUM ('learning', 'play', 'meal', 'nap', 'outdoor', 'art', 'music', 'milestone', 'other');
    CREATE TYPE milestone_category AS ENUM ('language', 'cognitive', 'physical', 'social');
    CREATE TYPE milestone_importance AS ENUM ('essential', 'significant', 'supportive');
    CREATE TYPE notification_type AS ENUM ('activity', 'photo', 'milestone', 'message', 'system');
    CREATE TYPE visit_request_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
    CREATE TYPE resource_type AS ENUM ('activity', 'guide', 'video', 'article');
    CREATE TYPE message_status AS ENUM ('sent', 'delivered', 'read');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Convert profiles table
DO $$ BEGIN
    -- Add new column without constraints first
    ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role_new user_role;
    
    -- Convert data
    UPDATE profiles SET role_new = role::user_role;
    
    -- Add constraints and drop old column
    ALTER TABLE profiles 
        ALTER COLUMN role_new SET NOT NULL,
        ALTER COLUMN role_new SET DEFAULT 'parent'::user_role,
        DROP COLUMN role CASCADE;
    
    -- Rename new column
    ALTER TABLE profiles RENAME COLUMN role_new TO role;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Convert activities table
DO $$ BEGIN
    ALTER TABLE activities ADD COLUMN IF NOT EXISTS activity_type_new activity_type;
    UPDATE activities SET activity_type_new = COALESCE(activity_type::activity_type, 'other'::activity_type);
    ALTER TABLE activities 
        ALTER COLUMN activity_type_new SET NOT NULL,
        ALTER COLUMN activity_type_new SET DEFAULT 'other'::activity_type,
        DROP COLUMN IF EXISTS activity_type CASCADE;
    ALTER TABLE activities RENAME COLUMN activity_type_new TO activity_type;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Convert milestones table
DO $$ BEGIN
    -- Add new columns
    ALTER TABLE milestones 
        ADD COLUMN IF NOT EXISTS category_new milestone_category,
        ADD COLUMN IF NOT EXISTS importance_new milestone_importance;
    
    -- Convert data
    UPDATE milestones SET 
        category_new = category::milestone_category,
        importance_new = importance::milestone_importance;
    
    -- Add constraints and drop old columns
    ALTER TABLE milestones 
        ALTER COLUMN category_new SET NOT NULL,
        ALTER COLUMN importance_new SET NOT NULL,
        DROP COLUMN IF EXISTS category CASCADE,
        DROP COLUMN IF EXISTS importance CASCADE;
    
    -- Rename new columns
    ALTER TABLE milestones 
        RENAME COLUMN category_new TO category;
    ALTER TABLE milestones 
        RENAME COLUMN importance_new TO importance;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Convert visit_requests table
DO $$ BEGIN
    ALTER TABLE visit_requests ADD COLUMN IF NOT EXISTS status_new visit_request_status;
    UPDATE visit_requests SET status_new = COALESCE(status::visit_request_status, 'pending'::visit_request_status);
    ALTER TABLE visit_requests 
        ALTER COLUMN status_new SET NOT NULL,
        ALTER COLUMN status_new SET DEFAULT 'pending'::visit_request_status,
        DROP COLUMN IF EXISTS status CASCADE;
    ALTER TABLE visit_requests RENAME COLUMN status_new TO status;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Convert milestone_resources table
DO $$ BEGIN
    ALTER TABLE milestone_resources ADD COLUMN IF NOT EXISTS resource_type_new resource_type;
    UPDATE milestone_resources SET resource_type_new = resource_type::resource_type;
    ALTER TABLE milestone_resources 
        ALTER COLUMN resource_type_new SET NOT NULL,
        DROP COLUMN IF EXISTS resource_type CASCADE;
    ALTER TABLE milestone_resources RENAME COLUMN resource_type_new TO resource_type;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Convert messages table
DO $$ BEGIN
    ALTER TABLE messages ADD COLUMN IF NOT EXISTS status_new message_status;
    UPDATE messages SET status_new = COALESCE(status::message_status, 'sent'::message_status);
    ALTER TABLE messages 
        ALTER COLUMN status_new SET NOT NULL,
        ALTER COLUMN status_new SET DEFAULT 'sent'::message_status,
        DROP COLUMN IF EXISTS status CASCADE;
    ALTER TABLE messages RENAME COLUMN status_new TO status;
EXCEPTION
    WHEN others THEN null;
END $$;

-- Add helpful comments
COMMENT ON TYPE user_role IS 'Enumerated type for user roles in the system';
COMMENT ON TYPE activity_type IS 'Types of activities that can be recorded';
COMMENT ON TYPE milestone_category IS 'Categories of developmental milestones';
COMMENT ON TYPE milestone_importance IS 'Importance levels for milestones';
COMMENT ON TYPE notification_type IS 'Types of system notifications';
COMMENT ON TYPE visit_request_status IS 'Status options for visit requests';
COMMENT ON TYPE resource_type IS 'Types of educational resources';
COMMENT ON TYPE message_status IS 'Status of messages in the system';