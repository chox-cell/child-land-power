import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { RealtimeProvider } from './contexts/RealtimeContext';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import About from './pages/About';
import Programs from './pages/Programs';
import Sustainability from './pages/Sustainability';
import Admissions from './pages/Admissions';
import Contact from './pages/Contact';
import Portal from './pages/Portal';
import RegisterChild from './pages/RegisterChild';
import ScheduleVisit from './pages/ScheduleVisit';
import VirtualTour from './pages/VirtualTour';
import Payment from './pages/Payment';
import Blog from './pages/Blog';
import Donate from './pages/Donate';
import Login from './pages/Login';
import Register from './pages/Register';
import ChangePassword from './pages/ChangePassword';
import ResetPassword from './pages/ResetPassword';

function App() {
  return (
    <AuthProvider>
      <RealtimeProvider>
        <div className="min-h-screen bg-white">
          <Navigation />
          <main className="bg-white">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/programs" element={<Programs />} />
              <Route path="/sustainability" element={<Sustainability />} />
              <Route path="/admissions" element={<Admissions />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/portal" element={<Portal />} />
              <Route path="/register-child" element={<RegisterChild />} />
              <Route path="/schedule-visit" element={<ScheduleVisit />} />
              <Route path="/virtual-tour" element={<VirtualTour />} />
              <Route path="/payment" element={<Payment />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/donate" element={<Donate />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/change-password" element={<ChangePassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
            </Routes>
          </main>
          <Toaster position="top-right" />
        </div>
      </RealtimeProvider>
    </AuthProvider>
  );
}

export default App;