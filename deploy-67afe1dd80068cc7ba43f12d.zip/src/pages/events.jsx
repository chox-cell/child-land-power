import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { format, parseISO, isFuture } from 'date-fns';
import { FaCalendar, FaClock, FaMapMarkerAlt, FaUsers, FaCheck, FaSpinner } from 'react-icons/fa';
import { supabase } from '../lib/supabaseClient';
import toast from 'react-hot-toast';

function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [registrationForm, setRegistrationForm] = useState({
    name: '',
    email: '',
    phone: '',
    attendees: 1
  });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const { data, error } = await supabase
        .from('events')
        .select(`
          *,
          registrations:event_registrations(
            status,
            user_id
          )
        `)
        .eq('is_active', true)
        .order('start_time');

      if (error) throw error;
      setEvents(data);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast.error('Failed to load events');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (event) => {
    if (!event) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast.error('Please sign in to register for events');
        return;
      }

      const registeredCount = event.registrations.filter(
        r => r.status === 'registered'
      ).length;

      const status = registeredCount >= event.max_attendees ? 'waitlisted' : 'registered';

      const { error } = await supabase
        .from('event_registrations')
        .insert([
          {
            event_id: event.id,
            user_id: user.id,
            status,
            attendees: registrationForm.attendees
          }
        ]);

      if (error) throw error;

      toast.success(
        status === 'registered' 
          ? 'Successfully registered for the event!' 
          : 'Added to the waitlist!'
      );

      setSelectedEvent(null);
      setRegistrationForm({
        name: '',
        email: '',
        phone: '',
        attendees: 1
      });
      
      fetchEvents();
    } catch (error) {
      console.error('Error registering for event:', error);
      toast.error('Failed to register for event');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Upcoming Events
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join us for workshops, playdates, and educational activities
          </p>
        </section>

        {/* Events Grid */}
        <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {events.filter(event => isFuture(parseISO(event.start_time))).map(event => {
            const registeredCount = event.registrations.filter(
              r => r.status === 'registered'
            ).length;
            const spotsLeft = event.max_attendees - registeredCount;

            return (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-primary/30 backdrop-blur-lg rounded-2xl border border-accent/20 overflow-hidden hover:border-accent/40 transition-all"
              >
                <div className="p-6">
                  <h3 className="text-xl font-bold text-accent-light mb-4">
                    {event.title}
                  </h3>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-gray-300">
                      <FaCalendar className="text-accent" />
                      {format(parseISO(event.start_time), 'EEEE, MMMM d, yyyy')}
                    </div>
                    <div className="flex items-center gap-2 text-gray-300">
                      <FaClock className="text-accent" />
                      {format(parseISO(event.start_time), 'h:mm a')} - 
                      {format(parseISO(event.end_time), 'h:mm a')}
                    </div>
                    <div className="flex items-center gap-2 text-gray-300">
                      <FaMapMarkerAlt className="text-accent" />
                      {event.location}
                    </div>
                    <div className="flex items-center gap-2 text-gray-300">
                      <FaUsers className="text-accent" />
                      {spotsLeft > 0 
                        ? `${spotsLeft} spots left`
                        : 'Waitlist available'}
                    </div>
                  </div>

                  <p className="text-gray-300 mb-6">{event.description}</p>

                  <button
                    onClick={() => setSelectedEvent(event)}
                    className="w-full bg-accent text-primary-dark py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
                  >
                    Register Now
                  </button>
                </div>
              </motion.div>
            );
          })}
        </section>

        {/* Registration Modal */}
        {selectedEvent && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-primary-dark/95 backdrop-blur-lg rounded-2xl p-8 max-w-md w-full"
            >
              <h2 className="text-2xl font-bold text-accent mb-6">
                Register for {selectedEvent.title}
              </h2>

              <form onSubmit={(e) => {
                e.preventDefault();
                handleRegister(selectedEvent);
              }}>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-accent-light mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      value={registrationForm.name}
                      onChange={(e) => setRegistrationForm({
                        ...registrationForm,
                        name: e.target.value
                      })}
                      className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-accent-light mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={registrationForm.email}
                      onChange={(e) => setRegistrationForm({
                        ...registrationForm,
                        email: e.target.value
                      })}
                      className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-accent-light mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={registrationForm.phone}
                      onChange={(e) => setRegistrationForm({
                        ...registrationForm,
                        phone: e.target.value
                      })}
                      className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-accent-light mb-2">
                      Number of Attendees
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={registrationForm.attendees}
                      onChange={(e) => setRegistrationForm({
                        ...registrationForm,
                        attendees: parseInt(e.target.value)
                      })}
                      className="w-full bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                      required
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="submit"
                    className="flex-1 bg-accent text-primary-dark py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
                  >
                    <FaCheck />
                    Confirm Registration
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedEvent(null)}
                    className="flex-1 border border-accent text-accent py-3 rounded-xl hover:bg-accent hover:text-primary-dark transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {events.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No upcoming events at the moment.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Events;