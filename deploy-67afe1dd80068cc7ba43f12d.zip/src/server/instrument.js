const Sentry = require("@sentry/node");
const { ProfilingIntegration } = require("@sentry/profiling-node");
const { nodeProfilingIntegration } = require("@sentry/profiling-node");

// Initialize Sentry
Sentry.init({
  dsn: process.env.VITE_SENTRY_NODE_DSN,
  integrations: [
    nodeProfilingIntegration(),
    new ProfilingIntegration(),
  ],
  tracesSampleRate: 1.0,
  profilesSampleRate: 1.0,
  environment: process.env.NODE_ENV
});