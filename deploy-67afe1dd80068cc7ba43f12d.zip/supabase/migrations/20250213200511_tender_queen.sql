-- Create function to handle new user signups
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'parent')
  );
  RETURN NEW;
END;
$$;

-- Create function to handle user deletions
CREATE OR REPLACE FUNCTION handle_deleted_user()
RETURNS trigger
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Delete user's profile
  DELETE FROM public.profiles WHERE id = OLD.id;
  RETURN OLD;
END;
$$;

-- Create trigger for new user signups
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Create trigger for user deletions
DROP TRIGGER IF EXISTS on_auth_user_deleted ON auth.users;
CREATE TRIGGER on_auth_user_deleted
  BEFORE DELETE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_deleted_user();

-- Add helpful comments
COMMENT ON FUNCTION handle_new_user IS 'Automatically creates a profile for new users';
COMMENT ON FUNCTION handle_deleted_user IS 'Cleans up user data when a user is deleted';
COMMENT ON TRIGGER on_auth_user_created ON auth.users IS 'Trigger to handle new user registration';
COMMENT ON TRIGGER on_auth_user_deleted ON auth.users IS 'Trigger to handle user deletion cleanup';