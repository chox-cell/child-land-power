import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUser, FaEnvelope, FaPhone, FaChild, FaCalendarAlt, FaFileAlt } from 'react-icons/fa';

function ApplyNow() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    parentName: '',
    email: '',
    phone: '',
    childName: '',
    childAge: '',
    startDate: '',
    program: 'full-time',
    additionalInfo: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Navigate to payment with selected program
    navigate('/payment', { state: { plan: formData.program } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold text-accent mb-8 text-center">Apply Now</h1>

          <form onSubmit={handleSubmit} className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <div className="space-y-6">
              {/* Parent Information */}
              <div>
                <h2 className="text-2xl font-bold text-accent-light mb-4">Parent Information</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaUser className="inline-block mr-2" />
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={formData.parentName}
                      onChange={(e) => setFormData({...formData, parentName: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaEnvelope className="inline-block mr-2" />
                      Email
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                      required
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-accent-light mb-2">
                      <FaPhone className="inline-block mr-2" />
                      Phone
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Child Information */}
              <div>
                <h2 className="text-2xl font-bold text-accent-light mb-4">Child Information</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaChild className="inline-block mr-2" />
                      Child's Name
                    </label>
                    <input
                      type="text"
                      value={formData.childName}
                      onChange={(e) => setFormData({...formData, childName: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaChild className="inline-block mr-2" />
                      Child's Age
                    </label>
                    <input
                      type="number"
                      value={formData.childAge}
                      onChange={(e) => setFormData({...formData, childAge: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                      min="0"
                      max="6"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Program Selection */}
              <div>
                <h2 className="text-2xl font-bold text-accent-light mb-4">Program Selection</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaFileAlt className="inline-block mr-2" />
                      Program Type
                    </label>
                    <select
                      value={formData.program}
                      onChange={(e) => setFormData({...formData, program: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white focus:border-accent outline-none"
                      required
                    >
                      <option value="full-time">Full-Time Care (€800/month)</option>
                      <option value="part-time">Part-Time Care (€400/month)</option>
                      <option value="drop-in">Drop-In Care (€10/hour)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-accent-light mb-2">
                      <FaCalendarAlt className="inline-block mr-2" />
                      Preferred Start Date
                    </label>
                    <input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                      className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white focus:border-accent outline-none [color-scheme:dark]"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <label className="block text-accent-light mb-2">
                  Additional Information
                </label>
                <textarea
                  value={formData.additionalInfo}
                  onChange={(e) => setFormData({...formData, additionalInfo: e.target.value})}
                  className="w-full bg-white/10 border border-accent/20 rounded-xl py-3 px-4 text-white placeholder-white/50 focus:border-accent outline-none"
                  rows="4"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-accent to-accent-light text-primary-dark font-semibold py-4 px-8 rounded-xl text-lg hover:opacity-90 transition-opacity"
              >
                Continue to Payment
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ApplyNow;