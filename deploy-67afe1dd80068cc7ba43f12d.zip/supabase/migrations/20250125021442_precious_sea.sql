/*
  # Fix eco metrics table and policies
  
  1. Changes
    - Drop existing trigger before recreating
    - Ensure safe creation of policies
    - Add initial data only if table is empty
  
  2. Security
    - Maintain RLS policies for authenticated users
    - Restrict insert/update to admin users
*/

-- Drop existing trigger first
DROP TRIGGER IF EXISTS update_eco_metrics_updated_at ON eco_metrics;
DROP FUNCTION IF EXISTS update_eco_metrics_updated_at();

-- Create or replace the trigger function
CREATE OR REPLACE FUNCTION update_eco_metrics_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create the trigger
CREATE TRIGGER update_eco_metrics_updated_at
  BEFORE UPDATE ON eco_metrics
  FOR EACH ROW
  EXECUTE FUNCTION update_eco_metrics_updated_at();

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view eco metrics" ON eco_metrics;
DROP POLICY IF EXISTS "Only admins can insert eco metrics" ON eco_metrics;
DROP POLICY IF EXISTS "Only admins can update eco metrics" ON eco_metrics;

-- Recreate policies
CREATE POLICY "Anyone can view eco metrics"
  ON eco_metrics
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can insert eco metrics"
  ON eco_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

CREATE POLICY "Only admins can update eco metrics"
  ON eco_metrics
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Insert initial data if table is empty
INSERT INTO eco_metrics (
  waste_reduced,
  trees_planted,
  water_saved,
  energy_saved
)
SELECT 
  100.5,  -- Initial waste reduced in kg
  5,      -- Initial trees planted
  1000.0, -- Initial water saved in L
  500.0   -- Initial energy saved in kWh
WHERE NOT EXISTS (SELECT 1 FROM eco_metrics);