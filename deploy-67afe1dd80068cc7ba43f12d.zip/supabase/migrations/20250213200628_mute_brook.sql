-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE visit_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE milestone_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create policies for activities
CREATE POLICY "Parents can view their children's activities"
  ON activities FOR SELECT
  TO authenticated
  USING (auth.uid() = parent_id);

CREATE POLICY "Parents can manage their children's activities"
  ON activities FOR ALL
  TO authenticated
  USING (auth.uid() = parent_id);

-- Create policies for milestones
CREATE POLICY "Anyone can view milestones"
  ON milestones FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for visit requests
CREATE POLICY "Staff can view visit requests"
  ON visit_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- Create policies for milestone resources
CREATE POLICY "Anyone can view milestone resources"
  ON milestone_resources FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for messages
CREATE POLICY "Users can view their own messages"
  ON messages FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);