import { describe, it, expect, beforeEach, vi } from 'vitest';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithProviders } from '../../../test/utils';
import Messages from '../Messages';
import { supabase } from '../../../lib/supabaseClient';

describe('Messages Component', () => {
  const mockSession = {
    user: { id: 'test-user-id' }
  };

  const mockMessages = [
    {
      id: '1',
      content: 'Hello, how are you?',
      sender_id: 'test-user-id',
      created_at: '2024-02-13T10:00:00Z'
    }
  ];

  beforeEach(() => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      or: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: mockMessages, error: null })
    }));
  });

  it('renders messages component', async () => {
    renderWithProviders(<Messages session={mockSession} />);
    
    await waitFor(() => {
      expect(screen.getByText('Hello, how are you?')).toBeInTheDocument();
    });
  });

  it('allows sending new messages', async () => {
    const user = userEvent.setup();
    const insertMock = vi.fn().mockResolvedValue({ data: [{ id: '2' }], error: null });
    
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      or: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: mockMessages, error: null }),
      insert: insertMock
    }));

    renderWithProviders(<Messages session={mockSession} />);

    await user.type(screen.getByPlaceholderText(/type your message/i), 'New message');
    await user.click(screen.getByRole('button', { name: /send/i }));

    await waitFor(() => {
      expect(insertMock).toHaveBeenCalledWith([
        expect.objectContaining({
          content: 'New message',
          sender_id: 'test-user-id'
        })
      ]);
    });
  });

  it('displays empty state when no messages', async () => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      or: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: [], error: null })
    }));

    renderWithProviders(<Messages session={mockSession} />);
    
    await waitFor(() => {
      expect(screen.getByText(/no messages yet/i)).toBeInTheDocument();
    });
  });
});