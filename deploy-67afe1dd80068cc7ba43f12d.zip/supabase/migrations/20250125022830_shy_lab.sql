/*
  # Drop Chat Tables
  
  1. Cleanup:
    - Drop chat_messages table if it exists
    - Drop chats table if it exists
    - Drop related triggers if they exist
  
  Note: Using IF EXISTS to safely handle non-existent objects
*/

-- Drop chat-related tables if they exist
DROP TABLE IF EXISTS chat_messages CASCADE;
DROP TABLE IF EXISTS chats CASCADE;

-- Drop chat-related triggers if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_chats_updated_at'
  ) THEN
    DROP TRIGGER update_chats_updated_at ON chats;
  END IF;
END $$;