/*
  # Remove chat functionality
  
  This migration removes the chat tables and related functionality.
  
  1. Drop Tables
    - Removes chat_messages table
    - Removes chats table
  2. Cleanup
    - Removes associated policies
*/

-- Drop chat_messages table and its policies
DROP TABLE IF EXISTS chat_messages;

-- Drop chats table and its policies
DROP TABLE IF EXISTS chats;