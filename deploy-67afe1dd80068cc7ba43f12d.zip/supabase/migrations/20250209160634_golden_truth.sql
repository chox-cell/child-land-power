/*
  # Fix Profiles RLS Policies

  1. Changes
    - Drop existing RLS policies
    - Create new policies with proper security
    - Allow profile creation during registration
  
  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Allow profile creation for new users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable insert for authentication" ON profiles;
DROP POLICY IF EXISTS "Enable read access for users" ON profiles;
DROP POLICY IF EXISTS "Enable update for users" ON profiles;

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create policy to allow profile creation during registration
CREATE POLICY "Allow profile creation during registration"
  ON profiles
  FOR INSERT
  WITH CHECK (true);

-- Create policy to allow users to view their own profile
CREATE POLICY "Allow users to view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Create policy to allow users to update their own profile
CREATE POLICY "Allow users to update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Add helpful comment
COMMENT ON TABLE profiles IS 'User profile information with row-level security';