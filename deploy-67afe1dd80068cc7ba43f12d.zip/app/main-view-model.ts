import { Observable } from '@nativescript/core';

export class HelloWorldModel extends Observable {
  constructor() {
    super();
  }

  onLearnMore() {
    console.log('Learn More About Programs tapped');
    // Navigation logic will be added here
  }

  onEnroll() {
    console.log('Enroll Now tapped');
    // Navigation logic will be added here
  }

  onContact() {
    console.log('Contact Us tapped');
    // Navigation logic will be added here
  }
}