-- Create profiles table first
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  phone text,
  address text,
  role text CHECK (role IN ('parent', 'staff', 'admin')) DEFAULT 'parent',
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create new restrictive policy
CREATE POLICY "User can see their own profile only"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);