/*
  # Create Visit Requests Table

  1. New Tables
    - visit_requests
      - id (uuid, primary key)
      - name (text)
      - email (text)
      - phone (text)
      - preferred_date (date)
      - preferred_time (time)
      - number_of_children (integer)
      - children_ages (text)
      - message (text)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS
    - Allow public creation of visit requests
    - Allow staff to view and manage requests
*/

-- Create visit_requests table
CREATE TABLE visit_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  preferred_date date NOT NULL,
  preferred_time time NOT NULL,
  number_of_children integer NOT NULL CHECK (number_of_children > 0),
  children_ages text NOT NULL,
  message text,
  status text NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE visit_requests ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable public visit request creation"
  ON visit_requests
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow staff to view visit requests"
  ON visit_requests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = auth.uid()
      AND (
        raw_user_meta_data->>'is_staff' = 'true'
        OR raw_user_meta_data->>'is_admin' = 'true'
      )
    )
  );

CREATE POLICY "Allow staff to update visit requests"
  ON visit_requests
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = auth.uid()
      AND (
        raw_user_meta_data->>'is_staff' = 'true'
        OR raw_user_meta_data->>'is_admin' = 'true'
      )
    )
  );

-- Create indexes
CREATE INDEX idx_visit_requests_status ON visit_requests(status);
CREATE INDEX idx_visit_requests_preferred_date ON visit_requests(preferred_date);
CREATE INDEX idx_visit_requests_email ON visit_requests(email);

-- Add updated_at trigger
CREATE TRIGGER update_visit_requests_updated_at
  BEFORE UPDATE ON visit_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add helpful comment
COMMENT ON TABLE visit_requests IS 'Visit scheduling requests from potential parents';