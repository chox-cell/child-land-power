/*
  # Make eco metrics private
  
  1. Changes:
    - Drop existing public policies
    - Create new restrictive policies for eco metrics
    - Only allow staff and admins to view metrics
  
  2. Security:
    - Remove public access
    - Add staff role check
    - Maintain admin privileges
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view eco metrics" ON eco_metrics;
DROP POLICY IF EXISTS "Only admins can insert eco metrics" ON eco_metrics;
DROP POLICY IF EXISTS "Only admins can update eco metrics" ON eco_metrics;

-- Create new restrictive policies
CREATE POLICY "Only staff and admins can view eco metrics"
  ON eco_metrics
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND (
        raw_user_meta_data->>'is_admin' = 'true'
        OR raw_user_meta_data->>'is_staff' = 'true'
      )
    )
  );

CREATE POLICY "Only admins can insert eco metrics"
  ON eco_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

CREATE POLICY "Only admins can update eco metrics"
  ON eco_metrics
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

CREATE POLICY "Only admins can delete eco metrics"
  ON eco_metrics
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );