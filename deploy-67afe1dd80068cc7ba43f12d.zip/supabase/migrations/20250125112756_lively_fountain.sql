/*
  # Create Charts and Analytics Tables
  
  This migration:
  1. Creates tables for charts and chart data
  2. Sets up proper indexing
  3. Adds data validation constraints
  4. Inserts initial sample data
*/

-- Create charts table if it doesn't exist
CREATE TABLE IF NOT EXISTS charts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  type text NOT NULL,
  description text,
  config jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create chart_data table if it doesn't exist
CREATE TABLE IF NOT EXISTS chart_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chart_id uuid REFERENCES charts NOT NULL,
  label text NOT NULL,
  value numeric NOT NULL,
  category text,
  date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE charts ENABLE ROW LEVEL SECURITY;
ALTER TABLE chart_data ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Anyone can view active charts" ON charts;
    DROP POLICY IF EXISTS "Only admins can manage charts" ON charts;
    DROP POLICY IF EXISTS "Anyone can view chart data" ON chart_data;
    DROP POLICY IF EXISTS "Only admins can manage chart data" ON chart_data;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create policies for charts
CREATE POLICY "Anyone can view active charts"
  ON charts
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only admins can manage charts"
  ON charts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create policies for chart_data
CREATE POLICY "Anyone can view chart data"
  ON chart_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM charts
      WHERE id = chart_id
      AND is_active = true
    )
  );

CREATE POLICY "Only admins can manage chart data"
  ON chart_data
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create or replace updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create triggers
DROP TRIGGER IF EXISTS update_charts_updated_at ON charts;
DROP TRIGGER IF EXISTS update_chart_data_updated_at ON chart_data;

CREATE TRIGGER update_charts_updated_at
  BEFORE UPDATE ON charts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chart_data_updated_at
  BEFORE UPDATE ON chart_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_charts_type ON charts(type);
CREATE INDEX IF NOT EXISTS idx_charts_is_active ON charts(is_active);
CREATE INDEX IF NOT EXISTS idx_chart_data_date ON chart_data(date);
CREATE INDEX IF NOT EXISTS idx_chart_data_category ON chart_data(category);
CREATE INDEX IF NOT EXISTS idx_chart_data_chart_id ON chart_data(chart_id);

-- Add check constraints
ALTER TABLE chart_data
ADD CONSTRAINT chk_chart_data_value
CHECK (value >= 0);

-- Add partial indexes
CREATE INDEX IF NOT EXISTS idx_charts_active
ON charts(id) WHERE is_active = true;

-- Insert sample data
INSERT INTO charts (title, type, description, config)
VALUES 
  (
    'Eco Impact Overview',
    'line',
    'Monthly tracking of our environmental impact metrics',
    '{
      "xAxis": "date",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  ),
  (
    'Resource Conservation',
    'bar',
    'Comparison of resource conservation metrics',
    '{
      "xAxis": "category",
      "yAxis": "value",
      "legend": true,
      "tooltip": true
    }'
  );

-- Insert sample chart data
WITH chart_ids AS (
  SELECT id, type FROM charts
)
INSERT INTO chart_data (chart_id, label, value, category, date)
SELECT 
  c.id,
  CASE 
    WHEN c.type = 'line' THEN 'Waste Reduced'
    ELSE 'Water Saved'
  END,
  CASE 
    WHEN c.type = 'line' THEN random() * 100
    ELSE random() * 1000
  END,
  CASE 
    WHEN c.type = 'line' THEN NULL
    ELSE 'Conservation'
  END,
  now() - (i || ' days')::interval
FROM chart_ids c
CROSS JOIN generate_series(0, 30) i;