import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaDownload, FaPlay, FaLanguage, FaVolumeUp } from 'react-icons/fa';

function LanguageResources() {
  const [wordOfDay, setWordOfDay] = useState({
    english: '',
    french: '',
    category: '',
    isEnglish: true
  });

  // Sample words for demonstration
  const words = [
    { english: 'Tree', french: 'Arbre', category: 'Nature' },
    { english: 'Sun', french: 'Soleil', category: 'Nature' },
    { english: 'Book', french: 'Livre', category: 'School' },
    { english: 'Friend', french: 'Ami', category: 'People' },
    { english: 'Apple', french: 'Pomme', category: 'Food' }
  ];

  useEffect(() => {
    // Change word every 24 hours
    const randomWord = words[Math.floor(Math.random() * words.length)];
    setWordOfDay(prev => ({ ...randomWord, isEnglish: prev.isEnglish }));

    // Toggle language every 5 seconds
    const interval = setInterval(() => {
      setWordOfDay(prev => ({ ...prev, isEnglish: !prev.isEnglish }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const resources = [
    {
      title: 'Animal Flashcards',
      description: 'Learn animal names in French and English',
      type: 'PDF',
      url: '/resources/animal-flashcards.pdf',
      icon: '🦁'
    },
    {
      title: 'Colors & Shapes',
      description: 'Interactive guide to colors and shapes',
      type: 'PDF',
      url: '/resources/colors-shapes.pdf',
      icon: '🎨'
    },
    {
      title: 'French Lullabies',
      description: 'Traditional French children\'s songs',
      type: 'Audio',
      url: '/resources/french-lullabies.mp3',
      icon: '🎵'
    },
    {
      title: 'Storytime Collection',
      description: 'Bilingual bedtime stories',
      type: 'Video',
      url: '/resources/storytime.mp4',
      icon: '📚'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white relative overflow-hidden">
      {/* Floating Spheres */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-sphere rounded-full blur-xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-sphere rounded-full blur-xl animate-pulse delay-1000"></div>
      
      <main className="relative z-10 container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Language Resources
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore our bilingual learning materials and activities
          </p>
        </section>

        {/* Word of the Day Widget */}
        <section className="mb-16">
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20 max-w-2xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-accent flex items-center gap-2">
                <FaLanguage />
                Word of the Day
              </h2>
              <span className="text-accent-light">{wordOfDay.category}</span>
            </div>
            <motion.div
              key={wordOfDay.isEnglish ? 'english' : 'french'}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center py-6"
            >
              <p className="text-4xl font-bold mb-2">
                {wordOfDay.isEnglish ? wordOfDay.english : wordOfDay.french}
              </p>
              <p className="text-gray-400">
                {wordOfDay.isEnglish ? 'English' : 'Français'}
              </p>
            </motion.div>
            <button className="flex items-center gap-2 mx-auto text-accent hover:text-accent-light transition-colors">
              <FaVolumeUp />
              Listen
            </button>
          </div>
        </section>

        {/* Downloadable Resources */}
        <section>
          <h2 className="text-3xl font-bold text-accent text-center mb-8">Learning Materials</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {resources.map((resource, index) => (
              <motion.div
                key={resource.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20 hover:border-accent/40 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-4xl mb-4 block">{resource.icon}</span>
                    <h3 className="text-xl font-bold text-accent-light mb-2">{resource.title}</h3>
                    <p className="text-gray-300 mb-4">{resource.description}</p>
                    <span className="text-sm text-accent">{resource.type}</span>
                  </div>
                  <button className="bg-accent text-primary-dark p-3 rounded-full hover:bg-accent-light transition-colors">
                    {resource.type === 'Video' ? <FaPlay /> : <FaDownload />}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default LanguageResources;