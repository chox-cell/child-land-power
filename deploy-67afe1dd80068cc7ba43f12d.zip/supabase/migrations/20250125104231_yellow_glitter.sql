/*
  # Create secure eco metrics view
  
  1. Changes
    - Create view for eco metrics data
    - Enable security_invoker to respect RLS policies
    - Include aggregated metrics and time-based calculations
  
  2. Security
    - View inherits RLS policies from base table
    - Only authenticated users can access based on existing policies
*/

-- Create view with security_invoker enabled
CREATE OR REPLACE VIEW eco_metrics_summary
WITH (security_invoker = true)
AS
SELECT 
  date_trunc('month', date) as month,
  SUM(waste_reduced) as total_waste_reduced,
  SUM(trees_planted) as total_trees_planted,
  SUM(water_saved) as total_water_saved,
  SUM(energy_saved) as total_energy_saved,
  ROUND(AVG(waste_reduced), 2) as avg_waste_reduced,
  ROUND(AVG(water_saved), 2) as avg_water_saved,
  ROUND(AVG(energy_saved), 2) as avg_energy_saved
FROM eco_metrics
GROUP BY date_trunc('month', date)
ORDER BY month DESC;

-- Grant access to authenticated users
GRANT SELECT ON eco_metrics_summary TO authenticated;