/*
  # Create eco metrics tracking system

  1. New Tables
    - `eco_metrics`
      - `id` (uuid, primary key)
      - `date` (timestamptz)
      - `waste_reduced` (numeric)
      - `trees_planted` (integer)
      - `water_saved` (numeric)
      - `energy_saved` (numeric)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `eco_metrics` table
    - Add policies for authenticated users to read metrics
    - Add policies for admin users to insert and update metrics
*/

-- Create eco_metrics table
CREATE TABLE IF NOT EXISTS eco_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date timestamptz NOT NULL DEFAULT now(),
  waste_reduced numeric NOT NULL DEFAULT 0,
  trees_planted integer NOT NULL DEFAULT 0,
  water_saved numeric NOT NULL DEFAULT 0,
  energy_saved numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE eco_metrics ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view eco metrics"
  ON eco_metrics
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can insert eco metrics"
  ON eco_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

CREATE POLICY "Only admins can update eco metrics"
  ON eco_metrics
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_eco_metrics_updated_at
  BEFORE UPDATE ON eco_metrics
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert initial data
INSERT INTO eco_metrics (
  waste_reduced,
  trees_planted,
  water_saved,
  energy_saved
) VALUES (
  100.5,  -- Initial waste reduced in kg
  5,      -- Initial trees planted
  1000.0, -- Initial water saved in L
  500.0   -- Initial energy saved in kWh
);