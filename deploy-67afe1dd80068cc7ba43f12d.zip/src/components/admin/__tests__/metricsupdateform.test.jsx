import { describe, it, expect, beforeEach, vi } from 'vitest';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithProviders } from '../../../test/utils';
import MetricsUpdateForm from '../MetricsUpdateForm';
import { supabase } from '../../../lib/supabaseClient';
import toast from 'react-hot-toast';

vi.mock('react-hot-toast', () => ({
  default: {
    success: vi.fn(),
    error: vi.fn()
  }
}));

describe('MetricsUpdateForm Component', () => {
  const mockCurrentMetrics = {
    waste_reduced: 100,
    trees_planted: 5,
    water_saved: 1000,
    energy_saved: 500
  };

  const mockOnClose = vi.fn();
  const mockOnUpdate = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders metrics update form', () => {
    renderWithProviders(
      <MetricsUpdateForm
        currentMetrics={mockCurrentMetrics}
        onClose={mockOnClose}
        onUpdate={mockOnUpdate}
      />
    );
    
    expect(screen.getByText('Update Eco Metrics')).toBeInTheDocument();
    expect(screen.getByLabelText(/waste reduced/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/trees planted/i)).toBeInTheDocument();
  });

  it('handles form submission', async () => {
    const user = userEvent.setup();
    
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      insert: vi.fn().mockResolvedValue({ data: [{ id: '1' }], error: null })
    }));

    renderWithProviders(
      <MetricsUpdateForm
        currentMetrics={mockCurrentMetrics}
        onClose={mockOnClose}
        onUpdate={mockOnUpdate}
      />
    );

    await user.clear(screen.getByLabelText(/waste reduced/i));
    await user.type(screen.getByLabelText(/waste reduced/i), '150');
    await user.click(screen.getByRole('button', { name: /save changes/i }));

    await waitFor(() => {
      expect(toast.success).toHaveBeenCalledWith('Metrics updated successfully');
      expect(mockOnUpdate).toHaveBeenCalled();
      expect(mockOnClose).toHaveBeenCalled();
    });
  });

  it('handles form submission error', async () => {
    const user = userEvent.setup();
    
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      insert: vi.fn().mockRejectedValue(new Error('Failed to update metrics'))
    }));

    renderWithProviders(
      <MetricsUpdateForm
        currentMetrics={mockCurrentMetrics}
        onClose={mockOnClose}
        onUpdate={mockOnUpdate}
      />
    );

    await user.clear(screen.getByLabelText(/waste reduced/i));
    await user.type(screen.getByLabelText(/waste reduced/i), '150');
    await user.click(screen.getByRole('button', { name: /save changes/i }));

    await waitFor(() => {
      expect(toast.error).toHaveBeenCalledWith('Error updating metrics');
    });
  });

  it('closes form on cancel', async () => {
    const user = userEvent.setup();
    
    renderWithProviders(
      <MetricsUpdateForm
        currentMetrics={mockCurrentMetrics}
        onClose={mockOnClose}
        onUpdate={mockOnUpdate}
      />
    );

    await user.click(screen.getByRole('button', { name: /cancel/i }));
    expect(mockOnClose).toHaveBeenCalled();
  });
});