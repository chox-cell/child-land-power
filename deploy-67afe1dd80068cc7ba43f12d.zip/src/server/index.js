require("./instrument.js");
const express = require("express");
const Sentry = require("@sentry/node");
const Redis = require("ioredis");

const app = express();

// Initialize Redis client
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  }
});

// The request handler must be the first middleware on the app
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());

// API Routes
app.get("/", function rootHandler(req, res) {
  res.json({ status: "ok" });
});

// Debug endpoint that triggers a test error
app.get("/debug-sentry", function mainHandler(req, res) {
  const transaction = Sentry.startTransaction({
    op: "test-error",
    name: "Debug Sentry Error",
  });

  Sentry.configureScope(scope => {
    scope.setTag("endpoint", "/debug-sentry");
    scope.setContext("request", {
      url: req.url,
      method: req.method,
      headers: req.headers
    });
  });

  try {
    throw new Error("My first Sentry error!");
  } catch (error) {
    Sentry.captureException(error, {
      tags: {
        endpoint: '/debug-sentry',
        type: 'test-error'
      },
      extra: {
        timestamp: new Date().toISOString(),
        requestPath: req.path,
        requestQuery: req.query
      }
    });
    throw error; // Re-throw to trigger error handler
  } finally {
    transaction.finish();
  }
});

// Cache middleware
const cache = (duration) => {
  return async (req, res, next) => {
    const key = `cache:${req.originalUrl || req.url}`;
    try {
      const cachedResponse = await redis.get(key);
      if (cachedResponse) {
        return res.json(JSON.parse(cachedResponse));
      }
      res.sendResponse = res.json;
      res.json = async (body) => {
        await redis.setex(key, duration, JSON.stringify(body));
        res.sendResponse(body);
      };
      next();
    } catch (error) {
      Sentry.captureException(error);
      next(error);
    }
  };
};

// Protected route example with caching
app.get("/api/protected", cache(300), async (req, res) => {
  const transaction = Sentry.startTransaction({
    op: "protected-route",
    name: "Protected Route Access",
  });

  try {
    // Simulate some work
    await new Promise(resolve => setTimeout(resolve, 100));
    
    res.json({
      message: "Protected route accessed successfully",
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    Sentry.captureException(error);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    transaction.finish();
  }
});

// The error handler must be registered before any other error middleware and after all controllers
app.use(Sentry.Handlers.errorHandler());

// Optional fallthrough error handler
app.use(function onError(err, req, res, next) {
  // The error id is attached to `res.sentry` to be returned
  // and optionally displayed to the user for support.
  res.statusCode = 500;
  res.json({
    error: "Internal server error",
    eventId: res.sentry,
    message: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});