import React from 'react';
import { FaHandsHelping, FaHeart, FaLeaf, FaUsers, FaDollarSign, FaCalendarAlt } from 'react-icons/fa';

function GetInvolved() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Get Involved
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join our mission to create a sustainable future through eco-conscious education
          </p>
        </section>

        {/* Ways to Get Involved */}
        <section className="grid md:grid-cols-2 gap-8 mb-16">
          {/* Volunteer */}
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <FaHandsHelping className="text-4xl text-accent mb-4" />
            <h2 className="text-2xl font-bold text-accent-light mb-4">Volunteer With Us</h2>
            <p className="text-gray-300 mb-6">
              Share your time and skills to support our eco-conscious educational programs. 
              From gardening to teaching, there are many ways to contribute.
            </p>
            <ul className="text-gray-300 space-y-2 mb-6">
              <li className="flex items-center gap-2">
                <FaLeaf className="text-accent" />
                Garden maintenance
              </li>
              <li className="flex items-center gap-2">
                <FaUsers className="text-accent" />
                Event support
              </li>
              <li className="flex items-center gap-2">
                <FaHeart className="text-accent" />
                Teaching assistance
              </li>
            </ul>
            <button
              onClick={() => window.location.href = '/volunteer'}
              className="w-full bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
            >
              <FaHandsHelping />
              Volunteer Now
            </button>
          </div>

          {/* Donate */}
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <FaDollarSign className="text-4xl text-accent mb-4" />
            <h2 className="text-2xl font-bold text-accent-light mb-4">Make a Donation</h2>
            <p className="text-gray-300 mb-6">
              Support our mission through financial contributions. Your donation helps us 
              provide quality eco-conscious education and maintain our facilities.
            </p>
            <ul className="text-gray-300 space-y-2 mb-6">
              <li className="flex items-center gap-2">
                <FaLeaf className="text-accent" />
                Eco-friendly materials
              </li>
              <li className="flex items-center gap-2">
                <FaUsers className="text-accent" />
                Scholarship programs
              </li>
              <li className="flex items-center gap-2">
                <FaHeart className="text-accent" />
                Facility improvements
              </li>
            </ul>
            <button
              onClick={() => window.location.href = '/donate'}
              className="w-full bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
            >
              <FaDollarSign />
              Donate Now
            </button>
          </div>
        </section>

        {/* Current Initiatives */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-accent text-center mb-8">Current Initiatives</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
              <h3 className="text-xl font-bold text-accent-light mb-2">Garden Project</h3>
              <p className="text-gray-300 mb-4">
                Help us maintain and expand our organic garden where children learn about sustainable agriculture.
              </p>
              <button className="w-full bg-accent/20 text-accent hover:bg-accent hover:text-primary-dark px-4 py-2 rounded-lg transition-colors">
                Learn More
              </button>
            </div>

            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
              <h3 className="text-xl font-bold text-accent-light mb-2">Eco Library</h3>
              <p className="text-gray-300 mb-4">
                Support our initiative to build a library of environmental education resources.
              </p>
              <button className="w-full bg-accent/20 text-accent hover:bg-accent hover:text-primary-dark px-4 py-2 rounded-lg transition-colors">
                Learn More
              </button>
            </div>

            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
              <h3 className="text-xl font-bold text-accent-light mb-2">Green Energy</h3>
              <p className="text-gray-300 mb-4">
                Help us transition to 100% renewable energy sources for our facility.
              </p>
              <button className="w-full bg-accent/20 text-accent hover:bg-accent hover:text-primary-dark px-4 py-2 rounded-lg transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-accent text-center mb-8">Upcoming Events</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
              <div className="flex items-start gap-4">
                <div className="bg-accent/20 p-3 rounded-lg">
                  <FaCalendarAlt className="text-2xl text-accent" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-accent-light">Community Garden Day</h3>
                  <p className="text-gray-400">Saturday, March 15th, 2024</p>
                  <p className="text-gray-300 mt-2">
                    Join us for a day of gardening, learning, and community building.
                  </p>
                  <button className="mt-4 text-accent hover:text-accent-light transition-colors">
                    Register →
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-primary/30 backdrop-blur-lg p-6 rounded-xl border border-accent/20">
              <div className="flex items-start gap-4">
                <div className="bg-accent/20 p-3 rounded-lg">
                  <FaCalendarAlt className="text-2xl text-accent" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-accent-light">Eco-Art Workshop</h3>
                  <p className="text-gray-400">Sunday, March 23rd, 2024</p>
                  <p className="text-gray-300 mt-2">
                    Create beautiful art pieces using recycled materials.
                  </p>
                  <button className="mt-4 text-accent hover:text-accent-light transition-colors">
                    Register →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact CTA */}
        <section className="text-center">
          <h2 className="text-3xl font-bold text-accent mb-6">Ready to Make a Difference?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Contact us to learn more about how you can get involved and support our mission.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <button className="bg-accent text-primary-dark px-8 py-4 rounded-xl hover:bg-accent-light transition-colors">
              Contact Us
            </button>
            <button className="border-2 border-accent text-accent px-8 py-4 rounded-xl hover:bg-accent hover:text-primary-dark transition-all">
              View All Opportunities
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

export default GetInvolved;