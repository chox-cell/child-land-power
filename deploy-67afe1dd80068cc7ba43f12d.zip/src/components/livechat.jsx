import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaComments, FaTimes, FaPaperPlane, FaRobot, FaUser } from 'react-icons/fa';
import { supabase } from '../lib/supabaseClient';
import toast from 'react-hot-toast';

function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatId, setChatId] = useState(null);
  const messagesEndRef = useRef(null);
  const [isBusinessHours, setIsBusinessHours] = useState(false);

  useEffect(() => {
    checkBusinessHours();
    const interval = setInterval(checkBusinessHours, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (chatId) {
      const subscription = supabase
        .channel(`chat:${chatId}`)
        .on('postgres_changes', { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'chat_messages',
          filter: `chat_id=eq.${chatId}`
        }, payload => {
          setMessages(current => [...current, payload.new]);
        })
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [chatId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const checkBusinessHours = () => {
    const now = new Date();
    const hours = now.getHours();
    const day = now.getDay();
    
    // Business hours: Monday-Friday, 9 AM - 5 PM
    setIsBusinessHours(day >= 1 && day <= 5 && hours >= 9 && hours < 17);
  };

  const initializeChat = async () => {
    try {
      const { data: chat, error } = await supabase
        .from('chats')
        .insert([{ status: 'active' }])
        .select()
        .single();

      if (error) throw error;
      
      setChatId(chat.id);
      
      // Add initial bot message
      const welcomeMessage = {
        chat_id: chat.id,
        sender_type: 'bot',
        content: 'Hello! Welcome to Childland. How can I help you today?',
        created_at: new Date().toISOString()
      };
      
      const { error: msgError } = await supabase
        .from('chat_messages')
        .insert([welcomeMessage]);

      if (msgError) throw msgError;
      
      setMessages([welcomeMessage]);
    } catch (error) {
      console.error('Error initializing chat:', error);
      toast.error('Unable to start chat. Please try again.');
    }
  };

  const handleOpen = () => {
    setIsOpen(true);
    if (!chatId) {
      initializeChat();
    }
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const userMessage = {
        chat_id: chatId,
        sender_type: 'user',
        content: newMessage.trim(),
        created_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('chat_messages')
        .insert([userMessage]);

      if (error) throw error;

      setNewMessage('');
      setIsTyping(true);

      // Simulate bot response
      setTimeout(async () => {
        const botMessage = {
          chat_id: chatId,
          sender_type: 'bot',
          content: getBotResponse(newMessage.trim()),
          created_at: new Date().toISOString()
        };

        const { error: botError } = await supabase
          .from('chat_messages')
          .insert([botMessage]);

        if (botError) throw botError;

        setIsTyping(false);
      }, 1500);

    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    }
  };

  const getBotResponse = (message) => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('program') || lowerMessage.includes('curriculum')) {
      return "Our program combines eco-conscious education with bilingual learning (French-English). Would you like to know more about our specific age groups or activities?";
    }
    
    if (lowerMessage.includes('cost') || lowerMessage.includes('fee') || lowerMessage.includes('price')) {
      return "Our fees start from €400/month for part-time care and €800/month for full-time care. Would you like to schedule a call with our admissions team to discuss our programs in detail?";
    }
    
    if (lowerMessage.includes('enroll') || lowerMessage.includes('register') || lowerMessage.includes('sign up')) {
      return "Great! To start the enrollment process, you can visit our Admissions page or I can help you schedule a tour of our facility. What would you prefer?";
    }
    
    if (isBusinessHours) {
      return "I'll connect you with one of our staff members who can better assist you. Please wait a moment...";
    }
    
    return "I can help with basic questions, or you can leave a message for our team to contact you during business hours (Monday-Friday, 9 AM - 5 PM).";
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={handleOpen}
        className="fixed bottom-6 right-6 bg-accent text-primary-dark p-4 rounded-full shadow-lg hover:bg-accent-light transition-colors z-50"
        aria-label="Open chat"
      >
        <FaComments size={24} />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-24 right-6 w-96 bg-primary-dark/95 backdrop-blur-lg rounded-2xl shadow-xl border border-accent/20 z-50"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-accent/20">
              <h2 className="text-lg font-bold text-accent flex items-center gap-2">
                <FaComments />
                Childland Support
              </h2>
              <button
                onClick={handleClose}
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Close chat"
              >
                <FaTimes />
              </button>
            </div>

            {/* Messages */}
            <div className="h-96 overflow-y-auto p-4 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${
                    message.sender_type === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-xl flex items-start gap-2 ${
                      message.sender_type === 'user'
                        ? 'bg-accent text-primary-dark'
                        : 'bg-primary/50 text-white'
                    }`}
                  >
                    {message.sender_type === 'bot' ? (
                      <FaRobot className="mt-1" />
                    ) : (
                      <FaUser className="mt-1" />
                    )}
                    <div>
                      <p>{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-primary/50 text-white p-3 rounded-xl">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce delay-100" />
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-accent/20">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 bg-primary/50 border border-accent/20 rounded-xl p-3 text-white focus:border-accent outline-none"
                />
                <button
                  type="submit"
                  className="bg-accent text-primary-dark p-3 rounded-xl hover:bg-accent-light transition-colors"
                  aria-label="Send message"
                >
                  <FaPaperPlane />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default LiveChat;