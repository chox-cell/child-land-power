-- Drop existing policies first to avoid conflicts
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Allow profile creation during registration" ON profiles;
    DROP POLICY IF EXISTS "Allow users to view own profile" ON profiles;
    DROP POLICY IF EXISTS "Allow users to update own profile" ON profiles;
    DROP POLICY IF EXISTS "Enable profile creation" ON profiles;
    DROP POLICY IF EXISTS "Enable profile viewing" ON profiles;
    DROP POLICY IF EXISTS "Enable profile updates" ON profiles;
    DROP POLICY IF EXISTS "Enable public profile creation" ON profiles;
    DROP POLICY IF EXISTS "Enable own profile viewing" ON profiles;
    DROP POLICY IF EXISTS "Enable own profile updates" ON profiles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Recreate profiles table with correct constraints
DROP TABLE IF EXISTS profiles CASCADE;
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  address text,
  role text NOT NULL CHECK (role IN ('parent', 'staff', 'admin')) DEFAULT 'parent',
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create new policies with unique names
CREATE POLICY "profiles_insert_policy"
  ON profiles
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "profiles_select_policy"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "profiles_update_policy"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Add helpful comment
COMMENT ON TABLE profiles IS 'User profile information with row-level security';