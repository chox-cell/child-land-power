import React from 'react';
import { FaMapMarkerAlt, FaPhone, FaEnvelope, FaCalendarAlt } from 'react-icons/fa';

function FindUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-dark via-primary to-black text-white">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-accent-light to-accent">
            Find Us
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Visit our eco-conscious childcare center in Orléans
          </p>
        </section>

        {/* Map and Contact Info */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {/* Map */}
          <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
            <h2 className="text-2xl font-bold text-accent mb-6">Our Location</h2>
            <div className="w-full h-[400px] rounded-xl overflow-hidden mb-6">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d42386.79255087553!2d1.8853921771484375!3d47.902488799999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e4e4d77fb7f0bd%3A0xe2088691e5f5b90b!2sOrl%C3%A9ans%2C%20France!5e0!3m2!1sen!2sus!4v1709669047974!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
            <div className="flex justify-center">
              <a
                href="https://maps.google.com/?q=Orleans,France"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors"
              >
                Get Directions
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
              <h2 className="text-2xl font-bold text-accent mb-6">Contact Information</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <FaMapMarkerAlt className="text-2xl text-accent mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-accent-light">Address</h3>
                    <p className="text-gray-300">
                      123 Rue de la République<br />
                      45000 Orléans, France
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <FaPhone className="text-2xl text-accent mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-accent-light">Phone</h3>
                    <p className="text-gray-300">+33 2 38 XX XX XX</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <FaEnvelope className="text-2xl text-accent mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-accent-light">Email</h3>
                    <p className="text-gray-300">contact@childland.fr</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
              <h2 className="text-2xl font-bold text-accent mb-6">Opening Hours</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300">Monday - Friday</span>
                  <span className="text-accent-light">8:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Saturday</span>
                  <span className="text-accent-light">Closed</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Sunday</span>
                  <span className="text-accent-light">Closed</span>
                </div>
              </div>
            </div>

            <div className="bg-primary/30 backdrop-blur-lg p-8 rounded-2xl border border-accent/20">
              <h2 className="text-2xl font-bold text-accent mb-6">Schedule a Visit</h2>
              <p className="text-gray-300 mb-4">
                Want to see our facility in person? Schedule a tour with our staff.
              </p>
              <button
                onClick={() => window.location.href = '/schedule-visit'}
                className="w-full bg-accent text-primary-dark px-6 py-3 rounded-xl hover:bg-accent-light transition-colors flex items-center justify-center gap-2"
              >
                <FaCalendarAlt />
                Schedule a Tour
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FindUs;