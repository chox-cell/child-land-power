import * as Sentry from '@sentry/node';
import * as SentryBrowser from '@sentry/react';
import { ProfilingIntegration } from '@sentry/profiling-node';
import { nodeProfilingIntegration } from "@sentry/profiling-node";
import newrelic from '@newrelic/browser-agent';

// Initialize Sentry for Node.js
Sentry.init({
  dsn: process.env.VITE_SENTRY_NODE_DSN,
  integrations: [
    nodeProfilingIntegration(),
  ],
  tracesSampleRate: 1.0,
  profilesSampleRate: 1.0,
  environment: import.meta.env.MODE,
  release: import.meta.env.VITE_APP_VERSION // Add release version
});

// Initialize Sentry for Browser
SentryBrowser.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  integrations: [
    new SentryBrowser.BrowserTracing(),
    new SentryBrowser.Replay()
  ],
  tracesSampleRate: 1.0,
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
  environment: import.meta.env.MODE,
  release: import.meta.env.VITE_APP_VERSION, // Add release version
  beforeSend(event) {
    // Clean up sensitive data
    if (event.request) {
      delete event.request.cookies;
      delete event.request.headers;
    }
    return event;
  }
});

// Initialize New Relic
newrelic.init({
  applicationID: import.meta.env.VITE_NEW_RELIC_APP_ID,
  licenseKey: import.meta.env.VITE_NEW_RELIC_LICENSE_KEY,
  distributed_tracing: {
    enabled: true
  },
  privacy: {
    cookies_enabled: true
  },
  ajax: {
    enabled: true,
    harvestTimeSeconds: 10
  }
});

// Custom performance monitoring with profiling
export const trackPerformance = (name, duration) => {
  // Start profiling
  Sentry.profiler.startProfiler();

  // Create and finish transaction
  const transaction = Sentry.startTransaction({
    name,
    op: 'performance',
  });

  // Add profiling data
  Sentry.startSpan(
    {
      name: `${name}_profiled`,
      op: 'profiling',
    },
    () => {
      // Your code to be profiled
      transaction.finish(duration);
    }
  );

  // Stop profiling
  Sentry.profiler.stopProfiler();

  // Track in New Relic
  newrelic.addToTrace({
    name,
    duration,
    type: 'custom'
  });
};

// Error tracking
export const trackError = (error, context = {}) => {
  // Track in Node.js
  Sentry.captureException(error, {
    extra: context
  });
  
  // Track in Browser
  SentryBrowser.captureException(error, {
    extra: context
  });
  
  // Track in New Relic
  newrelic.noticeError(error, {
    ...context,
    errorType: error.name,
    errorMessage: error.message
  });
};

// Business metrics
export const trackEvent = (eventName, properties = {}) => {
  // Track in Node.js with profiling
  Sentry.profiler.startProfiler();
  
  Sentry.startSpan(
    {
      name: eventName,
      op: 'business_event',
    },
    () => {
      Sentry.captureMessage(eventName, {
        level: 'info',
        extra: properties
      });
    }
  );

  Sentry.profiler.stopProfiler();

  // Track in Browser
  SentryBrowser.captureMessage(eventName, {
    level: 'info',
    extra: properties
  });

  // Track in New Relic
  newrelic.addPageAction(eventName, properties);
};

// React component performance monitoring
export const withPerformanceTracking = (WrappedComponent, componentName) => {
  return class extends React.Component {
    componentDidMount() {
      trackPerformance(`${componentName}_mount`, performance.now());
    }

    componentDidUpdate() {
      trackPerformance(`${componentName}_update`, performance.now());
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };
};

// Export Sentry instances for direct access if needed
export { Sentry as SentryNode, SentryBrowser };