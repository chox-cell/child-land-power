import { describe, it, expect, beforeEach, vi } from 'vitest';
import { screen, waitFor } from '@testing-library/react';
import { renderWithProviders } from '../../../test/utils';
import ActivityFeed from '../ActivityFeed';
import { supabase } from '../../../lib/supabaseClient';

describe('ActivityFeed Component', () => {
  const mockSession = {
    user: { id: 'test-user-id' }
  };

  const mockActivities = [
    {
      id: '1',
      title: 'Morning Circle Time',
      description: 'Participated in group singing and reading',
      created_at: '2024-02-13T10:00:00Z',
      metrics: {
        participation: 'High',
        engagement: 'Excellent'
      }
    }
  ];

  beforeEach(() => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      eq: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: mockActivities, error: null })
    }));
  });

  it('renders activity feed', async () => {
    renderWithProviders(<ActivityFeed session={mockSession} />);
    
    await waitFor(() => {
      expect(screen.getByText('Morning Circle Time')).toBeInTheDocument();
      expect(screen.getByText('Participated in group singing and reading')).toBeInTheDocument();
    });
  });

  it('displays loading state', () => {
    renderWithProviders(<ActivityFeed session={mockSession} />);
    expect(screen.getByRole('status')).toBeInTheDocument();
  });

  it('displays empty state when no activities', async () => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      eq: vi.fn().mockReturnThis(),
      order: vi.fn().mockResolvedValue({ data: [], error: null })
    }));

    renderWithProviders(<ActivityFeed session={mockSession} />);
    
    await waitFor(() => {
      expect(screen.getByText(/no activities recorded yet/i)).toBeInTheDocument();
    });
  });

  it('handles error state', async () => {
    vi.spyOn(supabase, 'from').mockImplementation((table) => ({
      select: vi.fn().mockReturnThis(),
      eq: vi.fn().mockReturnThis(),
      order: vi.fn().mockRejectedValue(new Error('Failed to load activities'))
    }));

    renderWithProviders(<ActivityFeed session={mockSession} />);
    
    await waitFor(() => {
      expect(screen.getByText(/error loading activities/i)).toBeInTheDocument();
    });
  });
});