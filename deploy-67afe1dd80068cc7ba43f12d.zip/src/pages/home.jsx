import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { FaLeaf, FaGlobe, FaClock, FaUsers, FaCalendarAlt, FaCompass } from 'react-icons/fa';

function Home() {
  const navigate = useNavigate();

  const handleScheduleVisit = () => {
    navigate('/schedule-visit');
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-5xl md:text-6xl font-bold mb-6 text-primary"
          >
            Welcome to Childland
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl md:text-2xl text-accent mb-3"
          >
            Nurturing Tomorrow's Eco-Conscious Leaders!
          </motion.p>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-text-secondary mb-8"
          >
            Orléans, France
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-col md:flex-row gap-4 justify-center"
          >
            <button
              onClick={handleScheduleVisit}
              className="btn-primary flex items-center justify-center gap-2"
            >
              <FaCalendarAlt />
              Schedule a Visit
            </button>
            <Link to="/virtual-tour" className="btn-secondary flex items-center justify-center gap-2">
              <FaCompass />
              Take Virtual Tour
            </Link>
          </motion.div>
        </section>

        {/* Gallery Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-primary text-center mb-12">Our Learning Environment</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card group">
              <div className="relative overflow-hidden rounded-xl mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?w=800&auto=format" 
                  alt="Children engaged in creative activities" 
                  className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-primary mb-2">Creative Learning</h3>
              <p className="text-text-secondary">Fostering imagination through interactive activities</p>
            </div>

            <div className="card group">
              <div className="relative overflow-hidden rounded-xl mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&auto=format" 
                  alt="Reading and learning space" 
                  className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-primary mb-2">Bilingual Environment</h3>
              <p className="text-text-secondary">Immersive French-English learning experience</p>
            </div>

            <div className="card group">
              <div className="relative overflow-hidden rounded-xl mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&auto=format" 
                  alt="Eco-friendly activities" 
                  className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-primary mb-2">Eco Activities</h3>
              <p className="text-text-secondary">Hands-on environmental education</p>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="grid md:grid-cols-2 gap-8 mb-20">
          <Link to="/sustainability" className="card group">
            <FaLeaf className="text-5xl text-accent mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-2xl font-bold text-primary mb-4">Eco-Conscious Learning</h3>
            <p className="text-text-secondary mb-4">Through hands-on gardening, recycling projects, and nature exploration, we nurture a deep connection with our environment.</p>
            <span className="text-accent flex items-center gap-2 group-hover:gap-4 transition-all">
              Learn More →
            </span>
          </Link>

          <Link to="/programs" className="card group">
            <FaGlobe className="text-5xl text-accent mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-2xl font-bold text-primary mb-4">Bilingual Environment</h3>
            <p className="text-text-secondary mb-4">Immersive French and English learning through play, stories, and daily activities for children aged 3-5 years.</p>
            <span className="text-accent flex items-center gap-2 group-hover:gap-4 transition-all">
              Explore Programs →
            </span>
          </Link>
        </section>

        {/* Values */}
        <section className="text-center mb-20">
          <h3 className="text-3xl font-bold text-primary mb-12">Our Core Values</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: FaLeaf, text: "Sustainability" },
              { icon: FaGlobe, text: "Bilingual" },
              { icon: FaClock, text: "Flexibility" },
              { icon: FaUsers, text: "Community" }
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="card"
              >
                <value.icon className="text-5xl text-accent mx-auto mb-4" />
                <p className="font-semibold text-lg text-primary">{value.text}</p>
              </motion.div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default Home;